# Kết quả kiểm tra bản bàn giao

Ngày 23/10/2026, AutoCAD đích: **2024 Windows bản đầy đủ**. Kiểm tra mã chạy trong môi trường Linux, không có AutoCAD.

| Kiểm tra | Kết quả thực tế |
|---|---|
| Cú pháp S-expression, form/arity cơ bản và tham chiếu `tc:*` | PASS: 12 mô-đun, 313 định nghĩa hàm, 123 entry command gồm alias |
| Nạp toàn bộ file LSP gộp bằng VeLisp | PASS với các bổ sung chuẩn thư viện mô tả trong DEVELOPMENT.md |
| Hình học thuần, góc/hướng, chia đoạn, DN/D, tên fitting, CSV, Size/reducer và kiểm tra dữ liệu UI | **114 PASS**, 0 thất bại |
| Parse grammar DCL | PASS; chưa render trên AutoCAD |
| Bộ unittest dữ liệu/gói bàn giao | **8 PASS**, 0 thất bại |
| Đối chiếu tổ hợp co cơ bản với template | 86 tổ hợp hệ/vật liệu/cỡ/góc được kiểm tra tồn tại; nhiều tổ hợp ống gió dùng chung một định nghĩa co |
| Property theo template | Width1/Length, Diameter, Diameter1/2, SIDE/UP90/UP45/DN45 được đối chiếu metadata |
| Giao diện nhập số | Hàm thật chạy với tile mô phỏng: từ chối số sai, số âm, hệ số đơn vị bằng 0; không đổi thông số khi dữ liệu lỗi |
| Tệp VBA gốc | 49/49 hash khớp bản tải lên |
| DWG mẫu gốc | SHA-256 khớp, không ghi lại/chuyển đổi DWG |
| `git diff --check` | PASS |

Template dùng duy nhất: `template CAd Duy.dwg`, SHA-256:

```text
e089a2c0831620a744b69017837ff8dd00773a6df2342f15cdbecc71652a925a
```

## Chưa chạy / chưa xác nhận

- `TCSELFTEST` với 16 bước kiểm tra host trong AutoCAD.
- ActiveX/ObjectDBX của Autodesk và import dynamic block vào một DWG đang mở.
- Hình ảnh DCL, hướng thực tế của co/tee/Y/reducer và khe nối/độ ngậm.
- Undo, hủy bằng Esc, layer khóa, xuất CSV UTF-8 và thao tác chọn đối tượng trong AutoCAD thực tế.
- Quy trình dự án đầy đủ hoặc mọi hành vi của các form VBA không được gửi kèm.

Các mục chưa chạy không được tính là PASS hoặc skipped-success. Bản bàn giao là **0.9 để nghiệm thu**, không tuyên bố đã hoàn tất nghiệm thu trong AutoCAD. Xem ACCEPTANCE.md để chạy các bước còn lại.
