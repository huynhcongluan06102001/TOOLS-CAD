# Phạm vi chuyển đổi và đối chiếu nguồn

Đã nhận 49 file `.bas`; hai file chỉ chứa tên mô-đun. Các hàm hình học, chọn đối tượng, đặt thuộc tính và thống kê trùng nhau được gộp vào namespace `tc:*`, tránh xung đột tên Public của nhiều mô-đun VBA.

## Các khác biệt cần biết

- Form `.frm/.frx` của `MAIN`/`usertool` không được gửi. Bảng DCL là giao diện mới, đóng trong lúc nhập lệnh rồi mở lại; không phải palette modeless có thể sửa giá trị bằng chuột khi đang vẽ. Khi pick tuyến có từ khóa `Size` và `Back`.
- Chỉ chuyển hình học MEP 2D WCS XY, không suy diễn 3D từ ghi chú cao độ. `TCISO` là phép xoay/ép theo thử nghiệm VBA.
- Pick tuyến hỗ trợ đổi D/DN/W/H giữa các đoạn. Chỉ đặt reducer đổi kích thước trên đoạn thẳng; đổi hướng cần co 45°/90° với hai đầu cùng cỡ. Không thay góc lẻ/135° bằng một co 90°.
- Nối tự động cần MLINE hai đỉnh hoặc block thẳng Length/Width1/Diameter với scale X=Y=1. Nút giao phải trong sai số, không chồng fitting. Cross tự động chỉ dành cho máng 90°; các kiểu khác chọn block thủ công.
- Template có co/tee/reducer PPR nhưng không có Y PPR theo quy tắc tên của VBA. Ví dụ `Y-D25x25 PPR` thiếu. Công cụ báo thiếu và hoàn tác, không dùng Y UPVC thay thế.
- UPVC trong template sử dụng D21/27/34/42/49/60/75/90/114/140/168/220/280. D25 PPR không được dùng làm mặc định UPVC.
- Xuất dữ liệu bằng bảng AutoCAD và CSV UTF-8 BOM cho Excel, không tái tạo định dạng Excel bằng COM. Các cột phân biệt số lượng block và tổng chiều dài.
- Chuyển tuyến và xử lý thoát nước mặc định giữ nguồn; tùy chọn “Xóa nguồn” chỉ xóa sau khi tạo thành công. Các lệnh chỉnh/thay/nối đối tượng có chủ đích sửa nguồn và được gom Undo.
- Chưa nghiệm thu AutoCAD: không tuyên bố đã tương đương 100% mọi hành vi VBA. Xem `ACCEPTANCE.md` để chạy thử phần host, hướng block và khe nối.

## Đối chiếu từng tệp

| Tệp nguồn | Lệnh / phần tương ứng | Cách xử lý |
|---|---|---|
| `ALIGNBLOCK.bas` | TCALIGN | Giữ block neo; Project/Equal/Round, không dựa thứ tự selection. |
| `autoconnectmline.bas` | TCAFUPVC | Gộp bản thử nghiệm vào bộ nối MLINE chung. |
| `AUTOFITTINGPPR.bas` | TCAFPPR | Co/tee/reducer; Y PPR báo thiếu block theo template. |
| `autofittingsteel.bas` | TCAFSTEEL | DN/D ngoài riêng; không giữ lỗi gọi Y PPR của mã gốc. |
| `autofittingtray.bas` | TCAFTRAY | Co, tee, cross, reducer, Width1/Width2 và trim/split. |
| `AUTOUPVC.bas` | TCAFUPVC | Pair/Batch; tập hợp cuts rồi chia main một lần. |
| `BLOCK.bas` | TCREPLACE, TCRENAME | Thay theo selection/EffectiveName; đổi tên định nghĩa là lệnh riêng. |
| `BOTRIBLOCK.bas` | TCARRAY | Hai chế độ số hàng/cột và khoảng cách, canh giữa. |
| `BOTRO.bas` | TCSUMDIM, TCTABLECSV, TCLEADER | Xuất CSV cho Excel; không điều khiển COM Excel hoặc tái tạo định dạng workbook. |
| `BOUNDINGBOXDYNAMIC.bas` | TCBBOX | Hình học đang hiển thị; không tính text/attribute vào khung. |
| `Changeblock.bas` | TCREPLACE | Giữ góc, scale, layer, tag trùng, dynamic property chung và XData công cụ. |
| `CHENNHANHFITTINGUPVC.bas` | TCUP90, TCDN45 | Dùng UP90/UP45/DN45 thực tế; chèn ký hiệu, không tự trim ống. |
| `CHENVAXOAYBLOCK.bas` | TCBLOCK, TCFIT, TCATTR, TCBEDIT | Nhập và xoay, gán thuộc tính/size. |
| `DIMBLOCK.bas` | TCDIMBLOCK, TCDIM | DIM chuỗi theo trục, tổng, đoạn polyline/MLINE/block. |
| `DOIMAUBLOCK.bas` | TCBYLAYER | Sửa ruột block là tùy chọn ảnh hưởng mọi tham chiếu; không tự PURGE dữ liệu. |
| `funtion.bas` | TCLABEL, TCBLOCK và helpers tc:* | Chọn đối tượng/layer/attributes và text dọc tuyến; alias được đăng ký trong LISP. |
| `InsertBlockrotate.bas` | TCBLOCK, TCBALIGN | Chèn xoay tự chọn hoặc theo tiếp tuyến đường cong. |
| `ketnoi.bas` | TCZIGBOX | Gộp biến thể zigzag + hộp chia. |
| `KETNOIBLOCK.bas` | TCGRID, TCFILLET, TCZIGBOX, TCULINK | Gộp các hàm kết nối/bo góc dùng chung. |
| `ketnoiocam.bas` | TCULINK | Liên kết chữ U qua trục chọn, bo góc theo R. |
| `KETNOITUDIEN.bas` | TCDB, TCCABLESTAT | Theo trục polyline hiện có; có thể vẽ trục bằng PLINE trước; thêm dây chờ khi thống kê. |
| `linedien.bas` | TCARC | Dùng bulge = 2*sagitta/chord, tránh chia cho r-h. |
| `linetoblock.bas` | TCLINETRAY | Thay phần demo vẽ LINE bằng nhóm cạnh song song để chèn Cable tray. |
| `MAIN_MODULE.bas` | TOOLS, TC | Form MAIN/usertool không gửi kèm; bảng DCL thiết kế mới, nhúng trong một file. |
| `Module1.bas` | TCAFUPVC | Bản batch thử nghiệm được gộp vào thuật toán chung. |
| `Module2.bas` | TCLINETRAY | Nhóm LINE song song có vùng chồng; mặc định giữ nguồn. |
| `Module3.bas` | — | File chỉ có Attribute VB_Name, không có Sub/Function để chuyển. |
| `Module4.bas` | TCZIGBOX | Gộp biến thể kết nối zigzag/hộp chia. |
| `Module5.bas` | TCTRAY | Gộp biến thể vẽ máng; hỗ trợ Size/Back khi pick. |
| `Module6.bas` | TCTRAY, TCAFTRAY | Gộp thuật toán đoạn thẳng và phụ kiện máng. |
| `Module7.bas` | TCSTAT, TCXGET | Đếm block, tổng MLINE, truy vấn metadata. |
| `Module8.bas` | — | File chỉ có Attribute VB_Name, không có Sub/Function để chuyển. |
| `Module9.bas` | TCBLOCK | Chức năng scan tree/combobox được thay bằng browser lọc tên. |
| `polylineoffset.bas` | TCSPINE | Một trục chính và các nhánh; bỏ các LINE trùng lặp trong VBA. |
| `tapve.bas` | — | Mã quản trị trial/mã máy và callback form; không phải công cụ vẽ, không tích hợp vào bản chuyển. |
| `test.bas` | TCISO | Bản sao 2.5D xoay/ép Y theo VBA; không tạo BIM/solid 3D. |
| `thongke.bas` | TCSTAT | Gom theo tên/size/attributes/vật liệu/hệ/layer. |
| `ThongKePolyline.bas` | TCCABLESTAT | Chiều dài thực và dây chờ, bảng hoặc CSV. |
| `THONGKEPPR.bas` | TCPPRSTAT | Fitting đếm cái; MLINE tổng mét. |
| `THONGKETRAY.bas` | TCTRAYSTAT | Block thẳng tổng Length, fitting không cộng chiều dài giả. |
| `VEDUCT.bas` | TCDUCT, TCDUCTPL, TCSPLITDUCT, TCDUCTSTAT | Tên/property theo Duy: Width1/Diameter, co và reducer/nhánh riêng. |
| `VEMANGCAP.bas` | TCTRAY, TCTRAYPL | Máng thẳng, co 45/90, ghi chú và XData SYSTEM. |
| `VEONGPPR.bas` | TCPPR, TCPPRPL | Pick/Polyline, Size/Back; đổi D trên đoạn thẳng bằng reducer. |
| `veplthoat.bas` | TCDRAIN, TCCHAMFER | Chọn main và nhánh, nối đầu gần, vát về hướng xả. Không tự giải mạng nhiều vòng hoặc sửa mọi giao cắt bất kỳ. |
| `VESTEEL.bas` | TCSTEEL, TCSTEELPL, TCSTEELSTAT, TCFIT | DN/D ngoài, ren/hàn theo cỡ; phụ kiện đặc biệt chọn bằng TCBLOCK. |
| `VEUPVC.bas` | TCUPVC, TCUPVCPL, TCUPVCSTAT | D theo template, co và khoảng ngậm điều chỉnh. |
| `xdata.bas` | TCXSET, TCXGET | Lưu và truy vấn chuỗi XData; metadata ứng dụng có tên riêng. |
| `ZIGZAGPOLYLINE.bas` | TCZIGZAG | Gom hàng theo anchor cố định và sai số, không làm trôi hàng. |
| `ZIGZAGWITHBOX.bas` | TCZIGBOX | HopchiangD20V1 scale 2; đọc AllowedValues Options thực tế. |
