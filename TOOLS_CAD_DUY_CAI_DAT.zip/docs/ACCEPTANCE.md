# Chạy nghiệm thu trên AutoCAD 2024 Windows

Chưa có kết quả chạy các bước dưới đây trên AutoCAD trong phiên phát triển này. Chúng là bước nghiệm thu cần thực hiện trên máy Windows.

## Kiểm tra tự động có host

1. `NEW` → chọn một template AutoCAD trống thông thường, không mở bản mẫu Duy làm bản vẽ kiểm thử. Model space phải rỗng và chưa sửa.
2. `APPLOAD` → `TOOLS-CAD_DUY.lsp`; `TCTEMPLATE` → chọn bản mẫu Duy gốc.
3. Chạy `TCSELFTEST`. Lệnh tạo sáu tuyến mẫu PPR/UPVC/thép/máng/ống gió chữ nhật/ống gió tròn và một tuyến PPR đổi size 32→25, đọc lại Length/Width1/attribute/XData và tạo DIM có Measurement 5000.
4. Kết quả mong đợi: **16 dòng PASS** và `SELFTEST PASS`. Nếu một bước lỗi, lệnh báo bước thất bại và hoàn tác phần đã tạo. Gửi lại nguyên văn lỗi F2 để chẩn đoán; không coi là đã đạt.
5. `ZOOM` → `Extents`. Kiểm tra hướng co trái/phải 45°/90°, vị trí miệng fitting và khoảng ngậm UPVC. Mã kiểm thử so sánh khả năng tạo hình và giá trị; kiểm tra trực quan vẫn cần thiết.
6. `U` một lần phải xóa toàn bộ hình thử của lệnh, giữ các thay đổi có trước. Không lưu đè bản thư viện.

## Kiểm tra thao tác

| Chức năng | Cách kiểm tra | Tiêu chí |
|---|---|---|
| Bảng điều khiển | `TOOLS`, đổi nhóm/hệ/vật liệu, nhập số sai rồi sửa | Không có tile trống do lỗi key; số sai được từ chối; thông số hợp lệ được nhớ |
| Thư viện | `TCBLOCK`, lọc `ELB*PPR`, chèn và Enter | Đúng block, không nhập cả nội dung Model của template |
| PPR/UPVC/thép | Mỗi hệ vẽ hai tuyến có co trái và phải | Đúng tên block, đường kính, layer và mép nối |
| Chuyển polyline | Chọn hai polyline mở; thử thêm một polyline có bulge | Tuyến hợp lệ chuyển đúng; nguồn giữ mặc định; nguồn có bulge được báo và toàn lệnh hoàn tác |
| Tee / reducer | `TCAFUPVC`, `TCAFPPR`, `TCAFSTEEL`, Pair | Nhánh/đường chính cắt đúng cạnh; reducer cùng trục và đúng hai kích thước |
| Batch | Một main dài và ba nhánh cách xa nhau | Main được chia một lần, không mất phần còn lại; nhánh trùng nút hoặc fitting chồng nhau bị từ chối |
| Máng cross | Hai block thẳng giao giữa tại 90° → `TCAFTRAY` | Một cross, bốn đầu máng tiếp giáp đúng |
| Ống gió | `TCDUCT` cho nep TDC và tron | Chữ nhật ghi Width1, tròn ghi Diameter; đúng block co |
| Rise UPVC | `TCUP90`, `TCDN45` | Trạng thái lần lượt UP90/UP45 và DN45; đây là chèn ký hiệu, không tự cắt ống |
| Thay block | Block có attribute/dynamic/XData → `TCREPLACE` | Vị trí, góc, scale, tag trùng và metadata giữ; mẫu không bị xóa |
| Bố trí | `TCARRAY`, `TCALIGN`, một hàng/một cột | Canh giữa đúng; block neo không dịch chuyển |
| Đi dây | Các nhóm 2×3 block → GRID, ZIGZAG, ZIGBOX, ARC | Đi qua đủ điểm, đúng hàng, hộp đúng hướng/Options |
| Tủ điện | Polyline có nhiều đoạn → `TCDB` | Đường cáp đi theo đủ các đỉnh; không cắt góc qua phòng |
| Thống kê | MLINE 5000 mm + máng Length 3000 mm + hai fitting | Chiều dài 5 m/3 m, fitting đếm cái, không cộng kích thước phụ kiện vào chiều dài ống |
| CSV | Chọn Both; mở CSV trong Excel | Đúng số liệu/UTF-8, dấu phẩy và dấu nháy được giữ trong ô |
| Lỗi/hủy | Esc giữa nhập, block thiếu, layer khóa, đoạn quá ngắn | Có thông báo; không sót ray/explode tạm; biến CLAYER/CMLSTYLE/CMLSCALE/CMLJUST/OSMODE được trả lại |

Các lệnh tạo hình cần chạy trên bản sao. Khi đã đạt quy trình phù hợp với công việc, mới áp dụng lên bản vẽ dự án.
