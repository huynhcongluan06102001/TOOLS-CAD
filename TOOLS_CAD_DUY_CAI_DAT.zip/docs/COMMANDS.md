# Danh sách lệnh

Gõ `TOOLS` hoặc `TC` để mở bảng điều khiển; `TCHELP` hiện hướng dẫn. Thông số dùng chung được lưu theo profile AutoCAD.

## Vẽ tuyến

| Lệnh | Chức năng | Cách dùng / giới hạn |
|---|---|---|
| `TCPPR` | Ve ong PPR | Pick diem hoac chon Polyline; tu chen co 45/90. |
| `TCUPVC` | Ve ong UPVC | Duong kinh ngoai D; vat lieu theo template Duy. |
| `TCSTEEL` | Ve ong thep | Nhap DN; ve MLINE theo D ngoai va fitting DN. |
| `TCTRAY` | Ve mang cap | Cable tray / Trunking / Ladder, Width1 va Length. |
| `TCDUCT` | Ve ong gio | Nep TDC / nep C / tron / cach nhiet / tieu am. |
| `TCPPRPL` | Polyline sang PPR | Chuyen nhieu polyline mo, doan thang. |
| `TCUPVCPL` | Polyline sang UPVC | Giu nguon mac dinh; co the bat xoa nguon. |
| `TCSTEELPL` | Polyline sang thep | Kiem tra tat ca nguon truoc khi tao tuyen. |
| `TCTRAYPL` | Polyline sang mang cap | Dung block dong thuc te cua template. |
| `TCDUCTPL` | Polyline sang ong gio | Ong gio tron dung Diameter, chu nhat dung Width1. |
| `TCSPLITDUCT` | Chia doan ong gio | Chia theo chieu dai; giu dynamic, attributes va XData. |
| `TCLINETRAY` | Net song song sang mang | Nhom LINE song song va chong lan theo chieu doc. |

## Nối phụ kiện

| Lệnh | Chức năng | Cách dùng / giới hạn |
|---|---|---|
| `TCAFPPR` | Tu noi fitting PPR | Pair/Batch: co 45/90, tee, reducer; bao block thieu. |
| `TCAFUPVC` | Tu noi fitting UPVC | MLINE 2 dinh, tam Zero; cat theo mep fitting. |
| `TCAFSTEEL` | Tu noi fitting thep | D ngoai MLINE doi sang DN de chon fitting. |
| `TCAFTRAY` | Tu noi fitting mang | Elbow / Tee / Cross / Reducer, ke ca Batch. |
| `TCAFDUCT` | Tu noi fitting ong gio | Co / Chac 3 / Con giam; chi dung block co trong template. |
| `TCFIT` | Chen phu kien thu cong | Theo he va thong so ben phai, hoac nhap ten block. |
| `TCUP90` | Cap co UP90 + UP45 | Pick gan dau MLINE UPVC; giong mo-dun goc. |
| `TCDN45` | Co thoat xuong DN45 | Trang thai Duy la DN45, khong phai DOWN45. |
| `TCDRAIN` | Noi nhanh polyline thoat | Ong chinh + nhanh vuong goc; vat ve huong ong dung. |
| `TCCHAMFER` | Vat goc polyline 45 | Vat cac dinh 90; giu nguon mac dinh. |

## Block / thư viện

| Lệnh | Chức năng | Cách dùng / giới hạn |
|---|---|---|
| `TCBLOCK` | Thu vien / chen block | Loc 1315 block co ten trong template va block ban ve. |
| `TCARRAY` | Bo tri block theo vung | Nhap so hang/cot hoac buoc; sao chep dynamic cua mau. |
| `TCALIGN` | Can hang / chia deu block | Giu nguyen block neo, chieu len truc hoac chia deu. |
| `TCREPLACE` | Thay block | Theo selection/ten; giu tag trung, scale, goc, XData. |
| `TCRENAME` | Doi ten dinh nghia block | Anh huong tat ca tham chieu cung dinh nghia. |
| `TCBALIGN` | Chen block theo tiep tuyen | Chon block mau, pick tren LINE/POLYLINE/ARC. |
| `TCBEDIT` | Sua dynamic property | Hien AllowedValues va kiem tra lai sau khi gan. |
| `TCATTR` | Sua attribute hang loat | Lay tag tu block mau, gan gia tri cho nhom da chon. |
| `TCBBOX` | Khung block hien tai | Lay hinh hoc hien thi, bo qua text va attribute. |
| `TCBYLAYER` | Chuan hoa layer / mau | Tuy chon sua ruot block; mac dinh chi sua tham chieu. |

## Điện / dây cáp

| Lệnh | Chức năng | Cách dùng / giới hạn |
|---|---|---|
| `TCGRID` | Noi block ngang doc | Thu tu diem gan nhat, tao polyline ortho. |
| `TCCHAIN` | Noi block gan nhat | Chuoi polyline qua diem chen, khong bo goc. |
| `TCFILLET` | Noi block va bo goc | Polyine qua block, R theo thong so dung chung. |
| `TCZIGZAG` | Noi block zigzag | Nhom hang theo sai so, sap xep kieu ran. |
| `TCZIGBOX` | Zigzag va hop chia | Dung HopchiangD20V1 scale 2 va Options cua block. |
| `TCARC` | Day dien dang cung | Bulge tinh theo do vong cung that. |
| `TCULINK` | Noi o cam kieu U | Pick truc day, noi tung cap va bo goc. |
| `TCSPINE` | Truc chinh va nhanh block | Chieu block len truc qua diem pick. |
| `TCDB` | Noi thiet bi ve tu dien | Giu du cac dinh cua polyline truc chinh. |

## DIM / ghi chú

| Lệnh | Chức năng | Cách dùng / giới hạn |
|---|---|---|
| `TCDIMBLOCK` | DIM chuoi block | DIM xoay theo truc, tuy chon them DIM tong. |
| `TCDIM` | DIM cac doan tuyen | LINE / polyline thang / MLINE / block thang. |
| `TCLABEL` | Text doc tuyen | Dat text o nua chieu dai that, xoay de doc. |
| `TCLEADER` | Ghi chu MLeader | Chon mui ten, diem ghi chu, nhap noi dung. |

## Thống kê / CSV

| Lệnh | Chức năng | Cách dùng / giới hạn |
|---|---|---|
| `TCSTAT` | Thong ke tong hop | Tach vat lieu, he thong, layer, size, visibility. |
| `TCPPRSTAT` | Thong ke PPR | Loc nhom PPR tu metadata va ten fitting. |
| `TCUPVCSTAT` | Thong ke UPVC | Dem fitting va tinh chieu dai ong. |
| `TCSTEELSTAT` | Thong ke thep | Dem fitting DN va tinh chieu dai MLINE. |
| `TCTRAYSTAT` | Thong ke mang cap | Dem block, gom tong Length cac block thang. |
| `TCDUCTSTAT` | Thong ke ong gio | Size theo thuoc tinh block; chia don vi ra met. |
| `TCCABLESTAT` | Thong ke day cap | Chieu dai tuyen + day cho moi tuyen. |
| `TCSUMDIM` | Cong DIM thang | Bo qua DIM goc/ban kinh; xuat bang chi tiet. |
| `TCTABLECSV` | Bang CAD sang CSV | CSV UTF-8 BOM, Excel mo duoc, khong can cai Excel. |

## Tiện ích / kiểm tra

| Lệnh | Chức năng | Cách dùng / giới hạn |
|---|---|---|
| `TCXSET` | Gan XData | Chon ten nhom va noi dung, gan cho selection. |
| `TCXGET` | Doc XData | Doc metadata cua selection ra dong lenh. |
| `TCISO` | Ban sao 2.5D | Xoay/ep Y theo test.bas; khong phai mo hinh BIM 3D. |
| `TCINSPECT` | Xem block / AllowedValues | In ten, dynamic properties, attributes va XData. |
| `TCTEMPLATE` | Chon template Duy | Luu duong dan thu vien tren may Windows cua ban. |
| `TCINIT` | Khoi tao / kiem tra thu vien | Doc danh muc ObjectDBX va tao style TC_MC. |
| `TCCHECK` | Chan doan moi truong | In phien ban, LISPSYS, template va don vi. |
| `TCSELFTEST` | Kiem thu AutoCAD | Chi chay trong ban ve moi rong; tao hinh de doi chieu. |

## Bí danh từ VBA

Các biến thể cùng chức năng trỏ về một lệnh chung; đây không phải các bản dịch từng dòng độc lập.

| Tên gọi VBA | Lệnh mới |
|---|---|
| `SHOWFORM` | `TOOLS` |
| `MAINPPR` | `TCPPR` |
| `VEONGUPVC` | `TCUPVC` |
| `MAINSTEEL` | `TCSTEEL` |
| `MAINMANGCAP` | `TCTRAY` |
| `MAINDUCT` | `TCDUCT` |
| `BOTRIBLOCK` | `TCARRAY` |
| `ALIGNANDSPACEBLOCKS` | `TCALIGN` |
| `CHANGEBLOCK` | `TCREPLACE` |
| `REPLACEBLOCKNAMES` | `TCREPLACE` |
| `INSERTBLOCKWITHROTATION` | `TCBLOCK` |
| `DRAWCURRENTVISIBILITYBOUNDINGBOXFIXED` | `TCBBOX` |
| `AUTOTRAYFITTING_FULL` | `TCAFTRAY` |
| `AUTOINSERTFITTING_PPR` | `TCAFPPR` |
| `AUTOINSERTFITTING_STEEL` | `TCAFSTEEL` |
| `AUTOINSERTFITTING_FINAL_STANDARD_V11` | `TCAFUPVC` |
| `AUTOINSERTFITTING_FINAL_STANDARD_V10` | `TCAFUPVC` |
| `AUTOINSERTFITTING_BATCH_FULL` | `TCAFUPVC` |
| `INSERTDOUBLEELBOWONMLINE` | `TCUP90` |
| `ELBOW45DOWNONMLINE` | `TCDN45` |
| `CONVERTPOLYLINETOPIPING` | `TCPPRPL` |
| `VEONGTHOAT_POLYLINE` | `TCUPVCPL` |
| `VEONGSTEEL_POLYLINE` | `TCSTEELPL` |
| `VEMANGCAP_FROM_POLYLINE` | `TCTRAYPL` |
| `SPLITDUCTBLOCKS` | `TCSPLITDUCT` |
| `SCANANDGROUP_INSERTCABLETRAY` | `TCLINETRAY` |
| `CONNECTBLOCKSGRID` | `TCGRID` |
| `CONNECTBLOCKSSINGLEPOLYLINE_FILLET` | `TCFILLET` |
| `CONNECTBLOCKSGRIDZIGZAG` | `TCZIGZAG` |
| `CONNECTBLOCKSGRIDZIGZAGWITHBOX` | `TCZIGBOX` |
| `LINKBLOCKSARC_AUTOSORT_NEARESTEND` | `TCARC` |
| `LINKBLOCKOFFSET` | `TCULINK` |
| `CREATECHAINPOLYLINEFROMBLOCKS` | `TCSPINE` |
| `CONNECTBLOCKS_FOLLOWORCREATEPOLYLINE` | `TCDB` |
| `QUICKCHAINDIMBLOCKS_FINAL` | `TCDIMBLOCK` |
| `QUICKCHAINDIMBLOCKS_SAFE` | `TCDIMBLOCK` |
| `DIMALLPOLYLINESINSELECTION` | `TCDIM` |
| `DIMMLINE_FINAL_CORRECTSIDE` | `TCDIM` |
| `DIMLENGTHOFBLOCK` | `TCDIM` |
| `TINHTONGDIM_CHITIET` | `TCSUMDIM` |
| `TINHTONGDIM_XUATTABLE` | `TCSUMDIM` |
| `EXPORTTABLESTOEXCEL` | `TCTABLECSV` |
| `CREATEMLEADER_CUSTOM` | `TCLEADER` |
| `COUNTALL_WITHMLINE` | `TCSTAT` |
| `TRUYVAN` | `TCXGET` |
| `THONGKEPOLYLINE` | `TCCABLESTAT` |
| `THONGKECAP` | `TCCABLESTAT` |
| `THONGKEDUCT_TOTABLE` | `TCDUCTSTAT` |
| `COUNTBLOCKSBYATTRIBUTES_TOTABLE` | `TCTRAYSTAT` |
| `COUNTBLOCKSANDMLINE_TOTABLE_WITHSYSTEM` | `TCSTAT` |
| `COUNTBLOCKSANDMLINE_TOTABLE_STEEL` | `TCSTEELSTAT` |
| `COUNTBLOCKSANDMLINE_TOTABLE_THOAT` | `TCUPVCSTAT` |
| `COUNTBLOCKSANDMLINE_TOTABLE` | `TCPPRSTAT` |
| `BTN_CLEANANDPURGE` | `TCBYLAYER` |
| `CHUYEN2D_SANG_25D_FIXED` | `TCISO` |
| `TAOMATNGHIENG_25D_ISOMETRIC` | `TCISO` |
| `AUTOCONNECT_V15_PHASED` | `TCDRAIN` |
| `DATPHUKIEN` | `TCFIT` |
