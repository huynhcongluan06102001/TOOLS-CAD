# Build và kiểm thử mã nguồn

Python 3 và Node.js chỉ dùng để phát triển/đóng gói. AutoCAD không cần chúng.

```sh
python3 tools/build_release.py
python3 tools/check_sources.py
python3 -m unittest discover -s tests -p 'test_*.py' -v
VELISP_ROOT=/path/to/velisp node tests/run_pure.mjs
```

`build_release.py` nhúng DCL và tất cả mô-đun vào `TOOLS-CAD_DUY.lsp`, tạo registry 62 lệnh/58 alias và dữ liệu danh sách lệnh. Sau khi sửa mã tách trong `lisp/` hoặc giao diện, phải build lại trước khi phân phối.

Trình thông dịch dùng cho các kiểm tra thuần là [VeLisp](https://github.com/ten0s/velisp), commit `77e5a95fadd9bbf6d48cc6dc69d7a0875bf1f33f` (0.8.0). Cài riêng ngoài repository; không đóng gói thư viện này vào sản phẩm. Runner dùng các mô-đun thông dịch/grammar, không cần GTK:

```sh
git clone https://github.com/ten0s/velisp.git /tmp/velisp
git -C /tmp/velisp checkout 77e5a95fadd9bbf6d48cc6dc69d7a0875bf1f33f
npm install --prefix /tmp/velisp-deps antlr4@4.10.1 commander@9.3.0 temp@0.9.4
ln -s /tmp/velisp-deps/node_modules /tmp/velisp/node_modules
VELISP_ROOT=/tmp/velisp node tests/run_pure.mjs
```

VeLisp không phải AutoCAD. Runner bổ sung RTOS/DISTOF tối thiểu, EQUAL có fuzz và ATAN hai đối số theo atan2 vì VeLisp 0.8 chưa có cùng hành vi với AutoCAD. Các tile được mô phỏng riêng để kiểm tra hàm kiểm tra dữ liệu; `snvalid` trong mô phỏng chỉ kiểm tra chuỗi không rỗng. Không dùng mô phỏng này để kết luận ObjectDBX, hình học block, DCL hiển thị, tính hợp lệ đầy đủ của tên layer hoặc Undo hoạt động trong AutoCAD.

## Nguồn dữ liệu DWG

Template gốc có header `AC1032` (định dạng 2018). Đã đọc metadata bằng [LibreDWG](https://github.com/LibreDWG/libredwg), commit `a8ccb1f314d9feb2215be67d1f6f2a3d64b2c9a0`. Bộ đọc báo cảnh báo về dữ liệu ACIS của 3DSOLID; chỉ dùng kết quả để khảo sát tên, tham số block và MLINESTYLE. Không chuyển đổi, ghi lại hay thay thế DWG gốc.

JSON chẩn đoán của bộ đọc có số NaN không hợp lệ và một số byte không phải UTF-8; bản phân tích đã chuẩn hóa phần chẩn đoán đó. Runtime LISP luôn đọc DWG gốc qua ObjectDBX của Autodesk; không dùng JSON khảo sát để tạo hình hay thay thế tên block tại runtime. Các tên MEP ASCII dùng bởi lệnh có kiểm tra tồn tại và các thuộc tính chính được đối chiếu riêng.

`reference/vba/` chứa 49 mô-đun nguyên byte; `inventory.json` lưu hash và danh sách Sub/Function. `template-blocks.json`/`template-properties.json` chỉ là metadata rút gọn. Không kèm `THUVIENUPVC LISP.dwg` theo yêu cầu người dùng.
