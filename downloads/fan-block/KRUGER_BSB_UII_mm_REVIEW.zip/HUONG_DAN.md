# KRUGER BSB UII — mm, 33 hướng nhìn

## Trạng thái bàn giao — đọc trước
Đây là **DXF đường bao bố trí có thuộc tính + LISP tạo dynamic block trên AutoCAD**, không phải DWG dynamic đã được tạo và kiểm thử sẵn.
Môi trường tạo file không có AutoCAD. Lệnh tạo Visibility trong BSBFAN_BUILD.lsp chưa được chạy trên AutoCAD; có thể cần chỉnh trình tự prompt theo phiên bản. Không ghi đè file dự án thật khi thử.

Hình là **envelope/port schematic 2D phục vụ bố trí**, không phải hình chi tiết vỏ xoắn, guồng, ổ trục hoặc bản vẽ gia công của hãng. Không dùng để khoan/chế tạo. Các biên dạng không có kích thước không được nội suy thành chi tiết giả.

## Phạm vi
Nguồn: ba trang cuối của `20. SEAF-PLA-COR-1.pdf`:
- PDF trang 4 (catalog trang 32): BSB UII 315, 355, 400, 450, 500, 560, 630, 710, 800, 900, 1000.
- PDF trang 5: phụ kiện mặt bích. Bản này không gắn thêm flange phụ kiện H=120/200 vì khác phần thân quạt tiêu chuẩn.
- PDF trang 6: bộ BSB 710/DIIM với motor và bệ, thông số L1700 W1206 H1382. **Loại khỏi block UII** vì khác cấu hình, không trộn dữ liệu này vào model 710 UII.
- Model 1120/1250/1400: chỉ có mặt bích, thiếu bảng thân quạt trong tài liệu này, **không tạo**.
- `quat.dwg` được xem làm mẫu bố trí. Bản đọc trung gian cho thấy hình bằng có motor/bệ; không lấy hình đó để co giãn cho model khác. Không dùng bản chuyển đổi thử có watermark trong file bàn giao.

## Quy ước
Đơn vị: millimetres, INSUNITS=4, tỷ lệ 1:1.
FRONT: hướng trục/cửa hút, thể hiện B x A và đường kính V/V1/V2; tâm ở G, A-C.
SIDE: phương trục nằm ngang, bao L x A; thân N, cửa xả E x D, mặt bích ngoài N x S.
TOP: hình bằng bao B x L, hình chiếu thân/đầu hút/trục. Không có motor, dây đai, bệ rời.
Điểm chèn (0,0) theo gốc bao bố trí của mỗi hình; đổi hướng nhìn không giữ một tọa độ 3D chung của miệng nối.
Layer OUTLINE là đường bao quy ước, PORT là cửa kết nối, CENTER là tim. Các lớp BSB_STATE_* phục vụ visibility; không tắt/xóa riêng các layer này.

## Tạo block động trong AutoCAD 2025 Windows
1. Giải nén. Mở **KRUGER_BSB_UII_33_VIEWS_mm.dxf** bằng OPEN, không INSERT vào bản vẽ khác ở bước này.
2. Bản vẽ hiển thị 33 hình rời để kiểm tra. Definition cha `KRUGER_BSB_UII` đã chứa các hình con và ATTDEF; chưa có Visibility.
3. APPLOAD `BSBFAN_BUILD.lsp`. Gõ `BSBFANBUILD`.
4. Công cụ mở Block Editor và gọi tạo Visibility parameter. Bấm một điểm đặt grip ngoài hình quạt. Hoàn tất các prompt của BPARAMETER nếu AutoCAD yêu cầu.
5. Công cụ thử tạo TOP 315, SIDE 315, FRONT 315 … FRONT 1000, mỗi state chỉ hiện một hình con và thuộc tính cha. Không thao tác trong lúc lệnh đang chạy.
6. Chỉ khi dòng lệnh báo đã kiểm tra đủ 33 Visibility mới tiếp tục. Nếu lỗi: ESC, BCLOSE > Discard, giữ DXF gốc. Gửi nội dung F2 để sửa script; đừng coi kết quả chưa hoàn thành là dynamic block đúng.
7. Nếu còn state mặc định VisibilityState0, mở BEDIT > Visibility States và xóa state đó. Giữ 33 tên trong states.json.
8. INSERT `KRUGER_BSB_UII`. Đổi Visibility bằng grip hoặc Properties. Gõ `BSBFANUPDATE`, chọn block để đồng bộ MODEL, VIEW và các kích thước theo state vừa chọn.
9. SAVEAS bản kiểm tra sang DWG. Nếu muốn file thư viện chỉ có block: WBLOCK > Source: Block > KRUGER_BSB_UII > Units: millimeters. Không dùng WBLOCK Objects cho cả bảng 33 hình.

## Thuộc tính
TAG: tự nhập, BSBFANUPDATE không ghi đè.
MODEL, VIEW, SERIES, UNITS, STATUS; A/B/C/D/E/F/F1/G/H/J/L/M/N/P/Q/R/S/V/V1/V2/X/Y/T/T1/W/Z/SHAFT_D/SLOT theo bảng mm.
Để tránh chữ đè lên quạt, các thuộc tính mặc định invisible; sửa bằng EATTEDIT, xem bằng Properties/ATTDISP theo nhu cầu.
**Sau mỗi lần đổi Visibility phải chạy BSBFANUPDATE**. Chưa có reactor tự đồng bộ; nếu bỏ qua, thuộc tính có thể còn model cũ.
Lưu lượng/áp suất/công suất không được gán cho các model UII: trang cuối chỉ cung cấp điểm chọn riêng của 710/DIIM.

## Kiểm tra trước khi sử dụng
- DXF: đã đọc lại và AUDIT bằng ezdxf, không có lỗi cấu trúc; đủ 33 definition hình con; INSUNITS=4.
- CSV/JSON: 11 dòng; V bằng model; N-E=56 và S-D=56 cho tất cả các dòng.
- LISP: đã kiểm tra cân ngoặc; chưa kiểm thử native BPARAMETER/-BVSTATE/BVSHOW/BSAVE trên AutoCAD.
- Trong AutoCAD: đo model 450 (A827 B726 L876 N364 E308 D568 V450), 710 (A1302 B1120 L1176 N535 E479 D898 V710), 1000 (A1810 B1540 L1448 N719 E663 D1266 V1000).
- Đổi đủ 33 state; bảo đảm chỉ một hình hiện, chạy BSBFANUPDATE kiểm tra thuộc tính; lưu/đóng/mở lại và thử INSERT sang bản vẽ mm khác.
