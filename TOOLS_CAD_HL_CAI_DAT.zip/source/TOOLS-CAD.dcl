// Embedded into ToolsCadHL.lsp by tools/build_release.py.
tc_main : dialog {
  label = "Tools Cad HL | AutoCAD 2024 Windows";
  : row {
    : boxed_column {
      label = "Nhom chuc nang";
      : list_box { key = "groups"; width = 23; height = 21; fixed_width = true; }
    }
    : boxed_column {
      label = "Lenh (nhap dup de chay)";
      : list_box { key = "commands"; width = 45; height = 21; fixed_width = true; }
    }
    : boxed_column {
      label = "Thong so dung chung";
      : popup_list { key = "system"; label = "He"; width = 30; }
      : popup_list { key = "material"; label = "Vat lieu"; width = 30; }
      : row {
        : edit_box { key = "dn"; label = "D/DN"; edit_width = 7; }
        : edit_box { key = "width"; label = "W/D"; edit_width = 7; }
      }
      : row {
        : edit_box { key = "height"; label = "H"; edit_width = 7; }
        : edit_box { key = "text"; label = "Chu"; edit_width = 7; }
      }
      : edit_box { key = "layer"; label = "Layer"; edit_width = 20; }
      : edit_box { key = "service"; label = "He thong"; edit_width = 20; }
      : edit_box { key = "elevation"; label = "BOP/BOT"; edit_width = 20; }
      : row {
        : edit_box { key = "gap"; label = "Sai so noi"; edit_width = 6; }
        : edit_box { key = "overlap"; label = "Ngam UPVC"; edit_width = 6; }
      }
      : row {
        : edit_box { key = "fillet"; label = "R bo goc"; edit_width = 6; }
        : edit_box { key = "rowtol"; label = "Sai so hang"; edit_width = 6; }
      }
      : edit_box { key = "allowance"; label = "Day cho/tuyen"; edit_width = 10; }
      : edit_box { key = "unit"; label = "Don vi ve / met"; edit_width = 10; }
      : toggle { key = "note"; label = "Ghi chu khi ve tuyen"; }
      : toggle { key = "erase"; label = "Xoa nguon SAU khi chuyen doi"; }
      : text { label = "Thep nhap DN; PPR/UPVC nhap D."; }
    }
  }
  : text { key = "hint"; width = 104; fixed_width = true; }
  : errtile { key = "error"; }
  : row {
    : button { key = "run"; label = "Chay lenh"; is_default = true; width = 18; }
    : button { key = "save"; label = "Luu thong so"; width = 18; }
    : button { key = "help"; label = "Huong dan"; width = 18; }
    : button { key = "cancel"; label = "Dong"; is_cancel = true; width = 18; }
  }
}

tc_blocks : dialog {
  label = "Thu vien block | template CAd Duy";
  : text { label = "Doc truc tiep danh muc block; giu nguyen dinh nghia da co trong ban ve."; }
  : row {
    : edit_box { key = "query"; label = "Loc ten (* = bat ky)"; edit_width = 45; }
    : button { key = "filter"; label = "Loc"; width = 12; }
  }
  : list_box { key = "blocks"; width = 76; height = 22; }
  : text { key = "count"; width = 76; }
  : errtile { key = "error"; }
  ok_cancel;
}
