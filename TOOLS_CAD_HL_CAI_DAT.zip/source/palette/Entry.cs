using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Globalization;
using System.Text;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.Windows;
using AcApp = Autodesk.AutoCAD.ApplicationServices.Core.Application;

[assembly: ExtensionApplication(typeof(ToolsCad.Entry))]
[assembly: CommandClass(typeof(ToolsCad.Entry))]
namespace ToolsCad
{
    public sealed class Entry : IExtensionApplication
    {
        private static PaletteSet palette;
        private static PaletteView view;
        private static Preferences preferences;
        private static Request pending;
        private static Document observed;
        private sealed class Request
        {
            public string Token, Action, Command;
            public Document Document;
            public Profile Profile;
            public Dictionary<string, object> Settings;
            public bool Taken;
        }
        public void Initialize()
        {
            preferences = Preferences.Load();
            AcApp.DocumentManager.DocumentActivated += (s, e) => BindDocument(e.Document);
        }
        public void Terminate()
        {
            if (observed != null)
            {
                observed.CommandEnded -= Finished; observed.CommandCancelled -= Finished; observed.CommandFailed -= Finished;
            }
            palette?.Dispose();
        }
        private static void BindDocument(Document doc)
        {
            if (observed == doc) return;
            if (observed != null)
            {
                observed.CommandEnded -= Finished; observed.CommandCancelled -= Finished; observed.CommandFailed -= Finished;
            }
            if (pending != null && pending.Document != doc)
            {
                pending = null; view?.SetBusy(false); view?.SetStatus("Đã đổi bản vẽ; yêu cầu chưa chạy được hủy.", false);
            }
            observed = doc;
            if (doc != null) { doc.CommandEnded += Finished; doc.CommandCancelled += Finished; doc.CommandFailed += Finished; }
        }
        private static void Finished(object sender, CommandEventArgs e)
        {
            if (string.Equals(e.GlobalCommandName, "TC_EXEC", StringComparison.OrdinalIgnoreCase) && pending != null)
            {
                pending = null; view?.SetBusy(false); view?.SetStatus("Lệnh đã kết thúc hoặc bị hủy. Xem F2 nếu AutoCAD báo lỗi.", false);
            }
        }
        [CommandMethod("TCPALETTE", CommandFlags.Session)]
        public static void ShowCommand() => Show();
        [LispFunction("TC_PALETTE_SHOW_010")]
        public static string ShowLisp(ResultBuffer args)
        {
            Show(); return "OK";
        }
        private static void Show()
        {
            if (palette == null)
            {
                if (preferences == null) preferences = Preferences.Load();
                view = new PaletteView(preferences, Queue);
                palette = new PaletteSet("Tools Cad HL 0.10", new Guid("34b47b1c-7e35-4c29-a68a-664b26d8cff1"))
                {
                    Style = PaletteSetStyles.ShowAutoHideButton | PaletteSetStyles.ShowCloseButton | PaletteSetStyles.ShowPropertiesMenu,
                    DockEnabled = DockSides.Left | DockSides.Right, MinimumSize = new Size(320, 420),
                    Size = new Size(380, 740), KeepFocus = false
                };
                palette.Add("Các hệ thống", view);
                if (!preferences.PlacementInitialized)
                {
                    palette.Dock = DockSides.Right; preferences.PlacementInitialized = true;
                }
            }
            BindDocument(AcApp.DocumentManager.MdiActiveDocument);
            palette.Visible = true;
        }
        private static void Queue(string action, Profile profile, string command)
        {
            var doc = AcApp.DocumentManager.MdiActiveDocument;
            if (doc == null) { view.SetStatus("Mở một bản vẽ trước khi chạy lệnh.", true); return; }
            BindDocument(doc);
            if (pending != null || !doc.Editor.IsQuiescent)
            {
                view.SetStatus("Kết thúc lệnh đang chạy trước khi bấm nút mới. Có thể đổi kích thước khi đang pick tuyến.", true); return;
            }
            pending = new Request { Token = Guid.NewGuid().ToString("N"), Action = action, Command = command,
                Document = doc, Profile = profile, Settings = profile.Settings() };
            view.SetBusy(true); view.SetStatus("Chọn điểm / đối tượng trên bản vẽ. Bảng vẫn mở; Enter kết thúc, Esc hủy.", false);
            try { doc.SendStringToExecute("TC_EXEC " + pending.Token + "\n", true, false, false); }
            catch (System.Exception ex) { pending = null; view.SetBusy(false); view.SetStatus(ex.Message, true); }
        }
        private static string Token(ResultBuffer args)
        {
            var a = args?.AsArray(); return a != null && a.Length > 0 ? a[0].Value as string : null;
        }
        [LispFunction("TC_PALETTE_TAKE_010")]
        public static string Take(ResultBuffer args)
        {
            if (pending == null || pending.Taken || pending.Token != Token(args) || pending.Document != AcApp.DocumentManager.MdiActiveDocument)
                return "";
            pending.Taken = true;
            var result = new Dictionary<string, object> { {"action",pending.Action}, {"command",pending.Command}, {"settings",pending.Settings} };
            return LispWire.Encode(result);
        }
        [LispFunction("TC_PALETTE_LIVE_010")]
        public static string Live(ResultBuffer args)
        {
            if (pending == null || !pending.Taken || pending.Document != AcApp.DocumentManager.MdiActiveDocument)
                return "";
            return LispWire.Encode(pending.Profile.Settings());
        }
        [LispFunction("TC_PALETTE_DONE_010")]
        public static string Done(ResultBuffer args)
        {
            var values = args?.AsArray();
            if (pending != null && pending.Token == Token(args) && pending.Document == AcApp.DocumentManager.MdiActiveDocument)
            {
                string message = values != null && values.Length > 1 ? values[1].Value as string : "Lệnh đã kết thúc.";
                bool error = values != null && values.Length > 2 && (values[2].Value as string) == "0";
                view.SetBusy(false); view.SetStatus(message ?? "Lệnh đã kết thúc.", error); pending = null;
            }
            return "OK";
        }
    }
}
