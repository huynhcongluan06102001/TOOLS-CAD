using System;
using System.Collections.Generic;
using System.Linq;
namespace ToolsCad
{
    public static class ValveGeometry
    {
        public static double Snap45(double angle,double basis)
        { return basis+Math.Round((angle-basis)/(Math.PI/4),MidpointRounding.AwayFromZero)*(Math.PI/4); }
        public static double Rotation(U2Point delta,bool ortho,double ucsAngle)
        {
            double a=Math.Atan2(delta.Y,delta.X);
            return ortho?ucsAngle+Math.Round((a-ucsAngle)/(Math.PI/2),MidpointRounding.AwayFromZero)*(Math.PI/2):a;
        }
        public static (U2Point A,U2Point B) Ports(IEnumerable<U2Face> source,double diameter)
        {
            // Table valves use the local X flow axis; end-on circle views have no two axial ports.
            var faces=source.Where(f=>Math.Abs(f.Tangent.Y)>.999&&f.Width>=diameter*.65&&f.Width<=diameter*6).ToArray();
            U2Face left=null,right=null;double score=double.MaxValue;
            foreach(var a in faces)foreach(var b in faces) {
                double length=b.Center.X-a.Center.X;
                if(length<diameter*.2||Math.Abs(a.Center.Y-b.Center.Y)>Math.Max(.1,diameter*.015)||Math.Abs(a.Width-b.Width)>diameter*.2)continue;
                double cost=(Math.Abs(a.Width-diameter)+Math.Abs(b.Width-diameter))/diameter+Math.Abs((a.Center.Y+b.Center.Y)/2)/diameter*.05-length/diameter*.001;
                if(cost<score){score=cost;left=a;right=b;}
            }
            if(left==null)throw new InvalidOperationException("Trang thai nay khong co hai cong doc truc X de cat ong. Space chon trang thai khac hoac dat ngoai MLINE.");
            return (left.Center,right.Center);
        }
        public static (U2Point Left,U2Point Right) Cut(U2Point a,U2Point b,U2Point portA,U2Point portB,double overlap)
        {
            if(double.IsNaN(overlap)||double.IsInfinity(overlap)||overlap<0)throw new InvalidOperationException("Khoang ngam khong hop le.");
            var axis=(b-a).Unit;double length=(b-a).Length;
            if(Math.Abs((portA-a).Dot(axis.Perp))>.05||Math.Abs((portB-a).Dot(axis.Perp))>.05)
                throw new InvalidOperationException("Cong van khong nam tren tim MLINE. Khong cat ong.");
            double l=Math.Min((portA-a).Dot(axis),(portB-a).Dot(axis));double h=Math.Max((portA-a).Dot(axis),(portB-a).Dot(axis));
            if(l<=.01||h>=length-.01||h-l<=2*overlap+.01)throw new InvalidOperationException("Van vuot dau ong hoac khoang ngam qua lon. Khong cat ong.");
            return (a+axis*(l+overlap),a+axis*(h-overlap));
        }
        public static U2Point[][] SplitRoute(U2Point[] vertices,int segment,U2Point left,U2Point right,U2Point centerShift)
        {
            if(vertices==null||segment<0||segment+1>=vertices.Length)throw new InvalidOperationException("Doan MLINE khong hop le.");
            left-=centerShift;right-=centerShift;
            var a=vertices[segment];var b=vertices[segment+1];var u=(b-a).Unit;
            double l=(left-a).Dot(u),r=(right-a).Dot(u),length=(b-a).Length;
            if(l<=.001||r>=length-.001||r-l<=.001||Math.Abs((left-a).Dot(u.Perp))>.001||Math.Abs((right-a).Dot(u.Perp))>.001)
                throw new InvalidOperationException("Diem cat khong hop le; giu nguyen MLINE.");
            return new[]{vertices.Take(segment+1).Concat(new[]{left}).ToArray(),new[]{right}.Concat(vertices.Skip(segment+1)).ToArray()};
        }
        public static bool MatchesWidth(double actual,int dn)
        {
            double od=ValveCatalog.Outside(dn);
            double steel=dn==200?219.1:dn==250?273.0:dn==300?323.8:od;
            return dn>0&&(Math.Abs(actual-dn)<=Math.Max(.5,dn*.015)||Math.Abs(actual-od)<=Math.Max(1.5,od*.02)||Math.Abs(actual-steel)<=Math.Max(1.5,steel*.02));
        }
    }
}
