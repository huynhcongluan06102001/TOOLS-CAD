using System;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.Runtime;
using AcApp=Autodesk.AutoCAD.ApplicationServices.Core.Application;
namespace ToolsCad
{
    public static partial class Upvc2Bridge
    {
        // One transaction per drag, not one transaction/COM call per mouse event.
        private sealed class ValveJig : EntityJig
        {
            private readonly ValveSession session;
            private readonly Transaction transaction;
            private readonly bool rotating;
            private readonly double basis;
            private Point3d last;
            private bool sampled;private double lastAngle=double.NaN;
            public Point3d Point {get;private set;}
            public PromptStatus InputStatus;public string Keyword;
            public ValveJig(BlockReference b,ValveSession s,Transaction tr,bool rotate):base(b)
            {session=s;transaction=tr;rotating=rotate;basis=ValveUcsAngle();Point=b.Position;}
            protected override SamplerStatus Sampler(JigPrompts prompts)
            {
                var options=new JigPromptPointOptions(rotating?
                    "\nXoay theo buoc 45 do, click chot; Space doi trang thai [Angle]: ":
                    "\nChon diem dat van (OSNAP); Space doi trang thai: ");
                options.UserInputControls=UserInputControls.Accept3dCoordinates|UserInputControls.NullResponseAccepted;
                if(rotating){options.BasePoint=P(session.Anchor);options.UseBasePoint=true;options.Keywords.Add("Angle");}
                var result=prompts.AcquirePoint(options);InputStatus=result.Status;Keyword=result.StringResult;
                if(result.Status!=PromptStatus.OK)return SamplerStatus.Cancel;
                Point=result.Value;
                if(rotating) {
                    var d=V(Point)-session.Anchor;
                    double angle=DesiredAngle(d);
                    if(sampled&&Math.Abs(angle-lastAngle)<1e-10)return SamplerStatus.NoChange;
                    lastAngle=angle;
                }
                if(sampled&&Point.DistanceTo(last)<1e-6)return SamplerStatus.NoChange;
                last=Point;sampled=true;return SamplerStatus.OK;
            }
            private double DesiredAngle(U2Point d)
            {
                double raw=Math.Atan2(d.Y,d.X);
                return session.Pipe.IsNull?ValveGeometry.Snap45(raw,basis):
                    session.PipeAngle-session.PortAngle+(Math.Cos(raw-session.PipeAngle)<0?Math.PI:0);
            }
            protected override bool Update()
            {
                var b=(BlockReference)Entity;
                if(!rotating)ValvePose(b,Point,0,transaction);
                else {
                    var d=V(Point)-session.Anchor;if(d.Length<1e-6)return true;
                    double angle=DesiredAngle(d);
                    var offset=!session.Pipe.IsNull&&session.PortsValid?(session.PortA+session.PortB)/2:new U2Point();
                    ValvePose(b,P(session.Anchor-PlusGeometry.Rotate(offset,angle)),angle,transaction);
                }
                return true;
            }
        }
        private static ResultBuffer ValveArguments(params object[] values)
        {
            var result=new ResultBuffer();foreach(var v in values)
                result.Add(new TypedValue(v is string?(int)LispDataType.Text:(int)LispDataType.Double,v));
            return result;
        }
        [LispFunction("TC_VALVE_INTERACT_029")]
        public static string ValveInteract(ResultBuffer args)=>ValveCall(()=>{
            var values=args.AsArray();string handle=(string)values[0].Value;
            double overlap=Number(values[1].Value),tolerance=Number(values[2].Value);
            var s=ValveActive(handle);var ed=AcApp.DocumentManager.MdiActiveDocument.Editor;
            int snaps=Convert.ToInt32(AcApp.GetSystemVariable("OSMODE"));
            // Dense dynamic blocks make running intersection snaps very expensive.
            // Keep native point acquisition; never call Lisp osnap in a mouse loop.
            AcApp.SetSystemVariable("OSMODE",(snaps & ~(32|2048))|512);
            try {
                bool rotating=false;
                while(true) {
                    PromptResult response;Point3d point;PromptStatus input;string keyword;
                    using(var tr=s.Db.TransactionManager.StartTransaction()) {
                        var b=(BlockReference)tr.GetObject(s.Id,OpenMode.ForWrite);
                        var jig=new ValveJig(b,s,tr,rotating);response=ed.Drag(jig);point=jig.Point;input=jig.InputStatus;keyword=jig.Keyword;tr.Commit();
                    }
                    if(input==PromptStatus.None) {
                        using(var a=ValveArguments(handle))ed.WriteMessage("\n"+ValveCycle(a));continue;
                    }
                    if(rotating&&input==PromptStatus.Keyword&&keyword=="Angle") {
                        string result;using(var a=ValveArguments(handle))result=ValveAngle(a);
                        if(result!="OK"){if(result.StartsWith("ERROR:"))ed.WriteMessage("\n"+result);continue;}
                    }else {
                        if(response.Status!=PromptStatus.OK)return "CANCEL";
                        if(!rotating) {
                            string pick;using(var a=ValveArguments(handle,point.X,point.Y,tolerance))pick=ValvePick(a);
                            if(pick.StartsWith("ERROR:")){ed.WriteMessage("\n"+pick);continue;}
                            rotating=true;continue;
                        }
                    }
                    string end;using(var a=ValveArguments(handle,"1",overlap))end=ValveEnd(a);
                    if(end=="OK")return "OK";
                    ed.WriteMessage("\n"+end);
                }
            }finally{AcApp.SetSystemVariable("OSMODE",snaps);}
        });
    }
}
