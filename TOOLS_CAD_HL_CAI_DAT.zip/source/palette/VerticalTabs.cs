using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace ToolsCad
{
    // A single scrollable strip keeps the tabs on the right even in a short docked palette.
    internal sealed class VerticalTabs : UserControl
    {
        private readonly Panel deck = new Panel { Dock = DockStyle.Fill };
        private readonly FlowLayoutPanel strip = new FlowLayoutPanel
        {
            Dock = DockStyle.Right, Width = 46, AutoScroll = true,
            FlowDirection = FlowDirection.TopDown, WrapContents = false, Padding = new Padding(1)
        };
        private readonly List<Panel> pages = new List<Panel>();
        private readonly List<SideButton> buttons = new List<SideButton>();
        private readonly ToolTip tips = new ToolTip();
        private int selected = -1;
        public IReadOnlyList<Panel> TabPages => pages;
        public event EventHandler SelectedIndexChanged;
        public VerticalTabs() { Controls.Add(deck); Controls.Add(strip); }
        public void AddPage(Panel page, string title)
        {
            int index = pages.Count; pages.Add(page); page.Dock = DockStyle.Fill; page.Visible = false; deck.Controls.Add(page);
            var button = new SideButton { Caption = title, Width = 24, Height = 78, Margin = new Padding(1, 0, 1, 1), AccessibleName = title };
            tips.SetToolTip(button, title); button.Click += (s, e) => SelectedIndex = index;
            buttons.Add(button); strip.Controls.Add(button);
            if (selected < 0) SelectedIndex = 0;
        }
        public int SelectedIndex
        {
            get => selected;
            set
            {
                if (value < 0 || value >= pages.Count || value == selected) return;
                selected = value;
                for (int i = 0; i < pages.Count; i++)
                {
                    pages[i].Visible = i == value; buttons[i].Selected = i == value; buttons[i].Invalidate();
                }
                pages[value].BringToFront(); SelectedIndexChanged?.Invoke(this, EventArgs.Empty);
            }
        }
        protected override void Dispose(bool disposing) { if (disposing) tips.Dispose(); base.Dispose(disposing); }
        private sealed class SideButton : Button
        {
            public string Caption { get; set; }
            public bool Selected { get; set; }
            protected override void OnPaint(PaintEventArgs e)
            {
                e.Graphics.Clear(Selected ? Color.FromArgb(210, 230, 249) : SystemColors.Control);
                ControlPaint.DrawBorder(e.Graphics, ClientRectangle, Selected ? Color.SteelBlue : SystemColors.ControlDark, ButtonBorderStyle.Solid);
                var state = e.Graphics.Save(); e.Graphics.TranslateTransform(Width / 2F, Height / 2F); e.Graphics.RotateTransform(90);
                using (var brush = new SolidBrush(ForeColor))
                using (var format = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center, Trimming = StringTrimming.EllipsisCharacter })
                    e.Graphics.DrawString(Caption, Font, brush, new RectangleF(-Height / 2F + 2, -Width / 2F, Height - 4, Width), format);
                e.Graphics.Restore(state);
                if (Focused) ControlPaint.DrawFocusRectangle(e.Graphics, Rectangle.Inflate(ClientRectangle, -3, -3));
            }
        }
    }
}
