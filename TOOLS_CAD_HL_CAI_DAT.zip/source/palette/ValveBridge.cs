using System;
using System.IO;
using System.Linq;
using System.Globalization;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.EditorInput;
using AcApp=Autodesk.AutoCAD.ApplicationServices.Core.Application;
namespace ToolsCad
{
    public static partial class Upvc2Bridge
    {
        private sealed class ValveSession
        {
            public Database Db;public ObjectId Id,Pipe;public ValveGroup Group;public ValveSize Size;
            public U2Point Anchor,PortA,PortB,PipeShift,Center;public int PipeSegment;public double PipeAngle,PortAngle;public bool Positioned,PortsValid;
        }
        private static Database valveSource;
        private static string valveSourcePath;
        private static DateTime valveSourceWrite;
        private static long valveSourceLength;
        private static Database ValveSource(string path)
        {
            var info=new FileInfo(Path.GetFullPath(path));
            if(valveSource!=null&&string.Equals(valveSourcePath,info.FullName,StringComparison.OrdinalIgnoreCase)
                &&valveSourceWrite==info.LastWriteTimeUtc&&valveSourceLength==info.Length)return valveSource;
            var next=new Database(false,true);
            try {next.ReadDwgFile(info.FullName,FileOpenMode.OpenForReadAndAllShare,true,null);next.CloseInput(true);}
            catch {next.Dispose();throw;}
            valveSource?.Dispose();valveSource=next;valveSourcePath=info.FullName;
            valveSourceWrite=info.LastWriteTimeUtc;valveSourceLength=info.Length;return next;
        }
        private static ValveSession valve;
        private static ValveSession ValveActive(string handle)
        {Need(valve!=null&&valve.Db==AcApp.DocumentManager.MdiActiveDocument.Database&&valve.Id.Handle.ToString()==handle,"Luot dat van da ket thuc.");return valve;}
        private static string ValveCall(Func<string> action)
        {try{return action();}catch(System.Exception ex){return "ERROR: "+ex.Message;}}
        [LispFunction("TC_VALVE_BEGIN_027")]
        public static string ValveBegin(ResultBuffer args)=>ValveCall(()=>{
            Need(valve==null,"Ket thuc luot dat van truoc.");var v=args.AsArray();string path=(string)v[0].Value,key=(string)v[1].Value;int dn=(int)Number(v[2].Value);
            var group=ValveCatalog.Group(key);var spec=ValveCatalog.Size(key,dn);Need(File.Exists(path),"Chon/nap thu vien VALVES truoc.");
            var db=AcApp.DocumentManager.MdiActiveDocument.Database;ObjectId inserted;
            var source=ValveSource(path);
            {
                using(var tr=source.TransactionManager.StartOpenCloseTransaction()) {
                    var space=(BlockTableRecord)tr.GetObject(SymbolUtilityServices.GetBlockModelSpaceId(source),OpenMode.ForRead);
                    var sample=space.Cast<ObjectId>().Select(id=>tr.GetObject(id,OpenMode.ForRead)).OfType<BlockReference>()
                        .Where(b=>string.Equals(Name(b,tr),spec.name,StringComparison.OrdinalIgnoreCase)).OrderBy(b=>(V(b.Position)-new U2Point(spec.x,spec.y)).Length).FirstOrDefault();
                    Need(sample!=null,"Thu vien thieu block mau da chen: "+spec.name+". Can file bang van co cac mau size.");
                    var map=new IdMapping();source.WblockCloneObjects(new ObjectIdCollection(new[]{sample.ObjectId}),SymbolUtilityServices.GetBlockModelSpaceId(db),map,DuplicateRecordCloning.Ignore,false);inserted=map[sample.ObjectId].Value;
                }
            }
            try {
                using(var tr=db.TransactionManager.StartTransaction()) {
                    var block=(BlockReference)tr.GetObject(inserted,OpenMode.ForWrite);ValvePose(block,Point3d.Origin,0,tr);block.LayerId=db.Clayer;block.ColorIndex=256;
                    Meta(block,tr,db,"TC_SYSTEM","VALVES");Meta(block,tr,db,"TC_FITTING","1");Meta(block,tr,db,"TC_VALVE",group.key);Meta(block,tr,db,"TC_DN",dn.ToString(CultureInfo.InvariantCulture));
                    tr.Commit();
                }
                valve=new ValveSession{Db=db,Id=inserted,Group=group,Size=spec,Pipe=ObjectId.Null};
                using(var tr=db.TransactionManager.StartTransaction()) {
                    ValveMeasure((BlockReference)tr.GetObject(inserted,OpenMode.ForWrite),valve,tr);tr.Commit();
                }
                return inserted.Handle.ToString();
            }catch{valve=null;using(var tr=db.TransactionManager.StartTransaction()){tr.GetObject(inserted,OpenMode.ForWrite).Erase();tr.Commit();}throw;}
        });
        private static DynamicBlockReferenceProperty ValveState(BlockReference block)
        {
            if(!block.IsDynamicBlock)return null;
            var states=block.DynamicBlockReferencePropertyCollection.Cast<DynamicBlockReferenceProperty>()
                .Where(p=>!p.ReadOnly&&p.Value is string&&p.GetAllowedValues().OfType<string>().Any()).ToArray();
            return states.OrderByDescending(p=>p.PropertyName.IndexOf("vis",StringComparison.OrdinalIgnoreCase)>=0).FirstOrDefault();
        }
        private static void ValvePose(BlockReference block,Point3d point,double rotation,Transaction tr)
        {
            var before=block.BlockTransform;block.Position=point;block.Rotation=rotation;
            var delta=block.BlockTransform*before.Inverse();
            foreach(ObjectId id in block.AttributeCollection)
                ((AttributeReference)tr.GetObject(id,OpenMode.ForWrite)).TransformBy(delta);
        }
        private static Extents3d ValveBody(BlockReference block)
        {
            Extents3d? bounds=null;
            void Walk(Entity e,int depth)
            {
                if(!e.Visible||e is DBText||e is MText||e is Dimension||e is AttributeDefinition)return;
                if(e is BlockReference nested&&depth<8) {
                    using(var children=new DBObjectCollection()) {
                        nested.Explode(children);
                        foreach(DBObject child in children)using(child)if(child is Entity entity)Walk(entity,depth+1);
                    }
                }else {
                    try {var ext=e.GeometricExtents;if(bounds.HasValue){var current=bounds.Value;current.AddExtents(ext);bounds=current;}else bounds=ext;}
                    catch(Autodesk.AutoCAD.Runtime.Exception ex) when(ex.ErrorStatus==ErrorStatus.NullExtents) { }
                }
            }
            Walk(block,0);Need(bounds.HasValue,"Khong doc duoc duong bao than block.");return bounds.Value;
        }
        private static void ValvePorts(BlockReference block,ValveSession s,Transaction tr)
        {
            s.PortsValid=false;s.PortAngle=0;
            var pos=block.Position;double angle=block.Rotation;
            try {
                ValvePose(block,Point3d.Origin,0,tr);
                if(!s.Group.inline) {
                    var ext=ValveBody(block);
                    Need(ext.MaxPoint.X-ext.MinPoint.X>.01,"Than block khong co chieu rong de cat ong.");
                    s.PortA=new U2Point(ext.MinPoint.X,0);s.PortB=new U2Point(ext.MaxPoint.X,0);s.Center=(s.PortA+s.PortB)/2;s.PortsValid=true;return;
                }
                var ports=ValveGeometry.Ports(Faces(block,ValveCatalog.Outside(s.Size.dn),.65,6,true),ValveCatalog.Outside(s.Size.dn));
                s.PortA=ports.A;s.PortB=ports.B;s.Center=(ports.A+ports.B)/2;s.PortAngle=Math.Atan2(ports.B.Y-ports.A.Y,ports.B.X-ports.A.X);s.PortsValid=true;
            }finally{ValvePose(block,pos,angle,tr);}
        }
        private static void ValveMeasure(BlockReference block,ValveSession s,Transaction tr)
        {
            try {ValvePorts(block,s,tr);}
            catch(InvalidOperationException) {
                s.PortsValid=false;
                var at=block.Position;double angle=block.Rotation;
                try {ValvePose(block,Point3d.Origin,0,tr);var ext=ValveBody(block);s.Center=(V(ext.MinPoint)+V(ext.MaxPoint))/2;}
                finally {ValvePose(block,at,angle,tr);}
            }
        }
        [LispFunction("TC_VALVE_STATE_027")]
        public static string ValveCycle(ResultBuffer args)=>ValveCall(()=>{
            var s=ValveActive((string)args.AsArray()[0].Value);
            string state;U2Point anchor;
            using(var tr=s.Db.TransactionManager.StartTransaction()) {
                var block=(BlockReference)tr.GetObject(s.Id,OpenMode.ForWrite);var property=ValveState(block);
                if(property==null)return "Block chi co mot trang thai.";
                anchor=s.Positioned?s.Anchor:V(block.Position)+PlusGeometry.Rotate(s.Center,block.Rotation);
                var options=property.GetAllowedValues().OfType<string>().ToArray();int index=Array.IndexOf(options,(string)property.Value);
                property.Value=options[(index+1)%options.Length];state=(string)property.Value;
                block.RecordGraphicsModified(true);tr.Commit();
            }
            // Read evaluated geometry only after the visibility change is committed.
            using(var tr=s.Db.TransactionManager.StartTransaction()) {
                var block=(BlockReference)tr.GetObject(s.Id,OpenMode.ForWrite);
                ValveMeasure(block,s,tr);
                {
                    double angle=!s.Pipe.IsNull&&s.PortsValid?s.PipeAngle-s.PortAngle+
                        (Math.Cos(block.Rotation+s.PortAngle-s.PipeAngle)<0?Math.PI:0):block.Rotation;
                    ValvePose(block,P(anchor-PlusGeometry.Rotate(s.Center,angle)),angle,tr);
                }
                if(!s.Pipe.IsNull&&!s.PortsValid)state+=" - chon trang thai co cong noi de cat ong";
                block.RecordGraphicsModified(true);tr.Commit();
            }
            return state;
        });
        [LispFunction("TC_VALVE_MOVE_027")]
        public static string ValveMove(ResultBuffer args)=>ValveCall(()=>{
            var v=args.AsArray();var s=ValveActive((string)v[0].Value);var point=new U2Point(Number(v[1].Value),Number(v[2].Value));bool rotating=(string)v[3].Value=="1";
            using(var tr=s.Db.TransactionManager.StartTransaction()) {
                var block=(BlockReference)tr.GetObject(s.Id,OpenMode.ForWrite);
                if(!rotating){ValvePose(block,P(point),0,tr);}
                else {
                    var delta=point-s.Anchor;double angle=delta.Length>.0001?ValveGeometry.Rotation(delta,Convert.ToInt32(AcApp.GetSystemVariable("ORTHOMODE"))==1,ValveUcsAngle()):block.Rotation;
                    if(!s.Pipe.IsNull)angle=s.PipeAngle-s.PortAngle+(Math.Cos(angle-s.PipeAngle)<0?Math.PI:0);
                    var offset=s.Center;
                    ValvePose(block,P(s.Anchor-PlusGeometry.Rotate(offset,angle)),angle,tr);
                }
                block.RecordGraphicsModified(true);tr.Commit();
                s.Db.TransactionManager.QueueForGraphicsFlush();AcApp.DocumentManager.MdiActiveDocument.Editor.UpdateScreen();return "OK";
            }
        });
        private static double ValveUcsAngle()
        {
            var axis=Vector3d.XAxis.TransformBy(AcApp.DocumentManager.MdiActiveDocument.Editor.CurrentUserCoordinateSystem);
            return Math.Atan2(axis.Y,axis.X)+Convert.ToDouble(AcApp.GetSystemVariable("SNAPANG"));
        }
        [LispFunction("TC_VALVE_ANGLE_028")]
        public static string ValveAngle(ResultBuffer args)=>ValveCall(()=>{
            var s=ValveActive((string)args.AsArray()[0].Value);var ed=AcApp.DocumentManager.MdiActiveDocument.Editor;
            var options=new PromptAngleOptions("\nGoc xoay (nhap 90/180 hoac chon diem; F8 vuong goc): ")
                {BasePoint=P(s.Anchor),UseBasePoint=true,AllowNone=false};
            var result=ed.GetAngle(options);if(result.Status!=PromptStatus.OK)return "CANCEL";
            double angle=result.Value;
            // Inline valves must retain their flow axis; perpendicular free placement is unrestricted.
            if(!s.Pipe.IsNull) {
                double aligned=s.PipeAngle-s.PortAngle+(Math.Cos(angle+s.PortAngle-s.PipeAngle)<0?Math.PI:0);
                Need(Math.Abs(Math.Sin(angle-aligned))<.001,"Van noi MLINE phai doc tim ong. Dat ngoai ong de xoay tu do.");
                angle=aligned;
            }
            using(var tr=s.Db.TransactionManager.StartTransaction()) {
                var b=(BlockReference)tr.GetObject(s.Id,OpenMode.ForWrite);
                var offset=s.Center;
                ValvePose(b,P(s.Anchor-PlusGeometry.Rotate(offset,angle)),angle,tr);b.RecordGraphicsModified(true);tr.Commit();
            }
            ed.UpdateScreen();return "OK";
        });
        [LispFunction("TC_VALVE_PICK_027")]
        public static string ValvePick(ResultBuffer args)=>ValveCall(()=>{
            var v=args.AsArray();var s=ValveActive((string)v[0].Value);var pick=new U2Point(Number(v[1].Value),Number(v[2].Value));double tolerance=Number(v[3].Value);
            using(var tr=s.Db.TransactionManager.StartTransaction()) {
                var block=(BlockReference)tr.GetObject(s.Id,OpenMode.ForWrite);var space=(BlockTableRecord)tr.GetObject(block.OwnerId,OpenMode.ForRead);
                Mline best=null;U2Point on=pick,shift=new U2Point();int segment=0;double cost=double.MaxValue;
                foreach(ObjectId id in space) {
                    if(!(tr.GetObject(id,OpenMode.ForRead) is Mline pipe)||pipe.NumberOfVertices<2||pipe.IsClosed||!pipe.Visible)continue;
                    var layer=(LayerTableRecord)tr.GetObject(pipe.LayerId,OpenMode.ForRead);
                    if(layer.IsOff||layer.IsFrozen)continue;
                    var st=(MlineStyle)tr.GetObject(pipe.Style,OpenMode.ForRead);
                    var offsets=st.Elements.Cast<MlineStyleElement>().Select(e=>e.Offset*pipe.Scale).ToArray();
                    if(offsets.Length<2)continue;
                    double lo=offsets.Min(),hi=offsets.Max(),width=hi-lo;
                    double center=(lo+hi)/2-(pipe.Justification==MlineJustification.Top?hi:pipe.Justification==MlineJustification.Bottom?lo:0);
                    for(int i=0;i<pipe.NumberOfVertices-1;i++) {
                        var a=V(pipe.VertexAt(i));var b=V(pipe.VertexAt(i+1));if((b-a).Length<.001)continue;
                        var u=(b-a).Unit;var offset=u.Perp*(center*(pipe.Normal.Z<0?-1:1));
                        double along=(pick-a-offset).Dot(u);if(along<0||along>(b-a).Length)continue;
                        var q=a+offset+u*along;double distance=(q-pick).Length;
                        if(distance<=width/2+tolerance&&distance<cost){best=pipe;cost=distance;on=q;shift=offset;segment=i;}
                    }
                }
                s.Pipe=ObjectId.Null;s.Anchor=pick;s.Positioned=true;
                if(best!=null) {
                    Need(!((LayerTableRecord)tr.GetObject(best.LayerId,OpenMode.ForRead)).IsLocked,"MLINE tren layer khoa.");
                    Need(best.Scale>0&&Enumerable.Range(0,best.NumberOfVertices).All(i=>Math.Abs(best.VertexAt(i).Z)<.001)&&best.Normal.IsParallelTo(Vector3d.ZAxis),"MLINE can nam WCS XY, Z=0.");
                    if(s.Group.inline) {
                        var st=(MlineStyle)tr.GetObject(best.Style,OpenMode.ForRead);var offsets=st.Elements.Cast<MlineStyleElement>().Select(e=>e.Offset).ToArray();
                        double width=Upvc2Geometry.Width(best.Scale,offsets.Min(),offsets.Max());
                        Need(ValveGeometry.MatchesWidth(width,s.Size.dn),"Size van khong khop MLINE. Chon lai DN dung voi ong.");
                    }
                    ValvePorts(block,s,tr);
                    s.Pipe=best.ObjectId;s.Anchor=on;s.PipeShift=shift;s.PipeSegment=segment;var axis=V(best.VertexAt(segment+1))-V(best.VertexAt(segment));s.PipeAngle=Math.Atan2(axis.Y,axis.X);block.LayerId=best.LayerId;
                    var offset=s.Center;double rotation=s.PipeAngle-s.PortAngle;ValvePose(block,P(on-PlusGeometry.Rotate(offset,rotation)),rotation,tr);
                }else{
                    double rotation=0;double nearest=tolerance;
                    foreach(ObjectId id in space) {
                        if(!(tr.GetObject(id,OpenMode.ForRead) is Line line)||Math.Abs(line.StartPoint.Z)>.001||Math.Abs(line.EndPoint.Z)>.001)continue;
                        var q=line.GetClosestPointTo(P(pick),false);double distance=q.DistanceTo(P(pick));
                        if(distance<=nearest) {nearest=distance;s.Anchor=V(q);var d=line.EndPoint-line.StartPoint;rotation=Math.Atan2(d.Y,d.X);}
                    }
                    ValvePose(block,P(s.Anchor-PlusGeometry.Rotate(s.Center,rotation)),rotation,tr);
                }
                block.RecordGraphicsModified(true);tr.Commit();
                s.Db.TransactionManager.QueueForGraphicsFlush();AcApp.DocumentManager.MdiActiveDocument.Editor.UpdateScreen();return "OK";
            }
        });
        [LispFunction("TC_VALVE_END_027")]
        public static string ValveEnd(ResultBuffer args)=>ValveCall(()=>{
            var v=args.AsArray();var s=ValveActive((string)v[0].Value);bool commit=(string)v[1].Value=="1";double overlap=Number(v[2].Value);
            try {
                using(var tr=s.Db.TransactionManager.StartTransaction()) {
                    var block=(BlockReference)tr.GetObject(s.Id,OpenMode.ForWrite);
                    if(!commit)block.Erase();
                    else {
                        Need(s.Positioned,"Chua chon diem dat van.");
                        if(!s.Pipe.IsNull) {
                            Need(s.PortsValid,"Trang thai khong co hai cong noi; khong cat ong.");
                            var pipe=(Mline)tr.GetObject(s.Pipe,OpenMode.ForWrite);Need(!((LayerTableRecord)tr.GetObject(pipe.LayerId,OpenMode.ForRead)).IsLocked,"Layer ong dang khoa.");
                            var a=V(pipe.VertexAt(s.PipeSegment))+s.PipeShift;var b=V(pipe.VertexAt(s.PipeSegment+1))+s.PipeShift;var origin=V(block.Position);
                            var cut=ValveGeometry.Cut(a,b,origin+PlusGeometry.Rotate(s.PortA,block.Rotation),origin+PlusGeometry.Rotate(s.PortB,block.Rotation),overlap);
                            var space=(BlockTableRecord)tr.GetObject(pipe.OwnerId,OpenMode.ForWrite);
                            var vertices=Enumerable.Range(0,pipe.NumberOfVertices).Select(i=>V(pipe.VertexAt(i))).ToArray();
                            var pieces=ValveGeometry.SplitRoute(vertices,s.PipeSegment,cut.Left,cut.Right,s.PipeShift);
                            foreach(var points in pieces) {
                                // Rebuild with the original style instead of collapsing a cloned MLINE to one vertex.
                                var piece=new Mline();
                                try {
                                    piece.SetDatabaseDefaults(s.Db);piece.SetPropertiesFrom(pipe);
                                    space.AppendEntity(piece);tr.AddNewlyCreatedDBObject(piece,true);
                                    piece.Normal=pipe.Normal;piece.Style=pipe.Style;piece.Scale=pipe.Scale;
                                    piece.Justification=pipe.Justification;
                                    piece.SupressStartCaps=pipe.SupressStartCaps;piece.SupressEndCaps=pipe.SupressEndCaps;
                                    foreach(var point in points)piece.AppendSegment(P(point));
                                    using(var data=pipe.XData)if(data!=null)piece.XData=data;
                                    Need(piece.NumberOfVertices==points.Length&&piece.Style==pipe.Style&&Math.Abs(piece.Scale-pipe.Scale)<1e-9,
                                        "Khong tao duoc MLINE thay the; giu nguyen ong goc.");
                                    for(int i=0;i<points.Length;i++)Need((V(piece.VertexAt(i))-points[i]).Length<.001,
                                        "Dinh MLINE thay the sai; giu nguyen ong goc.");
                                    Need(points.Zip(points.Skip(1),(x,y)=>(y-x).Length).All(length=>length>.001),
                                        "Doan ong con lai qua ngan; giu nguyen ong goc.");
                                    var ext=piece.GeometricExtents;
                                    Need(ext.MaxPoint.DistanceTo(ext.MinPoint)>.001,"MLINE thay the rong; giu nguyen ong goc.");
                                    piece.RecordGraphicsModified(true);
                                }catch {if(piece.ObjectId.IsNull)piece.Dispose();throw;}
                            }
                            pipe.Erase();
                        }
                    }
                    tr.Commit();
                }
                valve=null;return "OK";
            }catch{throw;}
        });
        [LispFunction("TC_VALVE_RESET_027")]
        public static string ValveReset(ResultBuffer args)=>ValveCall(()=>{
            var old=valve;valve=null;
            if(old!=null&&!old.Id.IsErased)using(var tr=old.Db.TransactionManager.StartTransaction()) {
                tr.GetObject(old.Id,OpenMode.ForWrite).Erase();tr.Commit();
            }
            AcApp.DocumentManager.MdiActiveDocument.Editor.Regen();
            return "OK";
        });
    }
}
