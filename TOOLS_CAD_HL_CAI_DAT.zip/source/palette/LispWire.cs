using System;
using System.Text;
using System.Collections.Generic;
using System.Globalization;
namespace ToolsCad
{
    public static class LispWire
    {
        public static string Encode(Dictionary<string, object> data)
        {
            var text = new StringBuilder(); EncodeDictionary(text, data); return text.ToString();
        }
        private static string Quote(string text) => "\"" + text.Replace("\\", "\\\\").Replace("\"", "\\\"")
            .Replace("\r", "\\r").Replace("\n", "\\n").Replace("\t", "\\t").Replace("\0", "") + "\"";
        private static void EncodeDictionary(StringBuilder text, Dictionary<string, object> data)
        {
            text.Append('(');
            foreach (var pair in data)
            {
                text.Append('(').Append(Quote(pair.Key)).Append(' ');
                if (pair.Value is Dictionary<string, object> nested) EncodeDictionary(text, nested);
                else if (pair.Value is double number) text.Append(number.ToString("0.0###############", CultureInfo.InvariantCulture));
                else text.Append(Quote(pair.Value?.ToString() ?? ""));
                text.Append(')');
            }
            text.Append(')');
        }
    }
}
