using System.Reflection;
using System.Runtime.Versioning;
[assembly: AssemblyTitle("Tools Cad HL")]
[assembly: AssemblyDescription("Dockable system palettes for AutoCAD 2024 Windows")]
[assembly: AssemblyVersion("0.11.0.0")]
[assembly: AssemblyFileVersion("0.11.0.0")]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
