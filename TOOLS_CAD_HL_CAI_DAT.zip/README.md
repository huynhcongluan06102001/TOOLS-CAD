# Tools Cad HL — AutoCAD 2024 Windows

Chương trình sử dụng: **ToolsCadHL.lsp**. File này nhúng mã AutoLISP, giao diện .NET PaletteSet và DCL dự phòng. Không cần VBA Enabler. Template vẫn là **template CAd Duy.dwg** bạn đang có; chương trình không sửa DWG này.

## Cài đặt / nâng cấp

1. Nếu đã nạp bản cũ, đóng và mở lại AutoCAD để tránh giữ DLL giao diện cũ trong bộ nhớ.
2. Giải nén ZIP, lưu `ToolsCadHL.lsp` vào một thư mục cố định trên máy Windows.
3. Mở AutoCAD 2024 bản đầy đủ, gõ `APPLOAD`, chọn LSP.
4. Gõ `TCTEMPLATE`, chọn **template CAd Duy.dwg gốc trên máy**. Gói cài đặt không kèm DWG.
5. Gõ `TOOLS`. Lần đầu, LSP giải nén DLL giao diện của công cụ vào `%APPDATA%/ToolsCadHL/2024/<hash>/` và gọi `NETLOAD`. Nếu AutoCAD hỏi, cho phép nạp đúng DLL này; có thể thêm đúng thư mục công cụ vào Trusted Locations. Chương trình giữ nguyên cơ chế bảo mật AutoCAD.
6. Kéo thanh tiêu đề bảng đến mép trái/phải để dock. Dùng nút ghim của AutoCAD để giữ bảng mở. Các tab dọc bên phải có thể cuộn.

Giao diện chính giữ mở khi chọn điểm/đối tượng. `TCDCL` mở giao diện DCL dự phòng dạng hộp thoại. DCL nguyên bản không có khả năng dock như Properties, nên bảng chính dùng PaletteSet.

## Đặt chạc và phụ kiện trực tiếp

Trong tab **ỐNG GIÓ**, có nhóm **ĐẶT TRỰC TIẾP CHẠC / GÓT GIÀY**. Nhập kích thước ống chính, nhánh và cao trong phần phụ kiện; bấm nút, chọn điểm và hướng đặt. Các lệnh này không cần vẽ sẵn hai tuyến.

| Lệnh | Block / chức năng |
|---|---|
| `TCCHAC3` | Chạc 3 ống gió chữ nhật; bản cách nhiệt/tiêu âm theo vật liệu |
| `TCCHACT` | Chạc chữ T ống gió tròn |
| `TCGOTGIAY` | Chạc chữ T cong / gót giày, theo vật liệu |
| `TCCHACY` | Chạc chữ Y 45° chữ nhật; template có loại không bảo ôn |

Tên trường WIDTH1 trên bảng có nghĩa **ống chính**, WIDTH2 là **nhánh**. Công cụ đổi sang đúng property của block: riêng `Chac 3` dùng native Width2 cho chính và Width1 cho nhánh; `Chac chu T cong` dùng Width1/Width2; T tròn dùng Diameter1/2.

Dropdown **ĐẶT PHỤ KIỆN THỦ CÔNG** của từng hệ có co/lơi, tê, nối giảm và các họ phụ kiện phù hợp. UPVC có 2 lơi lên/xuống, kết trục đứng, Y+lơi lên, van, ren ngoài/trong, thông tắc, thỏ và mặt bích. PPR/HDPE và thép có các họ van/ren/nối từ nguồn VBA. Ống gió có thêm côn lệch, chuyển vuông–tròn, miệng gió, van gió/chặn lửa, chân rẽ, khớp nối mềm, co xuống LCCT theo đúng tên thư viện. Dùng **SỬA THUỘC TÍNH PHỤ KIỆN** (`TCBEDIT`) để sửa các tham số riêng khác, bao gồm AllowedValues.

Một số họ không có đủ mọi cỡ trong template. Khi thiếu block, công cụ báo tên và hoàn tác. UPVC dùng D thực có trong template; không suy đoán D danh nghĩa 125 trong ảnh thành D140. Ký hiệu hai lơi và Y+lơi là hình 2D; Y+lơi yêu cầu chọn thêm điểm đặt lơi.

## Vẽ và nối tuyến

- Mỗi tab lưu riêng vật liệu, kích thước, layer, hệ thống và ghi chú. Kích thước vẽ tuyến và kích thước đặt phụ kiện là hai bộ riêng.
- Vẽ bằng pick hoặc bật Polyline có sẵn. Khi pick có thể sửa D/DN/W/H trên đúng tab đang vẽ; `Size` / `Back` cũng hoạt động tại dòng lệnh.
- Bật tự nối để nối đầu nhánh mới vào tuyến cùng layer/vật liệu. Nối vào giữa tuyến tạo tê/gót giày; đầu tuyến tạo co. Sai số đầu mút tách riêng với sai số nối.
- Nút tự kết phụ kiện cho chọn main rồi các nhánh. Bật “Ngắt / cắt tuyến” để cắt theo mép block. Đặt thủ công sẽ hỏi chọn các đoạn cần cắt; Enter bỏ qua. Ký hiệu đứng và block đặc biệt không tự suy đoán đường cắt.
- `Enter` kết thúc, `Esc` hủy, `U` hoàn tác. `TCINSPECT` đọc property; `TCHELP` in danh sách lệnh.

Có **67 lệnh chức năng, 58 bí danh VBA**. Tab **TẤT CẢ LỆNH** tìm và chạy đủ các lệnh đã đăng ký. Xem `docs/COMMANDS.md` và `docs/COVERAGE.md` để đối chiếu toàn bộ 49 mô-đun nguồn, bao gồm các biến thể gộp chung và phần không phải chức năng vẽ.

## Kiểm thử và giới hạn

Đã biên dịch giao diện x64 bằng API chính thức AutoCAD 2024 / .NET Framework 4.8 và chạy các kiểm tra mã thuần, catalog và gói cài đặt. **Chưa chạy được AutoCAD trên môi trường Linux này**: dock, ActiveX/ObjectDBX, hình học block và Undo thực tế cần nghiệm thu trên máy Windows. Chạy `TCSELFTEST` trong bản vẽ NEW rỗng, rồi làm theo `docs/ACCEPTANCE.md`. Đây là bản 0.10 để nghiệm thu, không tuyên bố đã đạt tương đương 100% VBA.

MEP làm việc trong Model, WCS XY, Z=0; BOP/BOT là ghi chú. Đơn vị mặc định mm. MLINE nối tự động cần hai đỉnh, Justification Zero; block thẳng cần scale X=Y=1. Thép nhập DN, nhựa nhập D ngoài. `LISPSYS=1/2` hỗ trợ CSV Unicode.

Nguồn tham khảo thêm người dùng gửi: https://www.youtube.com/@DuytoolMEP/videos . Phiên này truy cập bị HTTP 403; chưa xem hình/âm thanh/phụ đề video và không dùng video chưa xem để kết luận hành vi.

Mã C# của DLL nhúng được kèm tại `source/palette/` trong ZIP để đối chiếu. Không đóng gói DLL của Autodesk. Hướng dẫn phát triển ở `docs/DEVELOPMENT.md`.
