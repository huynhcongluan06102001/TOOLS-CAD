# Tools Cad HL — AutoCAD 2024 Windows

Chương trình sử dụng: **ToolsCadHL.lsp**. File này nhúng mã AutoLISP, giao diện .NET PaletteSet và DCL dự phòng. Không cần VBA Enabler. Template vẫn là **template CAd Duy.dwg** bạn đang có; chương trình không sửa DWG này.

## Mở đúng bảng dock — bản 0.11

Ảnh kiểm tra của người dùng đang chạy `TCDCL`: đây là hộp dự phòng. Đóng hộp và dùng `HLTOOLS` (hoặc `TOOLS`) để mở PaletteSet. `HLDOCK` mở bảng và ghim bên phải như Properties. Hộp DCL giờ có nút **Mở bảng dock** để chuyển trực tiếp.

1. Đóng/mở lại AutoCAD nếu đã nạp DLL bản cũ. Giải nén ZIP vào một thư mục cố định.
2. `APPLOAD` → **ToolsCadHL.lsp** của gói mới.
3. `HLDOCK` → mở và ghim bảng bên phải. Có thể dùng **Ghim trái / Ghim phải / Thả nổi** ngay trên bảng; kéo tiêu đề để di chuyển.
4. Nếu chưa nạp được DLL: `HLLOAD` → chọn **ToolsCadPalette.dll** nằm ngay cạnh LSP trong ZIP. Chương trình sẽ nạp và mở bảng dock.
5. Nếu cần nạp trực tiếp: `NETLOAD` → ToolsCadPalette.dll, rồi `HLDOCK`. `HLSTATUS` in phiên bản LSP/DLL, đường dẫn DLL, trạng thái hiện/ẩn và dock ra F2.
6. `TCTEMPLATE` → chọn template CAd Duy.dwg cũ trên máy.

DLL 0.11 được kèm riêng trong ZIP và vẫn nhúng trong LSP cho cách cài một file. Khi nạp bản nhúng, file được giải nén vào AppData/ToolsCadHL/2024. Nếu AutoCAD hỏi quyền nạp, xác nhận đúng DLL của công cụ; cơ chế bảo mật AutoCAD được giữ nguyên.

Nếu gõ HLDOCK mà báo Unknown command, bản LSP 0.11 chưa được APPLOAD trong bản vẽ hiện tại. Nếu HLSTATUS cho biết DLL chưa nạp, dùng HLLOAD và ghi lại lỗi F2 nếu vẫn thất bại. `HLPALETTE` là lệnh .NET để mở bảng sau NETLOAD; thao tác vẽ cần LSP đã nạp.

Giao diện chính giữ mở khi chọn điểm/đối tượng. DCL nguyên bản không dock được như Properties, nên bảng chính dùng PaletteSet. Khi nạp DLL, FILEDIA được tạm đặt về chế độ dòng lệnh rồi phục hồi; trạng thái dock/ghim khởi tạo sau khi cửa sổ Palette đã hiện. Lệnh HLDOCK luôn cho phép khôi phục bảng về mép phải.

## Đặt chạc và phụ kiện trực tiếp

Mỗi tab hệ thống có một dropdown **ĐẶT PHỤ KIỆN THỦ CÔNG** và một nút **ĐẶT PHỤ KIỆN** dùng chung cho danh sách:

1. Chọn tab và vật liệu.
2. Xổ danh sách, chọn phụ kiện; ví dụ Chạc 3, Chạc chữ T, Chạc chữ T cong/gót giày hoặc phụ kiện đặc biệt.
3. Nhập D1/D2 hoặc WIDTH1/WIDTH2/HEIGHT; chọn trạng thái và đảo hướng nếu cần.
4. Bấm ĐẶT PHỤ KIỆN, chọn điểm/hướng trên bản vẽ. Công cụ tự lấy tên block và gán thông số.

Chạc 3 hiện khi vật liệu ống gió chữ nhật; Chạc chữ T hiện khi chọn ống tròn. Gót giày, chạc Y và các lựa chọn đặc biệt nằm chung dropdown theo vật liệu. Khi bảng mở, gõ `TCFIT` cũng dùng lựa chọn của tab MEP đang chọn hoặc tab MEP vừa dùng. Không có lệnh riêng cho từng phụ kiện.

Tên trường WIDTH1 trên bảng có nghĩa **ống chính**, WIDTH2 là **nhánh**. Công cụ đổi sang đúng property của block: riêng `Chac 3` dùng native Width2 cho chính và Width1 cho nhánh; `Chac chu T cong` dùng Width1/Width2; T tròn dùng Diameter1/2.

Dropdown **ĐẶT PHỤ KIỆN THỦ CÔNG** của từng hệ có co/lơi, tê, nối giảm và các họ phụ kiện phù hợp. UPVC có 2 lơi lên/xuống, kết trục đứng, Y+lơi lên, van, ren ngoài/trong, thông tắc, thỏ và mặt bích. PPR/HDPE và thép có các họ van/ren/nối từ nguồn VBA. Ống gió có thêm côn lệch, chuyển vuông–tròn, miệng gió, van gió/chặn lửa, chân rẽ, khớp nối mềm, co xuống LCCT theo đúng tên thư viện. Dùng **SỬA THUỘC TÍNH PHỤ KIỆN** (`TCBEDIT`) để sửa các tham số riêng khác, bao gồm AllowedValues.

Một số họ không có đủ mọi cỡ trong template. Khi thiếu block, công cụ báo tên và hoàn tác. UPVC dùng D thực có trong template; không suy đoán D danh nghĩa 125 trong ảnh thành D140. Ký hiệu hai lơi và Y+lơi là hình 2D; Y+lơi yêu cầu chọn thêm điểm đặt lơi.

## Vẽ và nối tuyến

- Mỗi tab lưu riêng vật liệu, kích thước, layer, hệ thống và ghi chú. Kích thước vẽ tuyến và kích thước đặt phụ kiện là hai bộ riêng.
- Vẽ bằng pick hoặc bật Polyline có sẵn. Khi pick có thể sửa D/DN/W/H trên đúng tab đang vẽ; `Size` / `Back` cũng hoạt động tại dòng lệnh.
- Bật tự nối để nối đầu nhánh mới vào tuyến cùng layer/vật liệu. Nối vào giữa tuyến tạo tê/gót giày; đầu tuyến tạo co. Sai số đầu mút tách riêng với sai số nối.
- Nút tự kết phụ kiện cho chọn main rồi các nhánh. Bật “Ngắt / cắt tuyến” để cắt theo mép block. Đặt thủ công sẽ hỏi chọn các đoạn cần cắt; Enter bỏ qua. Ký hiệu đứng và block đặc biệt không tự suy đoán đường cắt.
- `Enter` kết thúc, `Esc` hủy, `U` hoàn tác. `TCINSPECT` đọc property; `TCHELP` in danh sách lệnh.

Có **63 lệnh chức năng, 58 bí danh VBA**. Tab **TẤT CẢ LỆNH** tìm và chạy đủ các lệnh đã đăng ký. Xem `docs/COMMANDS.md` và `docs/COVERAGE.md` để đối chiếu toàn bộ 49 mô-đun nguồn, bao gồm các biến thể gộp chung và phần không phải chức năng vẽ.

## Kiểm thử và giới hạn

Đã biên dịch giao diện x64 bằng API chính thức AutoCAD 2024 / .NET Framework 4.8 và chạy các kiểm tra mã thuần, catalog và gói cài đặt. **Chưa chạy được AutoCAD trên môi trường Linux này**: dock, ActiveX/ObjectDBX, hình học block và Undo thực tế cần nghiệm thu trên máy Windows. Chạy `TCSELFTEST` trong bản vẽ NEW rỗng, rồi làm theo `docs/ACCEPTANCE.md`. Đây là bản 0.11 để nghiệm thu, không tuyên bố đã đạt tương đương 100% VBA.

MEP làm việc trong Model, WCS XY, Z=0; BOP/BOT là ghi chú. Đơn vị mặc định mm. MLINE nối tự động cần hai đỉnh, Justification Zero; block thẳng cần scale X=Y=1. Thép nhập DN, nhựa nhập D ngoài. `LISPSYS=1/2` hỗ trợ CSV Unicode.

Nguồn tham khảo thêm người dùng gửi: https://www.youtube.com/@DuytoolMEP/videos . Phiên này truy cập bị HTTP 403; chưa xem hình/âm thanh/phụ đề video và không dùng video chưa xem để kết luận hành vi.

Mã C# của DLL nhúng được kèm tại `source/palette/` trong ZIP để đối chiếu. Không đóng gói DLL của Autodesk. Hướng dẫn phát triển ở `docs/DEVELOPMENT.md`.
