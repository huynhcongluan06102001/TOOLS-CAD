# Build và kiểm thử mã nguồn

Python 3 và Node.js chỉ dùng để phát triển/đóng gói. AutoCAD không cần chúng.

```sh
# Biên dịch C# trước, bằng dotnet build palette/ToolsCadPalette.csproj trên Windows,
# hoặc tools/build_palette.py với các reference assemblies chính thức trên Linux.
python3 tools/build_release.py
python3 tools/check_sources.py
python3 -m unittest discover -s tests -p 'test_*.py' -v
VELISP_ROOT=/path/to/velisp node tests/run_pure.mjs
```

`build_release.py` nhúng DLL PaletteSet đã biên dịch, DCL và tất cả mô-đun vào `ToolsCadHL.lsp`, tạo registry 67 lệnh/58 alias và dữ liệu danh sách lệnh. Sau khi sửa mã tách trong `lisp/` hoặc giao diện, phải build lại trước khi phân phối.

Trình thông dịch dùng cho các kiểm tra thuần là [VeLisp](https://github.com/ten0s/velisp), commit `77e5a95fadd9bbf6d48cc6dc69d7a0875bf1f33f` (0.8.0). Cài riêng ngoài repository; không đóng gói thư viện này vào sản phẩm. Runner dùng các mô-đun thông dịch/grammar, không cần GTK:

```sh
git clone https://github.com/ten0s/velisp.git /tmp/velisp
git -C /tmp/velisp checkout 77e5a95fadd9bbf6d48cc6dc69d7a0875bf1f33f
npm install --prefix /tmp/velisp-deps antlr4@4.10.1 commander@9.3.0 temp@0.9.4
ln -s /tmp/velisp-deps/node_modules /tmp/velisp/node_modules
VELISP_ROOT=/tmp/velisp node tests/run_pure.mjs
```

VeLisp không phải AutoCAD. Runner bổ sung RTOS/DISTOF tối thiểu, EQUAL có fuzz và ATAN hai đối số theo atan2 vì VeLisp 0.8 chưa có cùng hành vi với AutoCAD. Các tile được mô phỏng riêng để kiểm tra hàm kiểm tra dữ liệu; `snvalid` trong mô phỏng chỉ kiểm tra chuỗi không rỗng. Không dùng mô phỏng này để kết luận ObjectDBX, hình học block, DCL hiển thị, tính hợp lệ đầy đủ của tên layer hoặc Undo hoạt động trong AutoCAD.

## Nguồn dữ liệu DWG

Template gốc có header `AC1032` (định dạng 2018). Đã đọc metadata bằng [LibreDWG](https://github.com/LibreDWG/libredwg), commit `a8ccb1f314d9feb2215be67d1f6f2a3d64b2c9a0`. Bộ đọc báo cảnh báo về dữ liệu ACIS của 3DSOLID; chỉ dùng kết quả để khảo sát tên, tham số block và MLINESTYLE. Không chuyển đổi, ghi lại hay thay thế DWG gốc.

JSON chẩn đoán của bộ đọc có số NaN không hợp lệ và một số byte không phải UTF-8; bản phân tích đã chuẩn hóa phần chẩn đoán đó. Runtime LISP luôn đọc DWG gốc qua ObjectDBX của Autodesk; không dùng JSON khảo sát để tạo hình hay thay thế tên block tại runtime. Các tên MEP ASCII dùng bởi lệnh có kiểm tra tồn tại và các thuộc tính chính được đối chiếu riêng.

`reference/vba/` chứa 49 mô-đun nguyên byte; `inventory.json` lưu hash và danh sách Sub/Function. `template-blocks.json`/`template-properties.json` chỉ là metadata rút gọn. Không kèm `THUVIENUPVC LISP.dwg` theo yêu cầu người dùng.

## Giao diện PaletteSet

`palette/` chứa nguồn .NET Framework 4.8 x64. Package AutoCAD.NET 24.3.0 là API chính thức cho AutoCAD 2024; chỉ dùng lúc compile, không đóng gói DLL Autodesk. `tools/build_palette.py` gọi Roslyn trực tiếp khi Linux không dùng được mutex NuGet; `generate_palette_data.py` tạo catalog từ metadata thực và registry. `build_release.py` nhúng DLL chính công cụ bằng base64 và tên cache theo SHA-256. DLL chỉ được NETLOAD lúc mở TOOLS; không thay SECURELOAD.

Kiểm tra domain dùng mã thật Profiles/LispWire/NativeCatalog trên .NET 8:

```sh
python3 tools/test_palette_domain.py --dotnet /path/dotnet --sdk /path/sdk/8.0.426 --refs /path/packs/Microsoft.NETCore.App.Ref/8.0.32/ref/net8.0
python3 tools/package_release.py
```

Test domain không chạy WinForms/AutoCAD hoặc lưu JSON. JavaScriptSerializer chỉ có shim báo lỗi nếu được gọi, vì API lưu cấu hình đó thuộc .NET Framework Windows. Kiểm tra LISP bổ sung shim VL-STRING-TRIM và mô phỏng riêng kết quả cổng block để kiểm tra số học cắt/extend; chưa đánh giá hình học native block.

Bản ZIP cho người dùng chứa LSP, hướng dẫn và nguồn C#/LISP để đối chiếu; không chứa SDK, DWG hay VBA gốc. Để build lại cần cây mã phát triển và các metadata reference tương ứng.
