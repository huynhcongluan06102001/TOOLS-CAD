# Kiểm tra Tools Cad HL 0.11

Ngày 24/10/2026. Đích: AutoCAD 2024 Windows bản đầy đủ. Môi trường phát triển Linux, không có AutoCAD.

| Kiểm tra | Kết quả |
|---|---|
| Biên dịch giao diện | PASS: C# x64, .NET Framework 4.8, API chính thức AutoCAD 2024 (24.3.0); warnings as errors |
| Cú pháp LISP, tham chiếu nội bộ | PASS: 14 mô-đun, 351 định nghĩa, 130 entry command gồm bí danh và cầu nối |
| Nạp LSP gộp + tính toán thuần | 159 PASS: hình học, phân biệt tee/đầu mút, shoe/Y/cross, Width main/nhánh, cắt/extend, tên fitting, dữ liệu DCL, TCFIT dùng lựa chọn dropdown |
| Domain C# thật | 19 PASS: profile từng hệ, route/manual độc lập, catalog đầy đủ, trạng thái native, dropdown chạc/phụ kiện đặc biệt, encode dữ liệu |
| Kiểm tra gói/template | 12 PASS: 63 lệnh, 58 alias, catalog block native, base64 khớp DLL đã compile, PE x64 và SHA cache, DCL, branding |
| Tổ hợp co cơ bản | 86 tổ hợp tồn tại trong template |
| Nguồn gốc | 49/49 hash VBA và hash DWG khớp bản gốc |
| ZIP | CRC và SHA-256 từng tệp được kiểm tra bởi package_release.py; kèm DLL công cụ; không chứa DWG/VBA/Autodesk DLL |

Các shim của VeLisp và test .NET được mô tả trong DEVELOPMENT.md. Số học cắt tuyến dùng kết quả cổng mô phỏng riêng, không phải chạy hình học block Autodesk.

DWG gốc SHA-256:

```text
e089a2c0831620a744b69017837ff8dd00773a6df2342f15cdbecc71652a925a
```

Chưa chạy: TCSELFTEST (24 bước dự kiến), dock/ghim/kéo bảng và DPI trên Windows; ActiveX/ObjectDBX, import/visibility/hướng fitting, cắt tại cổng block thật, Undo/Esc, lưu profile Windows và quy trình dự án. Không tính các mục này là PASS. Bản 0.11 cần nghiệm thu theo ACCEPTANCE.md.

Kênh tham khảo https://www.youtube.com/@DuytoolMEP/videos truy cập bị HTTP 403 trong phiên này. Chưa xem/nghe video; hành vi được triển khai dựa trên mã VBA, ảnh người dùng và metadata DWG đã đọc.
