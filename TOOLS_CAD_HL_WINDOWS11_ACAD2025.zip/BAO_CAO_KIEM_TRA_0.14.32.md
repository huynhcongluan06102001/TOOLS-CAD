# Kiểm tra 0.14.32

- Build AutoCAD.NET 25 / .NET 8 Windows: 0 error, 0 warning.
- Native Jig có AnyBlankTerminatesInput + NullResponseAccepted; xử lý None
  trước nhánh Cancel, giữ Space ở cùng giai đoạn đặt/xoay.
- Bỏ keyword Angle và nhánh gọi nhập góc; click trái đầu chuyển sang xoay,
  click trái cuối gọi ValveEnd duy nhất và thoát khi thành công.
- Nút van bắt đầu với size hợp lệ hiện tại; chỉ mở chọn size khi không có size
  tương ứng. Thay size thông thường không tự khởi chạy lệnh.
- Kiểm tra tĩnh quy tắc điểm chèn 19 nhóm/176 mẫu; 7 kiểm tra wrapper cleanup.
- Các phép tính và cơ chế tạo MLINE từ 0.14.31 giữ nguyên.
- ZIP/DLL/manifest được kiểm tra checksum và CRC.

Giới hạn: kiểm tra tĩnh không thay thế thử native Jig/Space/chuột trên AutoCAD.
Chưa thực hiện kiểm thử UI hoặc DYNINPUT trên Windows tại môi trường này.
