# TOOLS CAD HL 0.14.35 — Hidden line

Bản tích hợp từ 0.14.34; cần kiểm thử host AutoCAD 2025. Không phải chứng nhận tất cả lệnh hoạt động giống 100%.

- Ô Hidden line dưới Preview; mặc định tắt, lưu preference.
- 425 ánh xạ legacy-name → block-name; kiểm kê từ 820 định nghĩa có tên và 567 mẫu trong DWG người dùng.
- Mẫu scale khác 1 được giữ; giá trị kích thước dynamic lấy từ block mẫu. PPR chọn theo OD, thép theo DN, UPVC theo bảng D cũ.
- Nạp block có tiền tố riêng, tránh ghi đè bộ thường. Không chuyển SCREW thành WELD. Trường hợp thiếu không tự chọn phụ kiện khác.
- Một WIPEOUT cho một MLINE; cùng LayerId, màu ByLayer; thứ tự dưới MLINE. Các block của lượt lệnh nằm trên vùng che.
- Vùng che được cập nhật khi thao tác qua tools, cùng nhóm Undo; liên kết hai chiều tránh xóa vùng che của bản gốc khi clone MLINE.

Kiểm tra đã chạy: build không lỗi/cảnh báo; 22.046 domain assertions; kiểm kê 425 ánh xạ và scale mẫu; LISP mock Hidden lifecycle, shared library, VALVES và STEEL; kiểm tra cấu trúc LISP và ZIP/hash.

Chưa chạy: AutoCAD UI, Wipeout.SetFrom/draw order thực, vòng đời database event/Undo, mọi visibility/flip và vị trí đầu nối của block mới. Build/mock không thay thế các kiểm tra này.

Giới hạn: thư viện gửi chỉ có uPVC/PPR/thép hàn; các tab khác giữ bộ gốc. MLINE mở XY Z=0, đầu thẳng vuông góc, không tự cắt. Sửa MLINE bằng lệnh ngoài tools không tự cập nhật vùng che. Đọc DOC_TRUOC_KHI_CAI_0.14.35.txt trước khi thử trên bản sao DWG.
