# Kiểm tra 0.14.34

Bằng chứng từ ảnh: chỉ nhận hai cổng X; Gate bị từ chối vì cổng lệch tim;
Foot bị từ chối vì khoảng ngậm/vượt đầu ống. Đây là ba điều kiện khác nhau.

Thay đổi:
- Cổng X/Y phải qua điểm chèn, nếu không thì đo khoảng cắt bằng giao điểm
  đường bao hiện hữu trên trục X qua điểm chèn. Không đổi Visibility.
- Đọc Curve trong block/nested block hiện hữu; không đọc text/dimension/
  attribute/wipeout như đường bao. Không chạy osnap/intersect command.
- PlanCut giới hạn khoảng ngậm, hỗ trợ một phần còn lại ở đầu/cuối tuyến,
  bảo vệ trường hợp phủ hết tuyến hoặc vượt đỉnh gấp khúc nội bộ.
- Tạo MLINE thay thế và kiểm tra trước khi Erase nguồn, cùng transaction.
- Tái dùng khoảng cắt đã đo trong session; audit ghi rõ cổng X/Y hoặc thân.

Kiểm tra:
- Build: 0 error, 0 warning.
- 17.862 domain assertions: thêm 277 kiểm tra X/Y, cổng lệch, vòng tròn
  đồng tâm, điểm trùng/không hữu hạn, tám hướng xoay, ba độ lệch canh ống,
  hai đầu tuyến, ngậm lớn, phủ hết ống và chạm góc gấp khúc.
- Wrapper/cleanup và dùng thư viện chung giữ nguyên, kiểm tra đã qua.
- ZIP, checksum, manifest và DLL nhúng được kiểm tra.

Giới hạn: dữ liệu thử hình học tổng hợp không thay thế đánh giá mọi trạng
thái dynamic block trên host. Chưa chạy AutoCAD Windows, native Curve.IntersectWith
hay cắt MLINE trong thư viện tổng mới. Chưa khẳng định mọi trạng thái đều hợp lệ.
