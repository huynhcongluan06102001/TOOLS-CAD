using System;
using System.Linq;
using System.Reflection;
using System.Text.Json;
namespace ToolsCad
{
    public sealed class ValveSize
    {
        public int dn {get;set;}
        public string name {get;set;}
        public double x {get;set;} public double y {get;set;}
        public double sx {get;set;} public double sy {get;set;}
        public double rotation {get;set;}
        public override string ToString()=>dn==0?"Standard": "DN"+dn;
    }
    public sealed class ValveGroup
    {
        public string key {get;set;}
        public string label {get;set;}
        public bool inline {get;set;}
        public ValveSize[] items {get;set;}
    }
    public static class ValveCatalog
    {
        public static readonly ValveGroup[] Groups=Read();
        private static ValveGroup[] Read()
        {
            using(var stream=Assembly.GetExecutingAssembly().GetManifestResourceStream("ToolsCad.ValveCatalog.json"))
                return JsonSerializer.Deserialize<ValveGroup[]>(stream);
        }
        public static ValveGroup Group(string key)=>Groups.FirstOrDefault(g=>g.key==key)??throw new ArgumentException("Loai van khong hop le.");
        public static ValveSize Size(string key,int dn)=>Group(key).items.FirstOrDefault(s=>s.dn==dn)??throw new ArgumentException("Thu vien khong co size van nay.");
        public static double Outside(int dn)
        {
            int[] sizes={15,20,25,32,40,50,65,80,100,125,150,200,250,300};
            double[] outside={21,27,34,42,49,60,76,90,114,140,168,220,280,315};
            int index=Array.IndexOf(sizes,dn);return index<0?0:outside[index];
        }
    }
}
