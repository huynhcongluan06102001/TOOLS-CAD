using System;
using System.IO;
using System.Linq;
using System.Globalization;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.Runtime;
using AcApp=Autodesk.AutoCAD.ApplicationServices.Core.Application;
namespace ToolsCad
{
    public static partial class Upvc2Bridge
    {
        private sealed class ValveSession
        {
            public Database Db;public ObjectId Id,Pipe;public ValveGroup Group;public ValveSize Size;
            public U2Point Anchor,PortA,PortB;public double PipeAngle,PortAngle;public bool Positioned,PortsValid;
        }
        private static ValveSession valve;
        private static ValveSession ValveActive(string handle)
        {Need(valve!=null&&valve.Db==AcApp.DocumentManager.MdiActiveDocument.Database&&valve.Id.Handle.ToString()==handle,"Luot dat van da ket thuc.");return valve;}
        private static string ValveCall(Func<string> action)
        {try{return action();}catch(System.Exception ex){return "ERROR: "+ex.Message;}}
        [LispFunction("TC_VALVE_BEGIN_027")]
        public static string ValveBegin(ResultBuffer args)=>ValveCall(()=>{
            Need(valve==null,"Ket thuc luot dat van truoc.");var v=args.AsArray();string path=(string)v[0].Value,key=(string)v[1].Value;int dn=(int)Number(v[2].Value);
            var group=ValveCatalog.Group(key);var spec=ValveCatalog.Size(key,dn);Need(File.Exists(path),"Chon/nap thu vien VALVES truoc.");
            var db=AcApp.DocumentManager.MdiActiveDocument.Database;ObjectId inserted;
            using(var source=new Database(false,true)) {
                source.ReadDwgFile(path,FileOpenMode.OpenForReadAndAllShare,true,null);source.CloseInput(true);
                using(var tr=source.TransactionManager.StartOpenCloseTransaction()) {
                    var space=(BlockTableRecord)tr.GetObject(SymbolUtilityServices.GetBlockModelSpaceId(source),OpenMode.ForRead);
                    var sample=space.Cast<ObjectId>().Select(id=>tr.GetObject(id,OpenMode.ForRead)).OfType<BlockReference>()
                        .Where(b=>string.Equals(Name(b,tr),spec.name,StringComparison.OrdinalIgnoreCase)).OrderBy(b=>(V(b.Position)-new U2Point(spec.x,spec.y)).Length).FirstOrDefault();
                    Need(sample!=null,"Thu vien thieu block mau da chen: "+spec.name+". Can file bang van co cac mau size.");
                    var map=new IdMapping();source.WblockCloneObjects(new ObjectIdCollection(new[]{sample.ObjectId}),SymbolUtilityServices.GetBlockModelSpaceId(db),map,DuplicateRecordCloning.Ignore,false);inserted=map[sample.ObjectId].Value;
                }
            }
            try {
                using(var tr=db.TransactionManager.StartTransaction()) {
                    var block=(BlockReference)tr.GetObject(inserted,OpenMode.ForWrite);ValvePose(block,Point3d.Origin,0,tr);block.LayerId=db.Clayer;block.ColorIndex=256;
                    Meta(block,tr,db,"TC_SYSTEM","VALVES");Meta(block,tr,db,"TC_FITTING","1");Meta(block,tr,db,"TC_VALVE",group.key);Meta(block,tr,db,"TC_DN",dn.ToString(CultureInfo.InvariantCulture));
                    tr.Commit();
                }
                valve=new ValveSession{Db=db,Id=inserted,Group=group,Size=spec,Pipe=ObjectId.Null};return inserted.Handle.ToString();
            }catch{using(var tr=db.TransactionManager.StartTransaction()){tr.GetObject(inserted,OpenMode.ForWrite).Erase();tr.Commit();}throw;}
        });
        private static DynamicBlockReferenceProperty ValveState(BlockReference block)
        {
            if(!block.IsDynamicBlock)return null;
            var states=block.DynamicBlockReferencePropertyCollection.Cast<DynamicBlockReferenceProperty>()
                .Where(p=>!p.ReadOnly&&p.Value is string&&p.GetAllowedValues().OfType<string>().Any()).ToArray();
            return states.OrderByDescending(p=>p.PropertyName.IndexOf("vis",StringComparison.OrdinalIgnoreCase)>=0).FirstOrDefault();
        }
        private static void ValvePose(BlockReference block,Point3d point,double rotation,Transaction tr)
        {
            var before=block.BlockTransform;block.Position=point;block.Rotation=rotation;
            var delta=block.BlockTransform*before.Inverse();
            foreach(ObjectId id in block.AttributeCollection)
                ((AttributeReference)tr.GetObject(id,OpenMode.ForWrite)).TransformBy(delta);
        }
        private static Extents3d ValveBody(BlockReference block)
        {
            Extents3d? bounds=null;
            void Walk(Entity e,int depth)
            {
                if(!e.Visible||e is DBText||e is MText||e is Dimension||e is AttributeDefinition)return;
                if(e is BlockReference nested&&depth<8) {
                    using(var children=new DBObjectCollection()) {
                        nested.Explode(children);
                        foreach(DBObject child in children)using(child)if(child is Entity entity)Walk(entity,depth+1);
                    }
                }else {
                    try {var ext=e.GeometricExtents;if(bounds.HasValue){var current=bounds.Value;current.AddExtents(ext);bounds=current;}else bounds=ext;}
                    catch(Autodesk.AutoCAD.Runtime.Exception ex) when(ex.ErrorStatus==ErrorStatus.NullExtents) { }
                }
            }
            Walk(block,0);Need(bounds.HasValue,"Khong doc duoc duong bao than block.");return bounds.Value;
        }
        private static void ValvePorts(BlockReference block,ValveSession s,Transaction tr)
        {
            s.PortsValid=false;s.PortAngle=0;
            var pos=block.Position;double angle=block.Rotation;
            try {
                ValvePose(block,Point3d.Origin,0,tr);
                if(!s.Group.inline) {
                    var ext=ValveBody(block);
                    Need(ext.MaxPoint.X-ext.MinPoint.X>.01,"Than block khong co chieu rong de cat ong.");
                    s.PortA=new U2Point(ext.MinPoint.X,0);s.PortB=new U2Point(ext.MaxPoint.X,0);s.PortsValid=true;return;
                }
                var ports=ValveGeometry.Ports(Faces(block,ValveCatalog.Outside(s.Size.dn),.65,6,true),ValveCatalog.Outside(s.Size.dn));
                s.PortA=ports.A;s.PortB=ports.B;s.PortAngle=Math.Atan2(ports.B.Y-ports.A.Y,ports.B.X-ports.A.X);s.PortsValid=true;
            }finally{ValvePose(block,pos,angle,tr);}
        }
        [LispFunction("TC_VALVE_STATE_027")]
        public static string ValveCycle(ResultBuffer args)=>ValveCall(()=>{
            var s=ValveActive((string)args.AsArray()[0].Value);
            using(var tr=s.Db.TransactionManager.StartTransaction()) {
                var block=(BlockReference)tr.GetObject(s.Id,OpenMode.ForWrite);var property=ValveState(block);
                if(property==null)return "Block chi co mot trang thai.";
                var options=property.GetAllowedValues().OfType<string>().ToArray();int index=Array.IndexOf(options,(string)property.Value);property.Value=options[(index+1)%options.Length];
                s.PortsValid=false;string state=(string)property.Value;
                if(!s.Pipe.IsNull)try{ValvePorts(block,s,tr);}catch(InvalidOperationException){state+=" - khong cat duoc o trang thai nay";}
                block.RecordGraphicsModified(true);tr.Commit();return state;
            }
        });
        [LispFunction("TC_VALVE_MOVE_027")]
        public static string ValveMove(ResultBuffer args)=>ValveCall(()=>{
            var v=args.AsArray();var s=ValveActive((string)v[0].Value);var point=new U2Point(Number(v[1].Value),Number(v[2].Value));bool rotating=(string)v[3].Value=="1";
            using(var tr=s.Db.TransactionManager.StartTransaction()) {
                var block=(BlockReference)tr.GetObject(s.Id,OpenMode.ForWrite);
                if(!rotating){ValvePose(block,P(point),0,tr);}
                else {
                    var delta=point-s.Anchor;double angle=delta.Length>.0001?Math.Atan2(delta.Y,delta.X):block.Rotation;
                    if(!s.Pipe.IsNull)angle=s.PipeAngle-s.PortAngle+(Math.Cos(angle-s.PipeAngle)<0?Math.PI:0);
                    var offset=!s.Pipe.IsNull&&s.PortsValid?(s.PortA+s.PortB)/2:new U2Point();
                    ValvePose(block,P(s.Anchor-PlusGeometry.Rotate(offset,angle)),angle,tr);
                }
                block.RecordGraphicsModified(true);tr.Commit();
                s.Db.TransactionManager.QueueForGraphicsFlush();AcApp.DocumentManager.MdiActiveDocument.Editor.UpdateScreen();return "OK";
            }
        });
        [LispFunction("TC_VALVE_PICK_027")]
        public static string ValvePick(ResultBuffer args)=>ValveCall(()=>{
            var v=args.AsArray();var s=ValveActive((string)v[0].Value);var pick=new U2Point(Number(v[1].Value),Number(v[2].Value));double tolerance=Number(v[3].Value);
            using(var tr=s.Db.TransactionManager.StartTransaction()) {
                var block=(BlockReference)tr.GetObject(s.Id,OpenMode.ForWrite);var space=(BlockTableRecord)tr.GetObject(block.OwnerId,OpenMode.ForRead);
                Mline best=null;U2Point on=pick;double cost=double.MaxValue;
                foreach(ObjectId id in space) {
                    if(!(tr.GetObject(id,OpenMode.ForRead) is Mline pipe)||pipe.NumberOfVertices!=2||pipe.Justification!=MlineJustification.Zero)continue;
                    var a=V(pipe.VertexAt(0));var b=V(pipe.VertexAt(1));if((b-a).Length<.001)continue;var u=(b-a).Unit;double along=(pick-a).Dot(u);
                    if(along<0||along>(b-a).Length)continue;var q=a+u*along;
                    var st=(MlineStyle)tr.GetObject(pipe.Style,OpenMode.ForRead);var offsets=st.Elements.Cast<MlineStyleElement>().Select(e=>e.Offset*pipe.Scale).ToArray();
                    if(offsets.Length<2)continue;double width=offsets.Max()-offsets.Min();double distance=(q-pick).Length;
                    if(distance<=width/2+tolerance&&distance<cost){best=pipe;cost=distance;on=q;}
                }
                s.Pipe=ObjectId.Null;s.Anchor=pick;s.PortsValid=false;s.Positioned=true;
                if(best!=null) {
                    Need(!((LayerTableRecord)tr.GetObject(best.LayerId,OpenMode.ForRead)).IsLocked,"MLINE tren layer khoa.");
                    Need(Math.Abs(best.VertexAt(0).Z)<.001&&Math.Abs(best.VertexAt(1).Z)<.001&&best.Normal.IsParallelTo(Vector3d.ZAxis),"MLINE can nam WCS XY, Z=0.");
                    if(s.Group.inline) {
                        var st=(MlineStyle)tr.GetObject(best.Style,OpenMode.ForRead);var offsets=st.Elements.Cast<MlineStyleElement>().Select(e=>e.Offset).ToArray();
                        double width=Upvc2Geometry.Width(best.Scale,offsets.Min(),offsets.Max());
                        Need(ValveGeometry.MatchesWidth(width,s.Size.dn),"Size van khong khop MLINE. Chon lai DN dung voi ong.");
                    }
                    ValvePorts(block,s,tr);
                    s.Pipe=best.ObjectId;s.Anchor=on;var axis=V(best.VertexAt(1))-V(best.VertexAt(0));s.PipeAngle=Math.Atan2(axis.Y,axis.X);block.LayerId=best.LayerId;
                    var offset=s.PortsValid?(s.PortA+s.PortB)/2:new U2Point();double rotation=s.PipeAngle-s.PortAngle;ValvePose(block,P(on-PlusGeometry.Rotate(offset,rotation)),rotation,tr);
                }else{ValvePose(block,P(pick),0,tr);}
                block.RecordGraphicsModified(true);tr.Commit();
                s.Db.TransactionManager.QueueForGraphicsFlush();AcApp.DocumentManager.MdiActiveDocument.Editor.UpdateScreen();return "OK";
            }
        });
        [LispFunction("TC_VALVE_END_027")]
        public static string ValveEnd(ResultBuffer args)=>ValveCall(()=>{
            var v=args.AsArray();var s=ValveActive((string)v[0].Value);bool commit=(string)v[1].Value=="1";double overlap=Number(v[2].Value);
            try {
                using(var tr=s.Db.TransactionManager.StartTransaction()) {
                    var block=(BlockReference)tr.GetObject(s.Id,OpenMode.ForWrite);
                    if(!commit)block.Erase();
                    else {
                        Need(s.Positioned,"Chua chon diem dat van.");
                        if(!s.Pipe.IsNull) {
                            Need(s.PortsValid,"Trang thai khong co hai cong noi; khong cat ong.");
                            var pipe=(Mline)tr.GetObject(s.Pipe,OpenMode.ForWrite);Need(!((LayerTableRecord)tr.GetObject(pipe.LayerId,OpenMode.ForRead)).IsLocked,"Layer ong dang khoa.");
                            var a=V(pipe.VertexAt(0));var b=V(pipe.VertexAt(1));var origin=V(block.Position);
                            var cut=ValveGeometry.Cut(a,b,origin+PlusGeometry.Rotate(s.PortA,block.Rotation),origin+PlusGeometry.Rotate(s.PortB,block.Rotation),overlap);
                            var space=(BlockTableRecord)tr.GetObject(pipe.OwnerId,OpenMode.ForWrite);
                            foreach(var ends in new[]{(a,cut.Left),(cut.Right,b)}) {
                                var piece=(Mline)pipe.Clone();piece.MoveVertexAt(0,P(ends.Item1));piece.MoveVertexAt(1,P(ends.Item2));piece.ColorIndex=256;
                                space.AppendEntity(piece);tr.AddNewlyCreatedDBObject(piece,true);
                            }
                            pipe.Erase();
                        }
                    }
                    tr.Commit();
                }
                valve=null;return "OK";
            }catch{throw;}
        });
        [LispFunction("TC_VALVE_RESET_027")]
        public static string ValveReset(ResultBuffer args)=>ValveCall(()=>{
            var old=valve;valve=null;
            if(old!=null&&!old.Id.IsErased)using(var tr=old.Db.TransactionManager.StartTransaction()) {
                tr.GetObject(old.Id,OpenMode.ForWrite).Erase();tr.Commit();
            }
            return "OK";
        });
    }
}
