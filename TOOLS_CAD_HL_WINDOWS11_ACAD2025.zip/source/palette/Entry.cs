using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Globalization;
using System.Text;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.Windows;
using AcApp = Autodesk.AutoCAD.ApplicationServices.Core.Application;

[assembly: ExtensionApplication(typeof(ToolsCad.Entry))]
[assembly: CommandClass(typeof(ToolsCad.Entry))]
namespace ToolsCad
{
    public sealed class Entry : IExtensionApplication
    {
        public static string VersionText => typeof(Entry).Assembly.GetName().Version.ToString(3);
        private static PaletteSet palette;
        private static PaletteView view;
        private static Preferences preferences;
        private static Request pending;
        private static Document observed;
        private sealed class Request
        {
            public string Token, Action, Command;
            public Document Document;
            public Profile Profile;
            public Dictionary<string, object> Settings;
            public bool Taken;
        }
        public void Initialize()
        {
            preferences = Preferences.Load();
            AcApp.DocumentManager.DocumentActivated += (s, e) => BindDocument(e.Document);
        }
        public void Terminate()
        {
            if (observed != null)
            {
                observed.CommandEnded -= Finished; observed.CommandCancelled -= Finished; observed.CommandFailed -= Finished;
                observed.LispEnded -= LispFinished; observed.LispCancelled -= LispAborted;
            }
            palette?.Dispose();
        }
        private static void BindDocument(Document doc)
        {
            if (observed == doc) return;
            if (observed != null)
            {
                observed.CommandEnded -= Finished; observed.CommandCancelled -= Finished; observed.CommandFailed -= Finished;
                observed.LispEnded -= LispFinished; observed.LispCancelled -= LispAborted;
            }
            if (pending != null && pending.Document != doc)
            {
                pending = null; view?.SetBusy(false); view?.SetStatus("Đã đổi bản vẽ; yêu cầu chưa chạy được hủy.", false);
            }
            observed = doc;
            if (doc != null) { doc.CommandEnded += Finished; doc.CommandCancelled += Finished; doc.CommandFailed += Finished; doc.LispEnded += LispFinished; doc.LispCancelled += LispAborted; }
        }
        private static void ClearRequest(string message)
        {
            // Clear the request before touching UI: a UI failure must not lock future drawing.
            pending = null;
            if (view != null && !view.IsDisposed)
            {
                view.SetBusy(false);
                view.SetStatus(message, false);
            }
        }
        private static void LispFinished(object sender, EventArgs e)
        {
            if (pending != null && pending.Taken)
                ClearRequest("Lệnh LISP đã kết thúc. Có thể vẽ tuyến mới; xem F2 nếu có lỗi.");
        }
        private static void LispAborted(object sender, EventArgs e)
        {
            if (pending != null) ClearRequest("Đã hủy lệnh. Có thể chọn VẼ để bắt đầu lại.");
        }
        private static void Finished(object sender, CommandEventArgs e)
        {
            if (string.Equals(e.GlobalCommandName, "HL_EXEC", StringComparison.OrdinalIgnoreCase) && pending != null)
            {
                pending = null; view?.SetBusy(false); view?.SetStatus("Lệnh đã kết thúc hoặc bị hủy. Xem F2 nếu AutoCAD báo lỗi.", false);
            }
        }
        [CommandMethod("TCPALETTE", CommandFlags.Session)]
        [CommandMethod("HLPALETTE", CommandFlags.Session)]
        public static void ShowCommand()
        {
            string result = TryShow(false);
            AcApp.DocumentManager.MdiActiveDocument?.Editor.WriteMessage("\nTools Cad HL: " + result);
        }
        [LispFunction("TC_PALETTE_VERSION_013")]
        public static string Version(ResultBuffer args) => VersionText;
        [LispFunction("TC_PALETTE_STATUS_013")]
        public static string Status(ResultBuffer args) => "DLL " + VersionText + " | " + typeof(Entry).Assembly.Location +
            (palette == null ? " | Bang chua mo" : " | Visible=" + palette.Visible + " | Dock=" + palette.Dock + " | AutoHide=" + palette.AutoRollUp);
        [LispFunction("TC_PALETTE_SHOW_013")]
        public static string ShowLisp(ResultBuffer args) => TryShow(false);
        [LispFunction("TC_PALETTE_DOCK_013")]
        public static string DockLisp(ResultBuffer args) => TryShow(true);
        [LispFunction("TC_PALETTE_FLOAT_013")]
        public static string FloatLisp(ResultBuffer args)
        {
            try { Show(); Place("FLOAT"); return "OK"; }
            catch (System.Exception ex) { return "ERROR: " + ex.GetType().Name + ": " + ex.Message + " | " + ex.StackTrace; }
        }
        private static string TryShow(bool reset)
        {
            try { Show(); if (reset) Place("RIGHT"); return "OK"; }
            catch (System.Exception ex) { return "ERROR: " + ex.GetType().Name + ": " + ex.Message + " | " + ex.StackTrace; }
        }
        public static bool CanRefreshLists()
        {
            var doc = AcApp.DocumentManager.MdiActiveDocument;
            return doc != null && pending == null && doc.Editor.IsQuiescent;
        }
        public static string[] DrawingLayers()
        {
            var names = new List<string>();
            var doc = AcApp.DocumentManager.MdiActiveDocument;
            if (doc == null) return names.ToArray();
            using (doc.LockDocument())
            using (var tr = doc.Database.TransactionManager.StartOpenCloseTransaction())
            {
                var table = (LayerTable)tr.GetObject(doc.Database.LayerTableId, OpenMode.ForRead);
                foreach (ObjectId id in table)
                {
                    var layer = (LayerTableRecord)tr.GetObject(id, OpenMode.ForRead);
                    if (!layer.IsDependent) names.Add(layer.Name);
                }
            }
            return names.OrderBy(n => n, StringComparer.CurrentCultureIgnoreCase).ToArray();
        }
        public static string[] MlineStyles()
        {
            var names = new List<string> { "TC_MC" };
            var doc = AcApp.DocumentManager.MdiActiveDocument;
            if (doc == null) return names.ToArray();
            using (doc.LockDocument())
            using (var tr = doc.Database.TransactionManager.StartOpenCloseTransaction())
            {
                var dict = (DBDictionary)tr.GetObject(doc.Database.MLStyleDictionaryId, OpenMode.ForRead);
                foreach (DBDictionaryEntry item in dict)
                    if (!names.Contains(item.Key)) names.Add(item.Key);
            }
            return names.ToArray();
        }
        private static void Show()
        {
            bool initializePlacement = false;
            if (palette == null)
            {
                if (preferences == null) preferences = Preferences.Load();
                var nextView = new PaletteView(preferences, Queue, Place);
                var nextPalette = new PaletteSet("Tools Cad HL " + VersionText, new Guid("34b47b1c-7e35-4c29-a68a-664b26d8cff1"))
                {
                    Style = PaletteSetStyles.ShowAutoHideButton | PaletteSetStyles.ShowCloseButton | PaletteSetStyles.ShowPropertiesMenu,
                    DockEnabled = DockSides.Left | DockSides.Right, MinimumSize = new Size(520, 420),
                    Size = new Size(560, 740), KeepFocus = false
                };
                try { nextPalette.Add("Các hệ thống", nextView); }
                catch { nextPalette.Dispose(); nextView.Dispose(); throw; }
                palette = nextPalette; view = nextView;
                initializePlacement = preferences.DockRevision < 11;
            }
            BindDocument(AcApp.DocumentManager.MdiActiveDocument);
            // AutoCAD creates/restores the native palette window when it first becomes visible.
            // Apply initial dock/pin after that, so restored state cannot undo the placement.
            palette.Visible = true;
            if (initializePlacement)
            {
                Place("RIGHT"); preferences.DockRevision = 11;
                try { preferences.Save(); }
                catch (System.Exception ex) { view.SetStatus("Bảng đã mở; chưa lưu được vị trí: " + ex.Message, true); }
            }
        }
        private static void Place(string side)
        {
            if (palette == null) return;
            try
            {
                palette.Visible = true;
                if (palette.AutoRollUp) palette.AutoRollUp = false;
                if (side == "FLOAT")
                {
                    // Undock before disabling docking; changing allowed sides while docked can fail.
                    if (palette.Dock != DockSides.None) palette.Dock = DockSides.None;
                    palette.DockEnabled = DockSides.None;
                }
                else
                {
                    palette.DockEnabled = DockSides.Left | DockSides.Right;
                    var desired = side == "LEFT" ? DockSides.Left : DockSides.Right;
                    if (palette.Dock != desired) palette.Dock = desired;
                }
                if (side == "FLOAT")
                {
                    var area = System.Windows.Forms.Screen.FromPoint(System.Windows.Forms.Cursor.Position).WorkingArea;
                    palette.Location = new Point(area.Left + 40, area.Top + 40);
                    palette.Size = new Size(560, Math.Max(420, Math.Min(740, area.Height - 80)));
                }
                view.SetStatus(side == "FLOAT" ? "Bảng thả nổi. Kéo tiêu đề để di chuyển." : "Đã ghim bảng. Chọn tab và thao tác trên bản vẽ.", false);
            }
            catch (System.Exception ex) { view.SetStatus("Không đổi được vị trí: " + ex.Message, true); throw; }
        }
        private static void Queue(string action, Profile profile, string command)
        {
            var doc = AcApp.DocumentManager.MdiActiveDocument;
            if (doc == null) { view.SetStatus("Mở một bản vẽ trước khi chạy lệnh.", true); return; }
            BindDocument(doc);
            if (pending != null || !doc.Editor.IsQuiescent)
            {
                view.SetStatus("Kết thúc lệnh đang chạy trước khi bấm nút mới. Có thể đổi kích thước khi đang pick tuyến.", true); return;
            }
            pending = new Request { Token = Guid.NewGuid().ToString("N"), Action = action, Command = command,
                Document = doc, Profile = profile, Settings = profile.Settings() };
            view.SetBusy(true); view.SetStatus("Chọn điểm / đối tượng trên bản vẽ. Bảng vẫn mở; Enter kết thúc, Esc hủy.", false);
            try { doc.SendStringToExecute("HL_EXEC " + pending.Token + "\n", true, false, false); }
            catch (System.Exception ex) { pending = null; view.SetBusy(false); view.SetStatus(ex.Message, true); }
        }
        private static string Token(ResultBuffer args)
        {
            var a = args?.AsArray(); return a != null && a.Length > 0 ? a[0].Value as string : null;
        }
        [LispFunction("TC_PALETTE_TAKE_013")]
        public static string Take(ResultBuffer args)
        {
            if (pending == null || pending.Taken || pending.Token != Token(args) || pending.Document != AcApp.DocumentManager.MdiActiveDocument)
                return "";
            pending.Taken = true;
            var result = new Dictionary<string, object> { {"action",pending.Action}, {"command",pending.Command}, {"settings",pending.Settings} };
            return LispWire.Encode(result);
        }
        [LispFunction("TC_PALETTE_LIVE_013")]
        public static string Live(ResultBuffer args)
        {
            if (pending == null || !pending.Taken || pending.Document != AcApp.DocumentManager.MdiActiveDocument)
                return "";
            return LispWire.Encode(pending.Profile.Settings());
        }
        [LispFunction("TC_PALETTE_CURRENT_013")]
        public static string Current(ResultBuffer args)
        {
            if (view == null || palette == null || !palette.Visible) return "";
            return LispWire.Encode(view.CurrentProfile.Settings());
        }
        [LispFunction("TC_PALETTE_DONE_013")]
        public static string Done(ResultBuffer args)
        {
            var values = args?.AsArray();
            if (pending != null && pending.Token == Token(args) && pending.Document == AcApp.DocumentManager.MdiActiveDocument)
            {
                string message = values != null && values.Length > 1 ? values[1].Value as string : "Lệnh đã kết thúc.";
                bool error = values != null && values.Length > 2 && (values[2].Value as string) == "0";
                pending = null; view.SetBusy(false); view.SetStatus(message ?? "Lệnh đã kết thúc.", error);
            }
            return "OK";
        }
    }
}
