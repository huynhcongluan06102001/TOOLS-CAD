using System;

namespace ToolsCad
{
    public static class PreviewGeometry
    {
        // Same +/-5 degree rule and tie order as tc:snap-turn. WCS coordinates.
        public static U2Point Snap(U2Point? previous, U2Point start, U2Point point, string mode)
        {
            if (!previous.HasValue) return point;
            var before=start-previous.Value;var next=point-start;
            double heading=Math.Atan2(before.Y,before.X), angle=Math.Atan2(next.Y,next.X);
            var turns=mode=="45"?new[]{0,45,-45,135,-135,180}:
                mode=="90"?new[]{0,90,-90,180}:new[]{0,45,-45,90,-90,135,-135,180};
            double delta=double.PositiveInfinity,best=0;
            foreach(int turn in turns)
            {
                double target=heading+turn*Math.PI/180;
                double difference=Math.Abs(Math.Atan2(Math.Sin(angle-target),Math.Cos(angle-target)));
                if(difference<delta){delta=difference;best=target;}
            }
            return delta<=Math.PI/36+1e-9 ? start+new U2Point(Math.Cos(best),Math.Sin(best))*next.Length : point;
        }
    }
}
