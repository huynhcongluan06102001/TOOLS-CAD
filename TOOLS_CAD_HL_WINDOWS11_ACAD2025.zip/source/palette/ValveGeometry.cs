using System;
using System.Collections.Generic;
using System.Linq;
namespace ToolsCad
{
    public static class ValveGeometry
    {
        public static double Snap45(double angle,double basis)
        { return basis+Math.Round((angle-basis)/(Math.PI/4),MidpointRounding.AwayFromZero)*(Math.PI/4); }
        public static double Rotation(U2Point delta,bool ortho,double ucsAngle)
        {
            double a=Math.Atan2(delta.Y,delta.X);
            return ortho?ucsAngle+Math.Round((a-ucsAngle)/(Math.PI/2),MidpointRounding.AwayFromZero)*(Math.PI/2):a;
        }
        public static (U2Point A,U2Point B) Ports(IEnumerable<U2Face> source,double diameter)
        {
            // Table valves use the local X flow axis; end-on circle views have no two axial ports.
            var faces=source.Where(f=>Math.Abs(f.Tangent.Y)>.999&&f.Width>=diameter*.65&&f.Width<=diameter*6).ToArray();
            U2Face left=null,right=null;double score=double.MaxValue;
            foreach(var a in faces)foreach(var b in faces) {
                double length=b.Center.X-a.Center.X;
                if(length<diameter*.2||Math.Abs(a.Center.Y-b.Center.Y)>Math.Max(.1,diameter*.015)||Math.Abs(a.Width-b.Width)>diameter*.2)continue;
                double cost=(Math.Abs(a.Width-diameter)+Math.Abs(b.Width-diameter))/diameter+Math.Abs((a.Center.Y+b.Center.Y)/2)/diameter*.05-length/diameter*.001;
                if(cost<score){score=cost;left=a;right=b;}
            }
            if(left==null)throw new InvalidOperationException("Khong nhan dien duoc cap mat cong thang trong hinh chieu nay.");
            return (left.Center,right.Center);
        }
        public static (U2Point A,U2Point B) PortsOnAxis(IEnumerable<U2Face> source,double diameter,bool vertical)
        {
            U2Point R(U2Point p)=>vertical?new U2Point(p.Y,-p.X):p;
            var faces=source.Select(f=>new U2Face(R(f.Center-f.Tangent*(f.Width/2)),R(f.Center+f.Tangent*(f.Width/2))));
            var pair=Ports(faces,diameter);
            if(Math.Abs(pair.A.Y)>.05||Math.Abs(pair.B.Y)>.05)
                throw new InvalidOperationException("Mat cong lech truc diem chen.");
            U2Point Back(U2Point p)=>vertical?new U2Point(-p.Y,p.X):p;
            return (Back(pair.A),Back(pair.B));
        }
        public static (U2Point A,U2Point B) BodySpan(IEnumerable<double> intersections)
        {
            var values=intersections.Where(x=>!double.IsNaN(x)&&!double.IsInfinity(x)).OrderBy(x=>x).ToArray();
            if(values.Length<2||values.Last()-values.First()<=.01)
                throw new InvalidOperationException("Khong xac dinh duoc hai bien than van tren truc diem chen; giu nguyen ong.");
            return (new U2Point(values.First(),0),new U2Point(values.Last(),0));
        }
        public static (U2Point Left,U2Point Right) Cut(U2Point a,U2Point b,U2Point portA,U2Point portB,double overlap)
        {
            if(double.IsNaN(overlap)||double.IsInfinity(overlap)||overlap<0)throw new InvalidOperationException("Khoang ngam khong hop le.");
            var axis=(b-a).Unit;double length=(b-a).Length;
            if(Math.Abs((portA-a).Dot(axis.Perp))>.05||Math.Abs((portB-a).Dot(axis.Perp))>.05)
                throw new InvalidOperationException("Cong van khong nam tren tim MLINE. Khong cat ong.");
            double l=Math.Min((portA-a).Dot(axis),(portB-a).Dot(axis));double h=Math.Max((portA-a).Dot(axis),(portB-a).Dot(axis));
            if(l<=.01||h>=length-.01||h-l<=2*overlap+.01)throw new InvalidOperationException("Van vuot dau ong hoac khoang ngam qua lon. Khong cat ong.");
            return (a+axis*(l+overlap),a+axis*(h-overlap));
        }
        public static U2Point[][] SplitRoute(U2Point[] vertices,int segment,U2Point left,U2Point right,U2Point centerShift)
        {
            if(vertices==null||segment<0||segment+1>=vertices.Length)throw new InvalidOperationException("Doan MLINE khong hop le.");
            left-=centerShift;right-=centerShift;
            var a=vertices[segment];var b=vertices[segment+1];var u=(b-a).Unit;
            double l=(left-a).Dot(u),r=(right-a).Dot(u),length=(b-a).Length;
            if(l<=.001||r>=length-.001||r-l<=.001||Math.Abs((left-a).Dot(u.Perp))>.001||Math.Abs((right-a).Dot(u.Perp))>.001)
                throw new InvalidOperationException("Diem cat khong hop le; giu nguyen MLINE.");
            return new[]{vertices.Take(segment+1).Concat(new[]{left}).ToArray(),new[]{right}.Concat(vertices.Skip(segment+1)).ToArray()};
        }
        public static (U2Point[][] Pieces,double Overlap) PlanCut(U2Point[] vertices,int segment,U2Point shift,U2Point portA,U2Point portB,double overlap)
        {
            if(vertices==null||vertices.Length<2||segment<0||segment+1>=vertices.Length||!double.IsFinite(overlap)||overlap<0)
                throw new InvalidOperationException("Du lieu cat van khong hop le; giu nguyen ong.");
            var a=vertices[segment]+shift;var b=vertices[segment+1]+shift;var u=(b-a).Unit;double length=(b-a).Length;
            if(Math.Abs((portA-a).Dot(u.Perp))>.05||Math.Abs((portB-a).Dot(u.Perp))>.05)
                throw new InvalidOperationException("Khoang cat khong nam tren tim MLINE; giu nguyen ong.");
            double low=Math.Min((portA-a).Dot(u),(portB-a).Dot(u)),high=Math.Max((portA-a).Dot(u),(portB-a).Dot(u));
            if(high-low<=.01)throw new InvalidOperationException("Than van qua ngan de cat ong.");
            double lap=Math.Min(overlap,(high-low)*.45);low+=lap;high-=lap;
            if(low<-.001&&segment>0||high>length+.001&&segment<vertices.Length-2)
                throw new InvalidOperationException("Van vuot qua dinh gap khuc ben trong MLINE; chon vi tri tren doan thang dai hon.");
            low=Math.Max(0,low);high=Math.Min(length,high);
            if(high-low<=.01)throw new InvalidOperationException("Van khong phu len doan ong da chon.");
            U2Point[] Clean(IEnumerable<U2Point> points) {
                var kept=new List<U2Point>();foreach(var p in points)if(kept.Count==0||(p-kept.Last()).Length>.001)kept.Add(p);
                return kept.ToArray();
            }
            var first=Clean(vertices.Take(segment+1).Concat(new[]{a+u*low-shift}));
            var second=Clean(new[]{a+u*high-shift}.Concat(vertices.Skip(segment+1)));
            var paths=new[]{first,second}.Where(path=>path.Length>=2).ToArray();
            if(paths.Length==0)throw new InvalidOperationException("Van che het tuyen ong; giu nguyen ong goc.");
            return (paths,lap);
        }
        public static bool MatchesWidth(double actual,int dn)
        {
            double od=ValveCatalog.Outside(dn);
            double steel=dn==200?219.1:dn==250?273.0:dn==300?323.8:od;
            return dn>0&&(Math.Abs(actual-dn)<=Math.Max(.5,dn*.015)||Math.Abs(actual-od)<=Math.Max(1.5,od*.02)||Math.Abs(actual-steel)<=Math.Max(1.5,steel*.02));
        }
    }
}
