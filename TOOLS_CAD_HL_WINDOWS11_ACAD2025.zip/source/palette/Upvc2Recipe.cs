using System;
using System.Collections.Generic;
using System.Linq;
namespace ToolsCad
{
    // Locations in the supplied UPVCPRO DWG. Names of anonymous evaluated blocks may change.
    public sealed class Upvc2Recipe
    {
        public string Code { get; }
        public bool Riser => Code.StartsWith("RS",StringComparison.Ordinal);
        public U2Point[] Parts { get; }
        public U2Point Outlet { get; }
        public U2Point RiserNear { get; }
        public U2Point RiserEnd { get; }
        private Upvc2Recipe(string code,U2Point[] parts,bool diagonal=false,U2Point? near=null,U2Point? end=null)
        {
            Code=code;Parts=parts;Outlet=diagonal?new U2Point(-1,1).Unit:new U2Point(-1,0);
            RiserNear=near??new U2Point(852.30,-10802.90);RiserEnd=end??new U2Point(624.30,-10802.90);
        }
        private static U2Point[] Points(params double[] values)
        {var result=new List<U2Point>();for(int i=0;i<values.Length;i+=2)result.Add(new U2Point(values[i],values[i+1]));return result.ToArray();}
        private static readonly U2Point[][] Old={
            Points(1825.06,2397.08,1599.19,2713.65,1230.58,2713.65),
            Points(6024.44,2397.08,6024.44,2714.76,5854.29,2851.23),
            Points(9799.69,2335.48,9799.69,2789.49,9799.69,2959.93,9661.80,3097.82),
            Points(13645.01,2397.08,13418.84,2713.44,13418.30,2900.28,13280.42,3038.17)};
        public static readonly Upvc2Recipe[] All={
            new Upvc2Recipe("MP1Y+1E1",Points(-7723.39,2219.53,-7943.25,2439.39)),
            new Upvc2Recipe("MP1Y+1E2",Points(-3512.09,1237.59),true),
            new Upvc2Recipe("MP1Y+2E1",Old[0]),new Upvc2Recipe("MP1Y+2E2",Old[1]),
            new Upvc2Recipe("MP1Y+3E1",Old[2]),new Upvc2Recipe("MP1Y+3E2",Old[3]),
            new Upvc2Recipe("RS1Y+1E1",Points(-6938.73,-11300.02,-7158.59,-11080.16),false,new U2Point(-7911.49,-11081.21),new U2Point(-8139.49,-11081.21)),
            new Upvc2Recipe("RS1Y+1E2",Points(-2938.72,-12281.96),true,new U2Point(-3978.42,-11242.58),new U2Point(-4139.48,-11081.21)),
            new Upvc2Recipe("RS1Y+2E1",Old[0]),new Upvc2Recipe("RS1Y+2E2",Old[1]),
            new Upvc2Recipe("RS1Y+3E1",Old[2]),new Upvc2Recipe("RS1Y+3E2",Old[3])};
        public static Upvc2Recipe For(string code)=>Array.Find(All,r=>r.Code==code)??throw new ArgumentException("Mau UPVC+ khong hop le.");
        public static double OriginY(U2Point port,U2Point anchor,U2Point direction)
        {
            if(Math.Abs(direction.X)<1e-8)throw new InvalidOperationException("Cong nhanh song song ong chinh.");
            return anchor.Y-port.Y-(anchor.X-port.X)*direction.Y/direction.X;
        }
    }
}
