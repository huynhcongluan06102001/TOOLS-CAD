using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace ToolsCad
{
    public sealed class PaletteView : UserControl
    {
        private readonly Preferences preferences;
        private readonly Action<string, Profile, string> execute;
        private readonly List<Button> commandButtons = new List<Button>();
        private readonly Label status = new Label { Dock = DockStyle.Bottom, Height = 56, Padding = new Padding(6), AutoEllipsis = true };
        private readonly VerticalTabs tabs = new VerticalTabs { Dock = DockStyle.Fill };
        private Profile currentMep;
        public Profile CurrentProfile => currentMep ?? preferences.For("PPR");

        public PaletteView(Preferences prefs, Action<string, Profile, string> run, Action<string> placement)
        {
            preferences = prefs; execute = run;
            Font = new Font("Segoe UI", 9F);
            AutoScaleMode = AutoScaleMode.Dpi;
            BackColor = Color.FromArgb(225, 207, 184);
            var top = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 34, WrapContents = false };
            var save = new Button { Text = "Lưu thông số", AutoSize = true };
            save.Click += (s, e) => Save();
            top.Controls.Add(save);
            foreach (var item in new[] { ("Ghim trái", "LEFT"), ("Ghim phải", "RIGHT"), ("Thả nổi", "FLOAT") })
            {
                var position = new Button { Text = item.Item1, AutoSize = true, MinimumSize = new Size(0, 25), Margin = new Padding(1) };
                position.Click += (s, e) => { try { placement(item.Item2); } catch (Exception ex) { SetStatus(ex.Message, true); } };
                top.Controls.Add(position);
            }
            top.WrapContents = true; top.AutoSize = true;
            Mep("UPVC", "UPVC"); Upvc2(); Mep("PPR", "PPR"); Mep("THÉP", "STEEL"); Mep("ỐNG GIÓ", "DUCT");
            Other("ĐÈN", new[] { ("Bố trí đèn", "TCARRAY"), ("Nối đèn ngang / dọc", "TCGRID"), ("Zigzag và hộp chia", "TCZIGBOX"), ("Dây điện dạng cung", "TCARC") });
            Other("TỦ ĐIỆN", new[] { ("Nối thiết bị về tủ", "TCDB"), ("Dây kiểu chữ U", "TCULINK"), ("Trục chính và nhánh", "TCSPINE"), ("Thống kê dây cáp", "TCCABLESTAT") });
            Mep("THANG MÁNG", "TRAY");
            Other("BỔ TRỢ", new[] { ("Căn hàng block", "TCALIGN"), ("Thay block", "TCREPLACE"), ("Chuẩn hóa ByLayer", "TCBYLAYER"), ("Khung block hiện tại", "TCBBOX"), ("Nối polyline thoát", "TCDRAIN"), ("Vát góc polyline", "TCCHAMFER") });
            Other("GHI CHÚ", new[] { ("Text dọc tuyến", "TCLABEL"), ("Ghi chú MLeader", "TCLEADER"), ("DIM chuỗi block", "TCDIMBLOCK"), ("DIM đoạn tuyến", "TCDIM"), ("Cộng DIM", "TCSUMDIM"), ("Bảng CAD sang CSV", "TCTABLECSV") });
            Other("THƯ VIỆN", new[] { ("Chọn template Library", "TCTEMPLATE"), ("Thư viện / chèn block", "TCBLOCK"), ("Xem thuộc tính block", "TCINSPECT"), ("Kiểm tra thư viện", "TCINIT"), ("Kiểm thử bản vẽ trống", "TCSELFTEST") });
            AllCommands();
            var help = Page("HELP");
            help.Controls.Add(new TextBox { Multiline = true, ReadOnly = true, Dock = DockStyle.Fill, ScrollBars = ScrollBars.Vertical,
                Text = "Tools Cad HL " + Entry.VersionText + "\r\n\r\nKéo tiêu đề bảng vào mép trái/phải để dock. Dùng nút ghim của AutoCAD để giữ bảng mở.\r\n\r\nMỗi tab lưu vật liệu và thông số riêng. Khi vẽ, có thể sửa D/DN hoặc W/H cho đoạn tiếp theo trên đúng tab đang vẽ; Size/Back cũng hoạt động ở dòng lệnh.\r\n\r\nTự nối vào tuyến có sẵn chỉ xét các tuyến cùng layer / vật liệu. Gót giày dùng block Chac chu T cong của template Library.\r\n\r\nTemplate giữ nguyên. AutoCAD 2025 Windows bản đầy đủ; hình học MEP WCS XY, Z=0.\r\n\r\nNếu lỗi: F2 để xem dòng lỗi; TCINSPECT đọc block; TCSELFTEST chạy trong bản vẽ NEW rỗng.\r\n\r\nGiao diện đã biên dịch; cần kiểm thử dock và block thực tế trong AutoCAD." });
            if (prefs.TabOrderRevision < 14)
            {
                int[] moved = { 4, 5, 6, 0, 1, 2, 3, 7, 8, 9, 10, 11 };
                if (prefs.SelectedTab >= 0 && prefs.SelectedTab < moved.Length) prefs.SelectedTab = moved[prefs.SelectedTab];
                prefs.TabOrderRevision = 14;
            }
            if (prefs.TabOrderRevision < 17)
            {
                if (prefs.SelectedTab >= 1) prefs.SelectedTab++;
                prefs.TabOrderRevision = 17;
            }
            tabs.SelectedIndex = Math.Max(0, Math.Min(tabs.TabPages.Count - 1, prefs.SelectedTab));
            tabs.SelectedIndexChanged += (s, e) => prefs.SelectedTab = tabs.SelectedIndex;
            Action captureProfile = () => { if (tabs.TabPages[tabs.SelectedIndex].Tag is Profile p) currentMep = p; };
            tabs.SelectedIndexChanged += (s,e) => captureProfile(); captureProfile();
            Controls.Add(tabs); Controls.Add(status); Controls.Add(top);
            ApplyMenuTheme(this);
            SetStatus("Chọn tab hệ thống. Bảng vẫn mở khi thao tác bản vẽ.", false);
        }

        private static void ApplyMenuTheme(Control control)
        {
            control.ForeColor = Color.FromArgb(48, 35, 25);
            if (control is TextBoxBase || control is ComboBox || control is NumericUpDown || control is ListBox)
                control.BackColor = Color.FromArgb(255, 252, 247);
            else if (control is Button button)
            {
                button.UseVisualStyleBackColor = false;
                button.BackColor = Color.FromArgb(241, 228, 210);
            }
            else control.BackColor = Color.FromArgb(225, 207, 184);
            foreach (Control child in control.Controls) ApplyMenuTheme(child);
        }

        private Panel Page(string label)
        {
            // Translate display labels only; preference keys and command labels stay stable.
            var titles = new Dictionary<string, string>
            {
                ["ĐÈN"] = "LIGHTING", ["TỦ ĐIỆN"] = "ELECTRICAL PANELS",
                ["THANG MÁNG"] = "CABLE TRAYS", ["THÉP"] = "STEEL",
                ["ỐNG GIÓ"] = "DUCT", ["BỔ TRỢ"] = "UTILITIES",
                ["GHI CHÚ"] = "ANNOTATIONS", ["THƯ VIỆN"] = "LIBRARY",
                ["TẤT CẢ LỆNH"] = "ALL COMMANDS"
            };
            var page = new Panel { Padding = new Padding(5) };
            tabs.AddPage(page, titles.TryGetValue(label, out var title) ? title : label);
            return page;
        }
        private TableLayoutPanel PageLayout(Panel page)
        {
            var scroll = new Panel { Dock = DockStyle.Fill, AutoScroll = true };
            var layout = new TableLayoutPanel { Dock = DockStyle.Top, AutoSize = true, ColumnCount = 2, Padding = new Padding(3) };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 38)); layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 62));
            scroll.Controls.Add(layout); page.Controls.Add(scroll); return layout;
        }
        private void Row(TableLayoutPanel panel, string label, Control input)
        {
            int row = panel.RowCount++; panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            panel.Controls.Add(new Label { Text = label, AutoSize = true, Anchor = AnchorStyles.Left, Margin = new Padding(2, 6, 2, 5) }, 0, row);
            // Reserve the preferred height, including spinner arrows at high DPI.
            input.MinimumSize = new Size(0, Math.Max(input.PreferredSize.Height, Font.Height + 12));
            if (input is ComboBox combo)
            {
                combo.DropDown += (s, e) =>
                {
                    int width = combo.Width;
                    foreach (var item in combo.Items)
                        width = Math.Max(width, TextRenderer.MeasureText(combo.GetItemText(item), combo.Font).Width + SystemInformation.VerticalScrollBarWidth + 24);
                    combo.DropDownWidth = Math.Min(width, Screen.FromControl(combo).WorkingArea.Width);
                };
            }
            input.Dock = DockStyle.Fill; input.Margin = new Padding(2, 3, 2, 3); panel.Controls.Add(input, 1, row);
        }
        private void Full(TableLayoutPanel panel, Control control)
        {
            int row = panel.RowCount++; panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            control.Dock = control is Button || control is TableLayoutPanel || control is CheckBox || control is FlexRow ? DockStyle.Top : DockStyle.Fill; control.Margin = new Padding(2, 4, 2, 4); panel.Controls.Add(control, 0, row); panel.SetColumnSpan(control, 2);
        }
        private TableLayoutPanel Group(TableLayoutPanel parent, string title)
        {
            // Keep every section in one table: nested AutoSize tables can under-report
            // their last row height when AutoCAD restores a narrow docked palette.
            Full(parent, new Label { Text = title, AutoSize = true, Font = new Font(Font, FontStyle.Bold) });
            return parent;
        }
        private ComboBox Diameter(string system, double selected, Action<double> update)
        {
            return Choice(Profile.Diameters(system).Select(d => d.ToString(System.Globalization.CultureInfo.InvariantCulture)).ToArray(),
                selected.ToString(System.Globalization.CultureInfo.InvariantCulture), v => update(double.Parse(v, System.Globalization.CultureInfo.InvariantCulture)));
        }
        private ComboBox Service(Profile p)
        {
            var c = new ComboBox { DropDownStyle = ComboBoxStyle.DropDown };
            c.Items.AddRange(p.System == "DUCT" ? new[] {"SA","RA","EA","FA"} : p.System == "TRAY" ? new[] {"ELE","ELV","FAS"} : new[] {"CW","HW","HWR","SP","WP","VP","FIRE"});
            c.Text = p.Service; c.TextChanged += (s, e) => p.Service = c.Text; return c;
        }
        private Control WithRefresh(ComboBox box, string label, Action refresh)
        {
            var panel = new TableLayoutPanel { AutoSize = true, ColumnCount = 1, RowCount = 2, Margin = Padding.Empty };
            panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            box.Dock = DockStyle.Fill;
            var button = new Button { Text = label, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, Padding = new Padding(4, 0, 4, 0) };
            button.Click += (s,e) =>
            {
                try
                {
                    if (!Entry.CanRefreshLists()) { SetStatus("Kết thúc lệnh đang chạy rồi nạp lại danh sách.", true); return; }
                    box.DroppedDown = false;
                    refresh();
                }
                catch (Exception ex) { SetStatus("Không nạp được danh sách: " + ex.Message, true); }
            };
            panel.Controls.Add(box, 0, 0); button.Anchor = AnchorStyles.Right | AnchorStyles.Top; panel.Controls.Add(button, 0, 1);
            return panel;
        }
        private TextBox MakeTextBox(string value, Action<string> update)
        {
            var c = new TextBox { Text = value ?? "" }; c.TextChanged += (s, e) => update(c.Text); return c;
        }
        private NumericUpDown Number(double value, Action<double> update, decimal min = 1, decimal max = 10000000)
        {
            var c = new NumericUpDown { Minimum = min, Maximum = max, DecimalPlaces = 2, ThousandsSeparator = false };
            c.Value = Math.Max(min, Math.Min(max, (decimal)(double.IsNaN(value) || double.IsInfinity(value) ? (double)min : Math.Max((double)min, Math.Min((double)max, value)))));
            update((double)c.Value); c.ValueChanged += (s, e) => update((double)c.Value); return c;
        }
        private ComboBox Choice(string[] values, string selected, Action<string> update)
        {
            var c = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
            c.Items.AddRange(values); c.SelectedItem = Array.IndexOf(values, selected) >= 0 ? selected : values[0];
            update((string)c.SelectedItem); c.SelectedIndexChanged += (s, e) => update((string)c.SelectedItem); return c;
        }
        private sealed class WrappedCheckBox : CheckBox
        {
            public override Size GetPreferredSize(Size proposedSize)
            {
                int available = Parent == null ? 250 : Math.Max(60, Parent.ClientSize.Width - Parent.Padding.Horizontal - Margin.Horizontal);
                if (Parent is TableLayoutPanel table && table.GetColumnSpan(this) == 1)
                {
                    int col = table.GetColumn(this);
                    int[] widths = table.GetColumnWidths();
                    if (col >= 0 && col < widths.Length && widths[col] > 0) available = Math.Min(available, Math.Max(40, widths[col] - Margin.Horizontal));
                }
                if (proposedSize.Width > 0) available = Math.Min(available, proposedSize.Width);
                int glyph = (int)Math.Ceiling(26 * DeviceDpi / 96.0);
                var text = TextRenderer.MeasureText(Text, Font, new Size(Math.Max(1, available - glyph), int.MaxValue),
                    TextFormatFlags.WordBreak | TextFormatFlags.TextBoxControl);
                return new Size(available, Math.Max(glyph, text.Height + (int)Math.Ceiling(6 * DeviceDpi / 96.0)));
            }
        }

        private CheckBox Check(string label, bool value, Action<bool> update)
        {
            var c = new WrappedCheckBox { Text = label, Checked = value, AutoSize = true }; c.CheckedChanged += (s, e) => update(c.Checked); return c;
        }
        private Button ActionButton(string label, string action, Profile p, string command = "")
        {
            var b = new Button { Text = label, Height = 33, AutoSize = false, MinimumSize = new Size(0, 33), MaximumSize = new Size(0, 33), BackColor = Color.FromArgb(229, 239, 249) };
            b.Click += (s, e) =>
            {
                string invalid = command == "TCTEMPLATE" ? null : p.Validate(); if (invalid != null) { SetStatus(invalid, true); return; }
                if (!Save()) return;
                execute(action, p, command);
            };
            commandButtons.Add(b); return b;
        }
        // Explicit row measurement avoids nested AutoSize feedback at narrow widths.
        private sealed class FlexRow : Panel
        {
            public CheckBox Option;
            public Button First, Second;
            public override Size GetPreferredSize(Size proposedSize)
            {
                int width = proposedSize.Width > 0 ? proposedSize.Width : Width;
                int side = (int)Math.Ceiling(36 * DeviceDpi / 96.0);
                int gap = (int)Math.Ceiling(4 * DeviceDpi / 96.0);
                int textWidth = Math.Max(30, width - 2 * (side + gap) - 26 * DeviceDpi / 96);
                int textHeight = TextRenderer.MeasureText(Option.Text, Option.Font,
                    new Size(textWidth, int.MaxValue), TextFormatFlags.WordBreak).Height;
                return new Size(width, Math.Max(side, textHeight + gap * 2));
            }
            protected override void OnLayout(LayoutEventArgs e)
            {
                base.OnLayout(e);
                if (Option == null || First == null || Second == null) return;
                int side = (int)Math.Ceiling(36 * DeviceDpi / 96.0);
                int gap = (int)Math.Ceiling(4 * DeviceDpi / 96.0);
                int height = GetPreferredSize(new Size(Width, 0)).Height;
                if (Height != height) Height = height;
                Second.SetBounds(Math.Max(0, Width - side), 0, side, side);
                First.SetBounds(Math.Max(0, Width - 2 * side - gap), 0, side, side);
                Option.SetBounds(0, 0, Math.Max(30, Width - 2 * (side + gap)), height);
            }
        }
        private Control FlexOptionRow(string text, bool value, Action<bool> update, Profile p, string first, string second)
        {
            var row = new FlexRow { Height = 36, AutoSize = false };
            var option = Check(text, value, update); option.AutoSize = false;
            var buttons = new[] { ActionButton(first, "FLEX", p, first), ActionButton(second, "FLEX", p, second) };
            foreach (var button in buttons)
            {
                button.MinimumSize = button.MaximumSize = Size.Empty;
                button.Padding = Padding.Empty; button.Margin = Padding.Empty;
                button.Font = new Font("Segoe UI", 8F);
                button.FlatStyle = FlatStyle.Flat;
                button.TextAlign = ContentAlignment.MiddleCenter;
                button.AutoEllipsis = false;
            }
            row.Option = option; row.First = buttons[0]; row.Second = buttons[1];
            row.Controls.Add(option); row.Controls.Add(buttons[0]); row.Controls.Add(buttons[1]);
            return row;
        }

        private Label Common(TableLayoutPanel panel, Profile p)
        {
            Row(panel, "Hệ thống", Service(p));
            if (p.System == "DUCT")
            {
                Full(panel, FlexOptionRow("Polyline có sẵn", p.Polyline, v => p.Polyline = v, p, "S1", "S2"));
                Full(panel, FlexOptionRow("Ghi chú tuyến", p.Notes, v => p.Notes = v, p, "R1", "R2"));
            }
            else
            {
                Full(panel, Check("Polyline có sẵn", p.Polyline, v => p.Polyline = v));
                Full(panel, Check("Ghi chú tuyến", p.Notes, v => p.Notes = v));
            }
            var note = Group(panel, "GHI CHÚ");
            Row(note, "Tiền tố", MakeTextBox(p.Prefix, v => p.Prefix = v));
            Row(note, "Hậu tố", MakeTextBox(p.Suffix, v => p.Suffix = v));
            Row(note, "BOP / BOT", MakeTextBox(p.Elevation, v => p.Elevation = v));
            Row(note, "Cao chữ", Number(p.TextHeight, v => p.TextHeight = v));
            var connectionHint = new Label { AutoSize = true, MaximumSize = new Size(320, 0) };
            Action updateConnectionHint = () => connectionHint.Text = p.AutoConnect
                ? "Tự nối BẬT: chọn đầu nhánh tại tim hoặc mép tuyến chính cùng layer/vật liệu."
                : "Tự nối TẮT: không tạo tê/chạc vào tuyến cũ. Bật tùy chọn trên hoặc dùng TỰ ĐỘNG KẾT PHỤ KIỆN.";
            Full(panel, Check("Tự nối vào tuyến cùng layer", p.AutoConnect, v => { p.AutoConnect = v; updateConnectionHint(); }));
            updateConnectionHint();
            Full(panel, Check("Ngắt / cắt tuyến tại phụ kiện", p.Trim, v => p.Trim = v));
            return connectionHint;
        }
        private void Upvc2()
        {
            var p = preferences.For("UPVC2");
            var page = Page("UPVC+"); page.Tag = p;
            var layout = PageLayout(page);
            Full(layout, new Label { AutoSize = true, Text = "UPVC+ — cần kiểm thử trên bản sao DWG." });
            Row(layout, "Vật liệu", Choice(Profile.Materials("UPVC"), p.Material, v => p.Material = v));
            Full(layout, ActionButton("CHỌN / NẠP LẠI THƯ VIỆN DWG", "COMMAND", p, "TCTEMPLATE"));
            Full(layout, Check("Ngắt / cắt ống tại phụ kiện", p.Trim, v => p.Trim = v));
            Row(layout, "Size trục đứng", Diameter("UPVC", p.Dn, v => p.Dn = v));
            Full(layout, Check("Select", p.UpvcBatchSelect, v => p.UpvcBatchSelect = v));
            Full(layout, ActionButton("CHÈN BLOCK TRỤC ĐỨNG", "UPVCRISER", p));
            foreach (var code in Upvc2Geometry.Codes)
                Full(layout, ActionButton(code, "UPVC2", p, code));
            var options = Group(layout, "TÙY CHỌN");
            Row(options, "Ngậm UPVC", Number(p.Overlap, v => p.Overlap = v, 0));
            Full(layout, new Label { AutoSize = true, MaximumSize = new Size(320, 0),
                Text = "Select: chọn một MLINE chính, quét nhiều nhánh MP hoặc trục đứng RS, Enter; click hai điểm để chọn hướng Y chung cho cả nhóm. Bỏ tick để nối từng nhánh. Nhánh lỗi được bỏ qua và báo tại F2; U hoàn tác cả lượt. Select áp dụng cho 12 mẫu nối, không áp dụng nút chèn trục đứng.\n\nMP: 1E2 dùng nhánh xiên 45°/135°; các mẫu còn lại dùng nhánh 90°. RS: chọn Circle hoặc block D<size>. Size lấy riêng từ từng đối tượng; tạo MLINE giữa phụ kiện theo style ống.\n\nUPVC+ dùng chung thư viện với UPVC; không chọn UPVCPRO làm thư viện đầy đủ mọi size." });
        }
        private void Mep(string label, string system)
        {
            var p = preferences.For(system); var page = Page(label); page.Tag = p;
            var layout = PageLayout(page); bool pipe = system == "PPR" || system == "UPVC" || system == "STEEL";
            var materialChoice = Choice(Profile.Materials(system), p.Material, v => p.Material = v);
            Row(layout, "Vật liệu", materialChoice);
            if (pipe) Row(layout, system == "STEEL" ? "DN" : "D ngoài", Diameter(system, p.Dn, v => p.Dn = v));
            else { Row(layout, "WIDTH / D", Number(p.Width, v => p.Width = v)); Row(layout, "HEIGHT", Number(p.Height, v => p.Height = v)); }
            if (system == "STEEL") Row(layout, "Kết nối", Choice(new[] {"AUTO","SCREW","WELD"}, p.SteelJoint, v => p.SteelJoint = v));
            if (pipe)
            {
                var styles = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
                Action refresh = () => {
                    try {
                        var names = Entry.MlineStyles(); // Read/import before changing the UI list.
                        string previous = p.MlineStyle;
                        styles.Items.Clear(); styles.Items.AddRange(names);
                        styles.SelectedItem = styles.Items.Contains(previous) ? previous : "Standard";
                        SetStatus("Đã nạp style từ thư viện. Style trùng tên giữ định nghĩa trong bản vẽ.", false);
                    } catch (Exception ex) { SetStatus("Không đọc được MLINE style: " + ex.Message, true); }
                };
                styles.SelectedIndexChanged += (s,e) => { if (styles.SelectedItem is string name) p.MlineStyle = name; };
                p.MlineStyle = "Standard";
                styles.Items.Add("Standard"); styles.SelectedItem = "Standard";
                Full(layout, new Label { Text = "MLINE style", AutoSize = true });
                Full(layout, WithRefresh(styles, "Nạp style", refresh));
                styles.DropDownWidth = 420;
            }
            Full(layout, ActionButton("CHỌN / NẠP LẠI THƯ VIỆN DWG", "COMMAND", p, "TCTEMPLATE"));
            var connectionHint = Common(layout, p);
            Row(layout, "Góc theo đoạn trước", Choice(new[] {"FREE", "45", "90", "BOTH"}, p.TurnMode, v => p.TurnMode = v));
            ComboBox branchChoice = null;
            bool updatingBranch = false;
            if (system == "DUCT")
            {
                branchChoice = Choice(new[] { "Gót giày", "Tê" }, p.Branch == "SHOE" ? "Gót giày" : "Tê", v => { if (!updatingBranch) p.Branch = v == "Gót giày" ? "SHOE" : "TEE"; });
                Row(layout, "Nối nhánh", branchChoice);
            }
            Full(layout, ActionButton("VẼ " + label, "DRAW", p));
            Full(layout, ActionButton("TỰ ĐỘNG KẾT PHỤ KIỆN", "AUTOFIT", p));
            var fitting = Group(layout, "ĐẶT PHỤ KIỆN THỦ CÔNG");
            string[] kinds = Profile.FittingsFor(system, p.Material);
            var fittingChoice = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList,
                DropDownWidth = 420, IntegralHeight = false, DropDownHeight = 340 };
            fittingChoice.SelectedIndexChanged += (s, e) => { if (fittingChoice.SelectedIndex >= 0) p.Fitting = kinds[fittingChoice.SelectedIndex]; };
            Action refreshFittings = () =>
            {
                string previous = p.Fitting;
                kinds = Profile.FittingsFor(system, p.Material);
                fittingChoice.Items.Clear(); fittingChoice.Items.AddRange(kinds.Select(k => system == "DUCT" && k == "TEE"
                    ? (p.Material == "tron" ? "Chạc chữ T (ống tròn)" : "Chạc 3 (ống chữ nhật)") : Profile.Label(k)).ToArray());
                fittingChoice.SelectedIndex = Math.Max(0, Array.IndexOf(kinds, previous));
                if (branchChoice != null)
                {
                    branchChoice.Enabled = p.Material != "tron";
                    updatingBranch = true;
                    branchChoice.SelectedItem = !branchChoice.Enabled ? "Tê" : p.Branch == "SHOE" ? "Gót giày" : "Tê";
                    updatingBranch = false;
                }
            };
            refreshFittings(); materialChoice.SelectedIndexChanged += (s, e) => refreshFittings();
            Row(fitting, "Loại phụ kiện", fittingChoice);
            var visibility = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
            Action refreshStates = () =>
            {
                string previous = p.Visibility;
                visibility.Items.Clear(); visibility.Items.Add("Mặc định");
                visibility.Items.AddRange(NativeCatalog.StatesFor(system, p.Material, p.Fitting));
                visibility.SelectedItem = visibility.Items.Contains(previous) ? previous : "Mặc định";
                p.Visibility = visibility.SelectedIndex == 0 ? "" : (string)visibility.SelectedItem;
                visibility.Enabled = visibility.Items.Count > 1;
            };
            visibility.SelectedIndexChanged += (s, e) => p.Visibility = visibility.SelectedIndex <= 0 ? "" : (string)visibility.SelectedItem;
            fittingChoice.SelectedIndexChanged += (s, e) => refreshStates();
            materialChoice.SelectedIndexChanged += (s, e) => refreshStates();
            refreshStates(); Row(fitting, "Trạng thái", visibility);
            if (pipe)
            {
                Row(fitting, "D1 / DN1", Diameter(system, p.FitDn, v => p.FitDn = v));
                Row(fitting, "D2 / DN2", Diameter(system, p.Dn2, v => p.Dn2 = v));
            }
            else
            {
                Row(fitting, "WIDTH1", Number(p.FitWidth, v => p.FitWidth = v));
                Row(fitting, "WIDTH2", Number(p.FitWidth2, v => p.FitWidth2 = v));
                Row(fitting, "HEIGHT", Number(p.FitHeight, v => p.FitHeight = v));
            }
            Full(fitting, Check("Đảo hướng / mirror phụ kiện", p.Flip, v => p.Flip = v));
            Full(layout, ActionButton("ĐẶT PHỤ KIỆN", "FITTING", p));
            Full(layout, ActionButton("SỬA THUỘC TÍNH", "COMMAND", p, "TCBEDIT"));
            if (system == "UPVC") Full(layout, ActionButton("TẠO HƯỚNG CHẢY", "COMMAND", p, "TCFLOW"));
            Full(layout, ActionButton("THỐNG KÊ", "STATS", p));
            Full(layout, new Label { Text = "TÙY CHỌN", AutoSize = true, Font = new Font(Font, FontStyle.Bold) });
            Row(layout, "Sai số nối", Number(p.Gap, v => p.Gap = v));
            Row(layout, "Sai số đầu mút", Number(p.EndpointTolerance, v => p.EndpointTolerance = v, 0.01m));
            if (system == "UPVC") Row(layout, "Ngậm UPVC", Number(p.Overlap, v => p.Overlap = v, 0));
            Row(layout, "Đơn vị vẽ / m", Number(p.UnitsPerMetre, v => p.UnitsPerMetre = v));
            Full(layout, Check("Xóa polyline nguồn sau khi tạo", p.Erase, v => p.Erase = v));
            Full(layout, connectionHint);
            Full(layout, new Label { AutoSize = true, MaximumSize = new Size(320, 0), Text = "Layer: dùng layer hiện hành trên thanh Layer của AutoCAD. Màu: ByLayer." });
            Full(layout, new Label { AutoSize = true, MaximumSize = new Size(320, 0), Text = "Bắt góc ±5°: FREE/BOTH → 45° và 90°. Vẫn cho đi thẳng. Khi vẽ pipe, gõ Center để bắt tim MLINE." });
            Full(layout, new Label { AutoSize = true, MaximumSize = new Size(320, 0), Text = "ĐẶT PHỤ KIỆN: chọn ống chính để lấy kích thước, chọn thêm nhánh nếu cần. Enter bỏ qua dùng kích thước nhập tay trong bảng." });
            Full(layout, new Label { Text = "THÀNH PHẦN GHI CHÚ", AutoSize = true });
            Full(layout, Check("Thêm tiền tố", p.IncludePrefix, v => p.IncludePrefix = v));
            Full(layout, Check("Thêm hậu tố", p.IncludeSuffix, v => p.IncludeSuffix = v));
            Full(layout, Check("Thêm vật liệu", p.IncludeMaterial, v => p.IncludeMaterial = v));
        }
        private void Other(string label, (string Label, string Command)[] commands)
        {
            string key = "UI_" + label;
            if (!preferences.Pages.TryGetValue(key, out var p) || p == null) preferences.Pages[key] = p = Profile.Create("PPR");
            var layout = PageLayout(Page(label));
            Row(layout, "Hệ thống", MakeTextBox(p.Service, v => p.Service = v));
            Row(layout, "Text height", Number(p.TextHeight, v => p.TextHeight = v));
            Row(layout, "R bo góc", Number(p.Fillet, v => p.Fillet = v, 0));
            Row(layout, "Dây chờ / tuyến", Number(p.Allowance, v => p.Allowance = v, 0));
            Row(layout, "Sai số gom hàng", Number(p.RowTolerance, v => p.RowTolerance = v));
            Row(layout, "Độ võng cung", Number(p.ArcRise, v => p.ArcRise = v));
            foreach (var item in commands) Full(layout, ActionButton(item.Label, "COMMAND", p, item.Command));
            Full(layout, new Label { AutoSize = true, MaximumSize = new Size(320, 0), Text = "Layer: dùng layer hiện hành trên thanh Layer của AutoCAD. Màu: ByLayer." });
        }
        private void AllCommands()
        {
            var layout = PageLayout(Page("TẤT CẢ LỆNH"));
            var search = new TextBox(); Row(layout, "Tìm lệnh", search);
            var list = new ListBox { Height = 290, HorizontalScrollbar = true }; Full(layout, list);
            var hint = new Label { AutoSize = true, MaximumSize = new Size(340, 0) }; Full(layout, hint);
            var run = new Button { Text = "CHẠY LỆNH ĐÃ CHỌN", Height = 34 }; Full(layout, run); commandButtons.Add(run);
            Full(layout, new Label { AutoSize = true, MaximumSize = new Size(340, 0), Text = "Lệnh MEP lấy thông số từ tab của hệ tương ứng. Mỗi lệnh có hướng dẫn chọn đối tượng tại dòng lệnh / F2." });
            Action filter = () => {
                list.Items.Clear();
                list.Items.AddRange(CommandCatalog.All.Where(c => c.ToString().IndexOf(search.Text,StringComparison.CurrentCultureIgnoreCase) >= 0).ToArray());
                if (list.Items.Count > 0) list.SelectedIndex = 0;
            };
            list.SelectedIndexChanged += (s,e) => hint.Text = (list.SelectedItem as MenuCommand)?.Hint ?? "";
            search.TextChanged += (s,e) => filter();
            run.Click += (s,e) => {
                var item = list.SelectedItem as MenuCommand; if (item == null) return;
                var p = item.Code == "TCFIT" ? CurrentProfile : preferences.For(string.IsNullOrEmpty(item.System) ? "PPR" : item.System);
                string invalid = p.Validate(); if (invalid != null) { SetStatus(invalid,true); return; }
                if (Save()) execute("COMMAND",p,item.Code);
            };
            filter();
        }
        private bool Save()
        {
            try { preferences.Save(); SetStatus("Đã lưu thông số riêng cho từng tab.", false); return true; }
            catch (Exception ex) { SetStatus("Không lưu được thông số: " + ex.Message, true); return false; }
        }
        public void SetBusy(bool busy)
        {
            foreach (var b in commandButtons) b.Enabled = !busy;
        }
        public void SetStatus(string message, bool error)
        {
            status.ForeColor = error ? Color.Firebrick : SystemColors.ControlText; status.Text = message;
        }
    }
}
