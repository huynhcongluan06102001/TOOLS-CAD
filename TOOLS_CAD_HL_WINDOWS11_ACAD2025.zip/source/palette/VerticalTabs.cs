using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace ToolsCad
{
    // A single scrollable strip keeps the tabs on the right even in a short docked palette.
    internal sealed class VerticalTabs : UserControl
    {
        private readonly Panel deck = new Panel { Dock = DockStyle.Fill };
        private readonly FlowLayoutPanel strip = new FlowLayoutPanel
        {
            Dock = DockStyle.Right, Width = 160, AutoScroll = true,
            FlowDirection = FlowDirection.TopDown, WrapContents = false, Padding = new Padding(1)
        };
        private readonly List<Panel> pages = new List<Panel>();
        private readonly List<SideButton> buttons = new List<SideButton>();
        private readonly ToolTip tips = new ToolTip();
        private Control footer;
        private int selected = -1;
        public IReadOnlyList<Panel> TabPages => pages;
        public event EventHandler SelectedIndexChanged;
        public VerticalTabs() { Controls.Add(deck); Controls.Add(strip); }
        public void SetFooter(Control control)
        {
            if (footer != null) strip.Controls.Remove(footer);
            footer = control;
            footer.AutoSize = false;
            footer.Margin = new Padding(1, 8, 1, 4);
            strip.Controls.Add(footer);
            ResizeLabels();
        }
        public void AddPage(Panel page, string title)
        {
            int index = pages.Count; pages.Add(page); page.Dock = DockStyle.Fill; page.Visible = false; deck.Controls.Add(page);
            var button = new SideButton { Caption = title, Width = 138, Height = 38, Margin = new Padding(1, 0, 1, 1), AccessibleName = title };
            tips.SetToolTip(button, title); button.Click += (s, e) => SelectedIndex = index;
            buttons.Add(button); strip.Controls.Add(button); ResizeLabels();
            if (selected < 0) SelectedIndex = 0;
        }
        private void ResizeLabels()
        {
            int width = 138;
            foreach (var button in buttons)
                width = Math.Max(width, TextRenderer.MeasureText(button.Caption, button.Font).Width + 24);
            strip.Width = width + SystemInformation.VerticalScrollBarWidth + 6;
            foreach (var button in buttons)
            {
                button.Width = width;
                button.Height = Math.Max(38, button.Font.Height + 16);
            }
            if (footer != null)
            {
                footer.Width = width;
                footer.Height = Math.Max(32, footer.Font.Height + 14);
            }
        }
        protected override void OnFontChanged(EventArgs e)
        {
            base.OnFontChanged(e);
            if (buttons != null) ResizeLabels();
        }
        public int SelectedIndex
        {
            get => selected;
            set
            {
                if (value < 0 || value >= pages.Count || value == selected) return;
                selected = value;
                for (int i = 0; i < pages.Count; i++)
                {
                    pages[i].Visible = i == value; buttons[i].Selected = i == value; buttons[i].Invalidate();
                }
                pages[value].BringToFront(); SelectedIndexChanged?.Invoke(this, EventArgs.Empty);
            }
        }
        protected override void Dispose(bool disposing) { if (disposing) tips.Dispose(); base.Dispose(disposing); }
        private sealed class SideButton : Button
        {
            public string Caption { get; set; }
            public bool Selected { get; set; }
            protected override void OnPaint(PaintEventArgs e)
            {
                e.Graphics.Clear(Selected ? Color.FromArgb(193, 155, 111) : Color.FromArgb(241, 228, 210));
                ControlPaint.DrawBorder(e.Graphics, ClientRectangle, Selected ? Color.FromArgb(112, 76, 43) : Color.FromArgb(172, 145, 112), ButtonBorderStyle.Solid);
                TextRenderer.DrawText(e.Graphics, Caption, Font,
                    Rectangle.Inflate(ClientRectangle, -8, -2), ForeColor,
                    TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine);
                if (Focused) ControlPaint.DrawFocusRectangle(e.Graphics, Rectangle.Inflate(ClientRectangle, -3, -3));
            }
        }
    }
}
