using System;
using System.Globalization;
using System.Linq;
using Autodesk.AutoCAD.Colors;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.Runtime;
using AcApp=Autodesk.AutoCAD.ApplicationServices.Core.Application;

[assembly: CommandClass(typeof(ToolsCad.RoutePreview))]
namespace ToolsCad
{
    public static class RoutePreview
    {
        [LispFunction("TC_ROUTE_PREVIEW_ENABLED_023")]
        public static string Enabled(ResultBuffer args) => Entry.RoutePreviewEnabled ? "1" : "0";
        private static void Need(bool condition,string message)
        {if(!condition)throw new InvalidOperationException(message);}
        private static double Number(object value)=>Convert.ToDouble(value,CultureInfo.InvariantCulture);
        private static string PointText(Point3d p)=>"("+p.X.ToString("G17",CultureInfo.InvariantCulture)+" "+p.Y.ToString("G17",CultureInfo.InvariantCulture)+" "+p.Z.ToString("G17",CultureInfo.InvariantCulture)+")";

        // All display entities live in a disposable side database. The real drawing
        // never receives a preview entity or temporary layer, even on Esc/failure.
        [LispFunction("TC_ROUTE_POINT_023")]
        public static string Pick(ResultBuffer args)
        {
            try
            {
                var v=args.AsArray();Need(v.Length==11,"Preview: du lieu khong hop le.");
                bool pipe=(string)v[0].Value=="PIPE";
                string asset=(string)v[1].Value,mode=(string)v[10].Value;
                double diameter=Number(v[2].Value),width=Number(v[3].Value);
                var start=new U2Point(Number(v[4].Value),Number(v[5].Value));
                U2Point? previous=(string)v[8].Value=="1" ? new U2Point(Number(v[6].Value),Number(v[7].Value)) : (U2Point?)null;
                // v[9] is the current layer name (used by the final LISP operation).
                Need(diameter>0 && width>0,"Preview: kich thuoc phai duong.");
                var doc=AcApp.DocumentManager.MdiActiveDocument;Need(doc!=null,"Mo ban ve truoc.");
                var source=doc.Database;var editor=doc.Editor;
                using(var preview=new Database(true,true))
                {
                    ObjectId definition;
                    using(var read=source.TransactionManager.StartOpenCloseTransaction())
                    {
                        ObjectId original;
                        if(pipe)
                        {
                            var styles=(DBDictionary)read.GetObject(source.MLStyleDictionaryId,OpenMode.ForRead);
                            Need(styles.Contains(asset),"Preview: chua co MLINE style "+asset);
                            original=styles.GetAt(asset);
                        }
                        else
                        {
                            var blocks=(BlockTable)read.GetObject(source.BlockTableId,OpenMode.ForRead);
                            Need(blocks.Has(asset),"Preview: chua nap block "+asset);original=blocks[asset];
                        }
                        var mapping=new IdMapping();
                        source.WblockCloneObjects(new ObjectIdCollection(new[]{original}),
                            pipe?preview.MLStyleDictionaryId:preview.BlockTableId,mapping,DuplicateRecordCloning.Replace,false);
                        definition=mapping[original].Value;
                    }
                    using(var tr=preview.TransactionManager.StartTransaction())
                    {
                        if(!pipe)
                        {
                            // Fade explicit child colors as well as ByBlock geometry,
                            // in the private copy only (including visibility states).
                            var blocks=(BlockTable)tr.GetObject(preview.BlockTableId,OpenMode.ForRead);
                            foreach(ObjectId blockId in blocks)
                            {
                                var record=(BlockTableRecord)tr.GetObject(blockId,OpenMode.ForRead);
                                if(record.IsLayout)continue;
                                foreach(ObjectId id in record)
                                    if(tr.GetObject(id,OpenMode.ForWrite) is Entity child)
                                    {child.ColorIndex=8;child.Transparency=new Transparency((byte)100);}
                            }
                        }
                        var space=(BlockTableRecord)tr.GetObject(SymbolUtilityServices.GetBlockModelSpaceId(preview),OpenMode.ForWrite);
                        Entity ghost;DynamicBlockReferenceProperty lengthProperty=null;
                        if(pipe)
                        {
                            var style=(MlineStyle)tr.GetObject(definition,OpenMode.ForRead);
                            var offsets=style.Elements.Cast<MlineStyleElement>().Select(x=>x.Offset).ToArray();
                            double span=offsets.Max()-offsets.Min();
                            Need(span>1e-6 && Math.Abs(offsets.Max()+offsets.Min())<1e-6,"Preview: MLINE style phai doi xung qua tim.");
                            var line=new Mline();line.SetDatabaseDefaults(preview);
                            space.AppendEntity(line);tr.AddNewlyCreatedDBObject(line,true);
                            line.Style=definition;line.Normal=Vector3d.ZAxis;line.Justification=MlineJustification.Zero;line.Scale=diameter/span;
                            line.AppendSegment(new Point3d(start.X,start.Y,0));line.AppendSegment(new Point3d(start.X+1,start.Y,0));ghost=line;
                        }
                        else
                        {
                            var block=new BlockReference(new Point3d(start.X,start.Y,0),definition);
                            block.SetDatabaseDefaults(preview);space.AppendEntity(block);tr.AddNewlyCreatedDBObject(block,true);ghost=block;
                            Need(block.IsDynamicBlock,"Preview: block tuyen khong phai block dong.");
                            var props=block.DynamicBlockReferencePropertyCollection.Cast<DynamicBlockReferenceProperty>().ToArray();
                            var widthProperty=new[]{"Width1","Width","Diameter","Diameter1"}
                                .Select(name=>props.FirstOrDefault(p=>string.Equals(p.PropertyName,name,StringComparison.OrdinalIgnoreCase)&&p.Value is double)).FirstOrDefault(p=>p!=null);
                            Need(widthProperty!=null && !widthProperty.ReadOnly,"Preview: thieu tham so chieu rong.");
                            SetSize(preview,widthProperty,width);
                            lengthProperty=props.FirstOrDefault(p=>string.Equals(p.PropertyName,"Length",StringComparison.OrdinalIgnoreCase));
                            Need(lengthProperty!=null && !lengthProperty.ReadOnly,"Preview: thieu tham so Length.");
                        }
                        ghost.ColorIndex=8;ghost.Transparency=new Transparency((byte)100);
                        string displayError=null;
                        Point3d Snap(Point3d value)
                        {
                            var point=PreviewGeometry.Snap(previous,start,new U2Point(value.X,value.Y),mode);
                            return new Point3d(point.X,point.Y,value.Z);
                        }
                        PointMonitorEventHandler monitor=(sender,e)=>
                        {
                            if(displayError!=null || !Entry.RoutePreviewEnabled || !e.Context.PointComputed) return;
                            try
                            {
                                var point=Snap(e.Context.ComputedPoint);
                                double length=new Point3d(start.X,start.Y,0).DistanceTo(new Point3d(point.X,point.Y,0));
                                if(length<1e-6 || Math.Abs(point.Z)>1e-6)return;
                                if(ghost is Mline ml)ml.MoveVertexAt(1,point);
                                else
                                {
                                    SetSize(preview,lengthProperty,length);
                                    ((BlockReference)ghost).Rotation=Math.Atan2(point.Y-start.Y,point.X-start.X);
                                }
                                ghost.RecordGraphicsModified(true);
                                e.Context.DrawContext.Geometry.Draw(ghost);
                            }
                            catch(System.Exception ex){displayError=ex.Message;}
                        };
                        var options=new PromptPointOptions("\nDiem tiep / [Size/Back/Center] (Enter ket thuc): ")
                        {BasePoint=new Point3d(start.X,start.Y,0),UseBasePoint=true,AllowNone=true};
                        options.Keywords.Add("Size");options.Keywords.Add("Back");options.Keywords.Add("Center");options.AppendKeywordsToMessage=false;
                        PromptPointResult picked;
                        editor.PointMonitor+=monitor;
                        try {picked=editor.GetPoint(options);}
                        finally {editor.PointMonitor-=monitor;}
                        if(picked.Status==PromptStatus.Cancel)return "CANCEL";
                        if(displayError!=null)editor.WriteMessage("\nPreview khong hien duoc: "+displayError+". Diem da chon van duoc giu.");
                        if(picked.Status==PromptStatus.None)return "END";
                        if(picked.Status==PromptStatus.Keyword)return picked.StringResult;
                        Need(picked.Status==PromptStatus.OK,"Preview: khong lay duoc diem.");
                        // Return the original picked point. LISP applies the identical snap
                        // rule before committing; Center keyword retains its existing bypass.
                        return PointText(picked.Value);
                    }
                }
            }
            catch(Autodesk.AutoCAD.Runtime.Exception ex) when(ex.ErrorStatus==ErrorStatus.UserBreak){return "CANCEL";}
            catch(System.Exception ex){return "ERROR: "+ex.Message;}
        }
        private static void SetSize(Database database,DynamicBlockReferenceProperty property,double value)
        {
            var old=HostApplicationServices.WorkingDatabase;
            try
            {
                HostApplicationServices.WorkingDatabase=database;
                property.Value=Convert.ChangeType(value,property.Value.GetType(),CultureInfo.InvariantCulture);
                Need(Math.Abs(Convert.ToDouble(property.Value,CultureInfo.InvariantCulture)-value)<0.01,
                    "Preview: block khong nhan dung kich thuoc "+property.PropertyName);
            }
            finally {HostApplicationServices.WorkingDatabase=old;}
        }
    }
}
