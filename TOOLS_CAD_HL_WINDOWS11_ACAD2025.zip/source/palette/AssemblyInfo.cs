using System.Reflection;
using System.Runtime.Versioning;
[assembly: AssemblyTitle("Tools Cad HL")]
[assembly: AssemblyDescription("Dockable system palettes for AutoCAD 2025 Windows")]
[assembly: AssemblyVersion("0.14.21.0")]
[assembly: AssemblyFileVersion("0.14.21.0")]
[assembly: SupportedOSPlatform("windows6.1")]
