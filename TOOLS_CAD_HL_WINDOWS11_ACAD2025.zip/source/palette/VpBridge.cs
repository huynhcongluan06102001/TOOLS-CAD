using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Globalization;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.Runtime;
using AcApp=Autodesk.AutoCAD.ApplicationServices.Core.Application;
namespace ToolsCad {
 public static partial class Upvc2Bridge {
  [LispFunction("TC_VP_JOIN_024")]
  public static string VpJoin(ResultBuffer args) {
   try {var v=args.AsArray();Need(v.Length==13,"VP: du lieu khong hop le.");
    return Upvc2Batch.Join((string)v[1].Value,(string)v[2].Value,h=>{
     var one=(TypedValue[])v.Clone();one[1]=new TypedValue((int)LispDataType.Text,h);return VpOne(one);});
   }catch(System.Exception ex){return "ERROR: VP: "+ex.Message;}
  }
  private static string VpOne(TypedValue[] v) {
   string path=null;
   try {
    string code=(string)v[0].Value;bool cross=code=="VP2T", angled=code=="VP1T+1E45";
    Need(cross||angled||code=="VP1T+1E90","Mau VP khong hop le.");
    double dn=Number(v[3].Value),dn2=Number(v[4].Value),lap=Number(v[7].Value);
    Need(Profile.Diameters("UPVC").Contains(dn)&&Profile.Diameters("UPVC").Contains(dn2)&&dn>=dn2,"Size VP khong hop le.");
    Need(lap>=0&&!double.IsInfinity(lap)&&!double.IsNaN(lap),"Ngam khong hop le.");
    bool trim=(string)v[8].Value=="1";string mat=(string)v[9].Value,branchMat=(string)v[12].Value;
    var db=AcApp.DocumentManager.MdiActiveDocument.Database;
    path=Path.Combine(Path.GetTempPath(),"ToolsCadVP-"+Guid.NewGuid().ToString("N")+".dwg");
    using(var input=Assembly.GetExecutingAssembly().GetManifestResourceStream("ToolsCad.VP.dwg"))
    using(var output=File.Create(path)){Need(input!=null,"Thieu VP.dwg.");input.CopyTo(output);}
    using(var sample=new Database(false,true)) {
     sample.ReadDwgFile(path,FileOpenMode.OpenForReadAndAllShare,true,null);sample.CloseInput(true);
     using(var sr=sample.TransactionManager.StartTransaction())
     using(var tr=db.TransactionManager.StartTransaction()) {
      var main=Run((Entity)tr.GetObject(Id(db,(string)v[1].Value),OpenMode.ForRead),tr,dn);
      var branch=Run((Entity)tr.GetObject(Id(db,(string)v[2].Value),OpenMode.ForRead),tr,dn2);
      Need(main.ObjectId!=branch.ObjectId&&main.OwnerId==branch.OwnerId,"Chon hai MLINE khac nhau cung Model.");
      foreach(var e in new[]{main,branch})Need(!((LayerTableRecord)tr.GetObject(e.LayerId,OpenMode.ForRead)).IsLocked,"Layer dang khoa.");
      var a=V(main.VertexAt(0));var b=V(main.VertexAt(1));var x=(b-a).Unit;var y=x.Perp;
      var anchor=new U2Point(Number(v[10].Value),Number(v[11].Value));var flow=new U2Point(Number(v[5].Value),Number(v[6].Value));
      Need(Math.Abs((flow-anchor).Dot(x))>1e-5,"Hai click huong phai khac nhau tren ong chinh.");
      if((flow-anchor).Dot(x)<0)x=x*(-1);y=x.Perp;
      var q0=V(branch.VertexAt(0));var q1=V(branch.VertexAt(1));
      Need(Math.Abs((q1-q0).Unit.Dot(x))<=Math.Sin(Math.PI/36)+1e-9,"VP can nhanh vuong goc ong chinh (+/-5 do).");
      var far=Math.Abs((q0-a).Dot(y))>=Math.Abs((q1-a).Dot(y))?q0:q1;
      if((far-a).Dot(y)<0)y=y*(-1);
      var origin=a+x*((far-a).Dot(x));
      if(cross)Need((q0-origin).Dot(y)*(q1-origin).Dot(y)<0,"VP2T can nhanh di qua hai phia ong chinh.");
      var sourceSpace=(BlockTableRecord)sr.GetObject(SymbolUtilityServices.GetBlockModelSpaceId(sample),OpenMode.ForRead);
      var refs=sourceSpace.Cast<ObjectId>().Select(id=>sr.GetObject(id,OpenMode.ForRead)).OfType<BlockReference>().ToArray();
      var table=(BlockTable)tr.GetObject(db.BlockTableId,OpenMode.ForRead);var space=(BlockTableRecord)tr.GetObject(main.OwnerId,OpenMode.ForWrite);
      string N(double d)=>d.ToString("0",CultureInfo.InvariantCulture);
      BlockReference Make(string sourceName,U2Point at,string targetName,ObjectId layer) {
       var reference=refs.Where(r=>Name(r,sr)==sourceName).OrderBy(r=>(V(r.Position)-at).Length).First();
       Need((V(reference.Position)-at).Length<1,"Mau VP sai phien ban.");Need(table.Has(targetName),"Thieu block "+targetName);
       var target=new BlockReference(Point3d.Origin,table[targetName]){Rotation=reference.Rotation,ScaleFactors=reference.ScaleFactors,LayerId=layer,ColorIndex=256};
       space.AppendEntity(target);tr.AddNewlyCreatedDBObject(target,true);States(reference,target);return target;
      }
      var sourceMain=cross?new U2Point(2902.369,1951.640):angled?new U2Point(-2215.534,2419.793):new U2Point(-6785.273,2453.317);
      var tee=Make("TEE-D90x60",sourceMain,"TEE-D"+N(dn)+"x"+N(dn2),main.LayerId);
      var fitting=Make(cross?"TEE-D60x60":angled?"ELB45-D60":"ELB90-D60",
       cross?sourceMain:angled?new U2Point(-2215.534,2686.823):sourceMain,
       cross?"TEE-D"+N(dn2)+"x"+N(dn2):(angled?"ELB45-D":"ELB90-D")+N(dn2),branch.LayerId);
      U2Face Port(BlockReference block,double size,bool horizontal,int sign) {
       var faces=Faces(block,size).Where(f=>horizontal?Math.Abs(f.Tangent.Y)>.9998&&Math.Abs(f.Center.Y)<size*.05:Math.Abs(f.Tangent.X)>.9998&&Math.Abs(f.Center.X)<size*.05).ToArray();
       Need(faces.Length>0,"Khong tim duoc cong VP dung huong.");return faces.OrderByDescending(f=>sign*(horizontal?f.Center.X:f.Center.Y)).First();
      }
      var low=Port(tee,dn,true,-1).Center;var high=Port(tee,dn,true,1).Center;
      double offset=angled?(2686.823-2419.793)*dn2/60:0;
      var branchLow=cross?Port(fitting,dn2,false,-1).Center:new U2Point(0,offset);
      var branchHigh=cross?Port(fitting,dn2,false,1).Center:new U2Point(0,offset);
      U2Point World(U2Point p)=>origin+x*p.X+y*p.Y;
      var u=(b-a).Unit;double lo=Math.Min((World(low)-a).Dot(u),(World(high)-a).Dot(u));double hi=Math.Max((World(low)-a).Dot(u),(World(high)-a).Dot(u));
      Need(lo>dn*.1&&hi<(b-a).Length-dn*.1,"Cum VP vuot dau ong chinh.");
      Need((far-World(branchHigh)).Dot(y)>dn2*.1,"Nhanh qua ngan cho cum VP.");
      if(cross)Need(Math.Min((q0-origin).Dot(y),(q1-origin).Dot(y))<branchLow.Y-dn2*.1,"Nhanh duoi qua ngan.");
      if(angled){var from=Port(tee,dn2,false,1).Center;var to=Port(fitting,dn2,false,-1).Center+new U2Point(0,offset);
       Need(to.Y>from.Y,"Hai phu kien VP chong nhau.");Pipe(space,tr,branch,World(from),World(to),dn2,db,branchMat);}
      fitting.Position=new Point3d(0,offset,0);
      var matrix=new Matrix3d(new[]{x.X,y.X,0,origin.X,x.Y,y.Y,0,origin.Y,0,0,1,0,0,0,0,1});
      foreach(var part in new[]{tee,fitting}){part.TransformBy(matrix);Meta(part,tr,db,"TC_SYSTEM","UPVC");Meta(part,tr,db,"TC_FITTING","1");Meta(part,tr,db,"TC_UPVC2",code);Meta(part,tr,db,"VAT LIEU",part==tee?mat:branchMat);Meta(part,tr,db,"TC_DN",N(part==tee?dn:dn2));}
      string pool=main.Handle.ToString();
      if(trim){double mlap=Math.Min(lap,dn*.2),blap=Math.Min(lap,dn2*.2);
       var left=Pipe(space,tr,main,a,a+u*(lo+mlap),dn,db,mat);var right=Pipe(space,tr,main,a+u*(hi-mlap),b,dn,db,mat);pool=left.Handle+","+right.Handle;
       if(cross){var top=(q0-origin).Dot(y)>0?q0:q1;var bottom=(q0-origin).Dot(y)<0?q0:q1;
        Pipe(space,tr,branch,origin+y*((top-origin).Dot(y)),World(branchHigh)-y*blap,dn2,db,branchMat);
        Pipe(space,tr,branch,World(branchLow)+y*blap,origin+y*((bottom-origin).Dot(y)),dn2,db,branchMat);
        branch.UpgradeOpen();branch.Erase();
       }else{branch.UpgradeOpen();branch.MoveVertexAt((far-q0).Length<1e-5?1:0,P(World(branchHigh)-y*blap));}
       main.UpgradeOpen();main.Erase();
      }
      tr.Commit();return "OK|"+pool;
     }
    }
   }catch(System.Exception ex){return "ERROR: VP: "+ex.Message;}
   finally{if(path!=null)try{File.Delete(path);}catch(IOException){}}
  }
 }
}
