using System;
using System.Collections.Generic;
using System.Linq;
namespace ToolsCad {
 public readonly struct HPoint {
  public readonly double X,Y;
  public HPoint(double x,double y){X=x;Y=y;}
  public static HPoint operator +(HPoint a,HPoint b)=>new HPoint(a.X+b.X,a.Y+b.Y);
  public static HPoint operator -(HPoint a,HPoint b)=>new HPoint(a.X-b.X,a.Y-b.Y);
  public static HPoint operator *(HPoint a,double b)=>new HPoint(a.X*b,a.Y*b);
  public double Length=>Math.Sqrt(X*X+Y*Y);
  public HPoint Unit=>this*(1/Length);
  public HPoint Perp=>new HPoint(-Y,X);
  public static double Cross(HPoint a,HPoint b)=>a.X*b.Y-a.Y*b.X;
 }
 public static class HiddenBoundary {
  public static HPoint[] Build(IReadOnlyList<HPoint> vertices,double low,double high) {
   if(vertices.Count<2||!double.IsFinite(low)||!double.IsFinite(high)||high-low<1e-8)throw new ArgumentException("MLINE width/vertices invalid.");
   if(vertices.Any(p=>!double.IsFinite(p.X)||!double.IsFinite(p.Y)))throw new ArgumentException("Nonfinite vertex.");
   var dirs=new HPoint[vertices.Count-1];
   for(int i=0;i<dirs.Length;i++){var d=vertices[i+1]-vertices[i];if(d.Length<1e-7)throw new ArgumentException("Duplicate MLINE vertices.");dirs[i]=d.Unit;}
   HPoint[] Side(double offset) {
    var points=new List<HPoint>{vertices[0]+dirs[0].Perp*offset};
    for(int i=1;i<vertices.Count-1;i++) {
     var a=dirs[i-1];var b=dirs[i];double cross=HPoint.Cross(a,b);
     if(Math.Abs(cross)<1e-9) {
      if((a+b).Length<1)throw new ArgumentException("MLINE reverses direction.");
      points.Add(vertices[i]+b.Perp*offset);
     } else {
      var q=vertices[i]+a.Perp*offset;
      var t=HPoint.Cross((b.Perp-a.Perp)*offset,b)/cross;
      if(Math.Abs(t)>Math.Min((vertices[i]-vertices[i-1]).Length,(vertices[i+1]-vertices[i]).Length))throw new ArgumentException("MLINE corner too short for width.");
      points.Add(q+a*t);
     }
    }points.Add(vertices[vertices.Count-1]+dirs[dirs.Length-1].Perp*offset);return points.ToArray();
   }
   var ring=Side(high).Concat(Side(low).Reverse()).ToArray();
   double area=0;for(int i=0;i<ring.Length;i++)area+=HPoint.Cross(ring[i],ring[(i+1)%ring.Length]);
   if(Math.Abs(area)<1e-8)throw new ArgumentException("Empty MLINE boundary.");
   for(int i=0;i<ring.Length;i++)for(int j=i+2;j<ring.Length;j++) {
    if(i==0&&j==ring.Length-1)continue;
    var a=ring[i];var b=ring[(i+1)%ring.Length];var c=ring[j];var d=ring[(j+1)%ring.Length];
    double den=HPoint.Cross(b-a,d-c);
    if(Math.Abs(den)<1e-10) {
     if(Math.Abs(HPoint.Cross(c-a,b-a))<1e-8 && Math.Max(Math.Min(a.X,b.X),Math.Min(c.X,d.X))<=Math.Min(Math.Max(a.X,b.X),Math.Max(c.X,d.X))+1e-8 && Math.Max(Math.Min(a.Y,b.Y),Math.Min(c.Y,d.Y))<=Math.Min(Math.Max(a.Y,b.Y),Math.Max(c.Y,d.Y))+1e-8)
      throw new ArgumentException("Overlapping MLINE boundary.");
    } else {
     double t=HPoint.Cross(c-a,d-c)/den,u=HPoint.Cross(c-a,b-a)/den;
     if(t>=-1e-9&&t<=1+1e-9&&u>=-1e-9&&u<=1+1e-9)throw new ArgumentException("Self-intersecting MLINE boundary.");
    }
   }
   return ring;
  }
 }
}
