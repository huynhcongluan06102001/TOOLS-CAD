using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Runtime;
using AcApp = Autodesk.AutoCAD.ApplicationServices.Core.Application;
[assembly: CommandClass(typeof(ToolsCad.LibraryBridge))]
namespace ToolsCad
{
    public static class LibraryBridge
    {
        private static string selectedLibrary;
        private static string Quote(string s) => "\"" + s.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\n", "\\n").Replace("\r", "\\r") + "\"";
        [LispFunction("TC_LIBRARY_NAMES_013")]
        public static string Names(ResultBuffer args)
        {
            try
            {
                var path = (string)args.AsArray()[0].Value;
                using (var db = new Database(false, true))
                {
                    db.ReadDwgFile(path, FileOpenMode.OpenForReadAndAllShare, true, null);
                    db.CloseInput(true);
                    using (var tr = db.TransactionManager.StartOpenCloseTransaction())
                    {
                        var result = new List<string>();
                        foreach (ObjectId id in (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead))
                        {
                            var b = (BlockTableRecord)tr.GetObject(id, OpenMode.ForRead);
                            if (!b.IsLayout && !b.IsAnonymous && !b.IsFromExternalReference) result.Add(Quote(b.Name));
                        }
                        selectedLibrary = path;
                        return "(" + string.Join(" ", result) + ")";
                    }
                }
            }
            catch (System.Exception ex) { return "ERROR: " + ex.Message; }
        }
        public static string[] LoadMlineStyles()
        {
            if (string.IsNullOrEmpty(selectedLibrary))
                throw new InvalidOperationException("Chọn file thư viện DWG trước, rồi nhấn Nạp style.");
            var doc = AcApp.DocumentManager.MdiActiveDocument;
            if (doc == null) throw new InvalidOperationException("Mở bản vẽ đích trước.");
            var names = new List<string> { "Standard" };
            using (doc.LockDocument())
            using (var source = new Database(false, true))
            {
                source.ReadDwgFile(selectedLibrary, FileOpenMode.OpenForReadAndAllShare, true, null);
                source.CloseInput(true);
                var ids = new ObjectIdCollection();
                using (var tr = source.TransactionManager.StartOpenCloseTransaction())
                {
                    var dictionary = (DBDictionary)tr.GetObject(source.MLStyleDictionaryId, OpenMode.ForRead);
                    foreach (DBDictionaryEntry item in dictionary)
                    {
                        if (string.Equals(item.Key, "Standard", StringComparison.OrdinalIgnoreCase)) continue;
                        names.Add(item.Key); ids.Add(item.Value);
                    }
                    if (ids.Count > 0)
                        source.WblockCloneObjects(ids, doc.Database.MLStyleDictionaryId,
                            new IdMapping(), DuplicateRecordCloning.Ignore, false);
                }
            }
            return names.ToArray();
        }
        [LispFunction("TC_LIBRARY_IMPORT_013")]
        public static string Import(ResultBuffer args)
        {
            string temporary=null;
            try
            {
                var values = args.AsArray(); var path = (string)values[0].Value; var name = (string)values[1].Value;
                if(path=="@STEEL028") {
                    temporary=Path.Combine(Path.GetTempPath(),"ToolsCadSteel-"+Guid.NewGuid().ToString("N")+".dwg");
                    using(var input=Assembly.GetExecutingAssembly().GetManifestResourceStream("ToolsCad.STEEL028.dwg"))
                    using(var output=File.Create(temporary))input.CopyTo(output);
                    path=temporary;
                }
                var doc = AcApp.DocumentManager.MdiActiveDocument;
                if (doc == null) return "ERROR: Mo ban ve dich truoc.";
                using (doc.LockDocument())
                using (var db = new Database(false, true))
                {
                    db.ReadDwgFile(path, FileOpenMode.OpenForReadAndAllShare, true, null);
                    db.CloseInput(true);
                    using (var tr = db.TransactionManager.StartOpenCloseTransaction())
                    {
                        var table = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
                        if (!table.Has(name)) return "ERROR: Thu vien thieu block: " + name;
                        var block = (BlockTableRecord)tr.GetObject(table[name], OpenMode.ForRead);
                        if (block.IsLayout || block.IsFromExternalReference) return "ERROR: Khong nhap layout/Xref.";
                        db.WblockCloneObjects(new ObjectIdCollection(new[] {block.ObjectId}), doc.Database.BlockTableId,
                            new IdMapping(), DuplicateRecordCloning.Ignore, false);
                        return "OK";
                    }
                }
            }
            catch (System.Exception ex) { return "ERROR: " + ex.Message; }
            finally { if(temporary!=null&&File.Exists(temporary))File.Delete(temporary); }
        }
    }
}
