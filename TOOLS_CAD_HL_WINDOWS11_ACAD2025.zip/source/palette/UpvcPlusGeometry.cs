using System;
using System.Linq;
namespace ToolsCad
{
    // Socket offsets are measured from the supplied before/after drawing, in mm.
    public sealed class PlusPart
    {
        public readonly U2Point At;
        public readonly string Name;
        public readonly U2Point In, Out;
        public PlusPart(string name,double x,double y,U2Point input,U2Point output)
        {Name=name;At=new U2Point(x,y);In=input;Out=output;}
    }
    public sealed class PlusRecipe
    {
        public readonly string Code;
        public readonly PlusPart[] Parts;
        public readonly double Heading, SampleSize;
        public bool Corner => Code=="1E45"||Code=="2E45";
        public bool TwoRisers => Code=="VPB-M"||Code=="2Z1YU+3E45";
        public PlusRecipe(string code,double heading,double size,params PlusPart[] parts)
        {Code=code;Heading=heading*Math.PI/180;SampleSize=size;Parts=parts;}
        private static U2Point Q(double x,double y)=>new U2Point(x,y);
        public static readonly PlusRecipe[] All={
            new PlusRecipe("VPB-M",107.104488396658,114,
                new PlusPart("Y-D168x114",6893.617185,2497.776367,Q(0,0),Q(-49.283,160.174)),
                new PlusPart("ELB45-D114",6809.953840,2769.658637,Q(3.657,-11.822),Q(0,0))),
            new PlusRecipe("1Z1YU+1E45",107.104488396658,114,
                new PlusPart("Y-D168x114",9261.733723,2490.856001,Q(0,0),Q(-35.147,114.216)),
                new PlusPart("ELB45-D114",9166.564586,2800.121898,Q(34.649,-112.599),Q(0,0))),
            new PlusRecipe("2Z1YU+3E45",107.104488396658,114,
                new PlusPart("Y-D168x114",11775.266228,2497.776367,Q(0,0),Q(-35.147,114.216)),
                new PlusPart("ELB45-D114",11680.097092,2807.042263,Q(34.650,-112.599),Q(0,0)),
                new PlusPart("ELB45-D114",11600.353677,3066.180042,Q(0,0),Q(-26.664,86.352)),
                new PlusPart("ELB45-D114",11533.086013,3284.031050,Q(16.272,-52.699),Q(0,0))),
            new PlusRecipe("1E45",0,168,
                new PlusPart("ELB45-D168",18485.610890,3459.326259,Q(-120,0),Q(84.852814,-84.852814))),
            new PlusRecipe("2E45",0,168,
                new PlusPart("ELB45-D168",15132.669040,3459.326259,Q(-120,0),Q(84.852814,-84.852814)),
                new PlusPart("ELB45-D168",15321.234851,3270.760447,Q(-84.852814,84.852814),Q(0,-120)))
        };
        public static PlusRecipe For(string code)=>All.FirstOrDefault(r=>r.Code==code)??throw new ArgumentException("Mau UPVC+ khong hop le.");
        public U2Point Local(U2Point p)=>PlusGeometry.Rotate(p,-Heading);
        public double Gap(int index)
        {
            var left=Parts[index-1];var right=Parts[index];
            return (right.At+right.In-left.At-left.Out).Length;
        }
    }
    public static class PlusGeometry
    {
        public static readonly string[][] ButtonRows={
            new[]{"MP1Y+1E1","RS1Y+1E1"},new[]{"MP1Y+1E2","RS1Y+1E2"},
            new[]{"MP1Y+2E1","RS1Y+2E1"},new[]{"MP1Y+2E2","RS1Y+2E2"},
            new[]{"MP1Y+3E1","RS1Y+3E1"},new[]{"MP1Y+3E2","RS1Y+3E2"},
            new[]{"VP1T+1E90","1Z1YU+1E45"},new[]{"VP1T+1E45","2Z1YU+3E45"},
            new[]{"VP2T","1E45"},new[]{"VPB-M","2E45"}};
        public static U2Point Rotate(U2Point p,double r)=>new U2Point(p.X*Math.Cos(r)-p.Y*Math.Sin(r),p.X*Math.Sin(r)+p.Y*Math.Cos(r));
        public static double Cross(U2Point a,U2Point b)=>a.X*b.Y-a.Y*b.X;
        public static U2Point Intersect(U2Point a,U2Point u,U2Point b,U2Point v)
        {
            double cross=Cross(u,v);if(Math.Abs(cross)<1e-8)throw new InvalidOperationException("Hai huong noi song song.");
            return a+u*(Cross(b-a,v)/cross);
        }
        public static U2Point Socket(System.Collections.Generic.IEnumerable<U2Face> faces,U2Point expected,double size,double sampleSize)
        {
            if(expected.Length<.01)return new U2Point(0,0);
            double turn=Math.Round(Math.Atan2(expected.Y,expected.X)/(Math.PI/4))*(Math.PI/4);
            var axis=new U2Point(Math.Cos(turn),Math.Sin(turn));var wanted=expected*(size/sampleSize);
            var face=faces.Where(f=>Math.Abs(f.Tangent.Dot(axis))<.02&&Math.Abs(f.Center.Dot(axis.Perp))<size*.03)
                .OrderBy(f=>(f.Center-wanted).Length+Math.Abs(f.Width-size)*.05).FirstOrDefault();
            if(face==null||(face.Center-wanted).Length>=size)
                throw new InvalidOperationException("Khong tim thay cong block dung mau/size. Giu nguyen doi tuong goc.");
            return axis*face.Center.Dot(axis);
        }
        public static U2Point[] Chain(PlusRecipe recipe,U2Point[] input,U2Point[] output,double ratio,double? anchorDistance=null)
        {
            int n=recipe.Parts.Length;var at=new U2Point[n];
            for(int i=1;i<n;i++) {
                var delta=recipe.Local(recipe.Parts[i].At+recipe.Parts[i].In-recipe.Parts[i-1].At-recipe.Parts[i-1].Out);
                var axis=recipe.Corner?new U2Point(1,-1).Unit:new U2Point(1,0);
                if(delta.Dot(axis)<=0)throw new InvalidOperationException("Mau co cong noi dao huong.");
                at[i]=at[i-1]+output[i-1]+axis*(recipe.Gap(i)*ratio)-input[i];
            }
            if(anchorDistance.HasValue) {
                if(!recipe.TwoRisers)throw new ArgumentException("Mau khong phai hai truc dung.");
                // Keep the terminal elbow at the selected riser; only the middle pipe stretches.
                int moving=recipe.Code=="VPB-M"?1:2;
                var shift=new U2Point(anchorDistance.Value,0)-at[n-1];
                for(int i=moving;i<n;i++)at[i]+=shift;
            }
            for(int i=1;i<n;i++) {
                var axis=recipe.Corner?new U2Point(1,-1).Unit:new U2Point(1,0);
                var delta=at[i]+input[i]-at[i-1]-output[i-1];
                if(delta.Dot(axis)<=0.01||Math.Abs(delta.Dot(axis.Perp))>0.01)
                    throw new InvalidOperationException("Hai truc/ong qua gan hoac cong phu kien khong dong truc. Giu nguyen ong goc.");
            }
            return at;
        }
        public static (U2Point Origin,U2Point X,U2Point Y,int NearA,int NearB) Corner(
            U2Point a,U2Point b,U2Point c,U2Point d,bool single,U2Point input,U2Point output,double diameter)
        {
            var aa=new[]{a,b};var bb=new[]{c,d};int ia=0,ib=0;double best=double.MaxValue;
            for(int i=0;i<2;i++)for(int j=0;j<2;j++)if((aa[i]-bb[j]).Length<best){best=(aa[i]-bb[j]).Length;ia=i;ib=j;}
            var x=(aa[ia]-aa[1-ia]).Unit;var y=x.Perp;
            var second=(bb[1-ib]-bb[ib]).Unit;
            if(second.Dot(y)>0)y=y*(-1);
            var localOut=single?new U2Point(1,-1).Unit:new U2Point(0,-1);
            var outlet=x*localOut.X+y*localOut.Y;
            if(second.Dot(outlet)<Math.Cos(Math.PI/36)-1e-9)
                throw new InvalidOperationException(single?"1E45 can hai ong doi huong 45 do (+/-5 do).":"2E45 can hai ong doi huong 90 do (+/-5 do).");
            U2Point Map(U2Point p)=>x*p.X+y*p.Y;
            var origin=Intersect(aa[1-ia]-Map(input),x,bb[1-ib]-Map(output),outlet);
            if((aa[1-ia]-origin-Map(input)).Dot(x*(-1))<=diameter*.1 || (bb[1-ib]-origin-Map(output)).Dot(outlet)<=diameter*.1)
                throw new InvalidOperationException("Ong qua ngan de chen co. Giu nguyen ong goc.");
            return (origin,x,y,ia,ib);
        }
    }
}
