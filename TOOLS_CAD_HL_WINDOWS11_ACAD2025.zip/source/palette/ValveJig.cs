using System;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.GraphicsInterface;
using AcApp=Autodesk.AutoCAD.ApplicationServices.Core.Application;
namespace ToolsCad
{
    public static partial class Upvc2Bridge
    {
        // Freeze the evaluated visible geometry once per phase/state. Mouse movement only
        // changes a world-draw matrix; no dynamic block or attribute is edited during dragging.
        private sealed class ValveJig : DrawJig
        {
            private readonly ValveSession session;
            private readonly DBObjectCollection preview=new DBObjectCollection();
            private readonly bool rotating;
            private readonly double basis,originalAngle;
            private readonly Point3d originalPoint;
            private Point3d targetPoint,last;
            private double targetAngle;
            private bool sampled;
            public Point3d Point {get;private set;}
            public PromptStatus InputStatus;public string Keyword;
            public ValveJig(BlockReference b,ValveSession s,Transaction tr,bool rotate)
            {
                session=s;rotating=rotate;basis=ValveUcsAngle();
                originalPoint=b.Position;originalAngle=b.Rotation;
                targetPoint=originalPoint;targetAngle=originalAngle;
                Point=P(V(b.Position)+PlusGeometry.Rotate(s.InsertionOffset,b.Rotation));
                try {
                    b.Explode(preview);
                    foreach(ObjectId id in b.AttributeCollection) {
                        var attribute=(AttributeReference)tr.GetObject(id,OpenMode.ForRead);
                        if(!attribute.Invisible)preview.Add((DBObject)attribute.Clone());
                    }
                }catch {DisposePreview();throw;}
            }
            public void DisposePreview(){foreach(DBObject item in preview)item.Dispose();preview.Dispose();}
            protected override SamplerStatus Sampler(JigPrompts prompts)
            {
                var options=new JigPromptPointOptions(rotating?
                    "\nRe chuot xem van xoay 45 do; click chot; Space doi trang thai: ":
                    "\nChon diem chen goc cua block (OSNAP); Space doi trang thai: ");
                options.UserInputControls=UserInputControls.Accept3dCoordinates|UserInputControls.NullResponseAccepted|UserInputControls.AnyBlankTerminatesInput;
                if(rotating){options.BasePoint=P(session.Anchor);options.UseBasePoint=true;}
                var result=prompts.AcquirePoint(options);InputStatus=result.Status;Keyword=result.StringResult;
                if(result.Status!=PromptStatus.OK)return SamplerStatus.Cancel;
                Point=result.Value;
                double angle=originalAngle;
                if(rotating) {
                    var d=V(Point)-session.Anchor;
                    // A confirmation at the same point/within the same 45-degree sector
                    // must reach Drag as OK. Redraw optimization must not filter user input.
                    angle=targetAngle;
                    if(d.Length>=1e-6) {
                        double raw=Math.Atan2(d.Y,d.X);
                        angle=session.Pipe.IsNull?ValveGeometry.Snap45(raw,basis):
                            session.PipeAngle-session.PortAngle+(Math.Cos(raw-session.PipeAngle)<0?Math.PI:0);
                    }
                }else if(sampled&&Point.DistanceTo(last)<1e-6)return SamplerStatus.NoChange;
                targetAngle=angle;
                var center=rotating?session.Anchor:V(Point);
                targetPoint=P(center-PlusGeometry.Rotate(session.InsertionOffset,angle));
                last=Point;sampled=true;return SamplerStatus.OK;
            }
            protected override bool WorldDraw(WorldDraw draw)
            {
                var delta=Matrix3d.Displacement(targetPoint-Point3d.Origin)*
                    Matrix3d.Rotation(targetAngle-originalAngle,Vector3d.ZAxis,Point3d.Origin)*
                    Matrix3d.Displacement(Point3d.Origin-originalPoint);
                draw.Geometry.PushModelTransform(delta);
                try {
                    foreach(DBObject item in preview)
                        if(item is Entity e&&e.Visible&&!(e is AttributeDefinition))draw.Geometry.Draw(e);
                }finally{draw.Geometry.PopModelTransform();}
                return true;
            }
            public void Apply(BlockReference block,Transaction transaction)
            {
                ValvePose(block,targetPoint,targetAngle,transaction);
                if(!rotating)session.Anchor=V(Point);
                block.RecordGraphicsModified(true);
            }
        }
        private static ResultBuffer ValveArguments(params object[] values)
        {
            var result=new ResultBuffer();foreach(var v in values)
                result.Add(new TypedValue(v is string?(int)LispDataType.Text:(int)LispDataType.Double,v));
            return result;
        }
        [LispFunction("TC_VALVE_INTERACT_029")]
        public static string ValveInteract(ResultBuffer args)=>ValveCall(()=>{
            var values=args.AsArray();string handle=(string)values[0].Value;
            double overlap=Number(values[1].Value),tolerance=Number(values[2].Value);
            var s=ValveActive(handle);var ed=AcApp.DocumentManager.MdiActiveDocument.Editor;
            int snaps=Convert.ToInt32(AcApp.GetSystemVariable("OSMODE"));
            // Dense dynamic blocks make running intersection snaps very expensive.
            // Keep native point acquisition; never call Lisp osnap in a mouse loop.
            AcApp.SetSystemVariable("OSMODE",(snaps & ~(32|2048))|512);
            try {
                bool rotating=false;
                while(true) {
                    PromptResult response;Point3d point;PromptStatus input;string keyword;
                    ValveJig jig;
                    using(var tr=s.Db.TransactionManager.StartTransaction()) {
                        var b=(BlockReference)tr.GetObject(s.Id,OpenMode.ForWrite);
                        jig=new ValveJig(b,s,tr,rotating);
                        b.Visible=false;b.RecordGraphicsModified(true);tr.Commit();
                    }
                    try {
                        ed.Regen(); // Clear the previous state's screen image before starting a new drag.
                        response=ed.Drag(jig);point=jig.Point;input=jig.InputStatus;keyword=jig.Keyword;
                        using(var tr=s.Db.TransactionManager.StartTransaction()) {
                            var b=(BlockReference)tr.GetObject(s.Id,OpenMode.ForWrite);
                            if(response.Status==PromptStatus.OK||input==PromptStatus.None)jig.Apply(b,tr);
                            tr.Commit();
                        }
                    }finally {
                        jig.DisposePreview();
                        using(var tr=s.Db.TransactionManager.StartTransaction()) {
                            var b=(BlockReference)tr.GetObject(s.Id,OpenMode.ForWrite);
                            b.Visible=true;b.RecordGraphicsModified(true);tr.Commit();
                        }
                    }
                    // Drag result is authoritative for the final click, not a cached sampler status.
                    if(response.Status!=PromptStatus.OK&&input==PromptStatus.None) {
                        using(var a=ValveArguments(handle))ed.WriteMessage("\n"+ValveCycle(a));continue;
                    }
                    if(response.Status!=PromptStatus.OK)return "CANCEL";
                    if(!rotating) {
                        string pick;using(var a=ValveArguments(handle,point.X,point.Y,tolerance))pick=ValvePick(a);
                        if(pick.StartsWith("ERROR:")){ed.WriteMessage("\n"+pick);continue;}
                        rotating=true;continue;
                    }
                    string end;using(var a=ValveArguments(handle,"1",overlap))end=ValveEnd(a);
                    // Commit once. On failure the transaction preserves the original pipe;
                    // return the actual error instead of trapping the user in another drag.
                    return end;
                }
            }finally{AcApp.SetSystemVariable("OSMODE",snaps);ed.Regen();}
        });
    }
}
