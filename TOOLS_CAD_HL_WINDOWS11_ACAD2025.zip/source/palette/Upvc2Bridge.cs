using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.Runtime;
using AcApp=Autodesk.AutoCAD.ApplicationServices.Core.Application;
[assembly: CommandClass(typeof(ToolsCad.Upvc2Bridge))]
namespace ToolsCad
{
    // Reads visibility/flip states from the supplied DWG, never guesses state labels.
    // Each target fitting uses its own size-specific library definition at unit scale.
    public static class Upvc2Bridge
    {
        private sealed class Part
        {
            public BlockReference Source, Target;
            public U2Point SourcePosition, Position;
            public List<U2Face> ReferenceFaces, TargetFaces;
            
        }
        private static U2Point V(Point3d p)=>new U2Point(p.X,p.Y);
        private static Point3d P(U2Point p)=>new Point3d(p.X,p.Y,0);
        private static string Name(BlockReference b,Transaction tr)=>((BlockTableRecord)tr.GetObject(b.IsDynamicBlock?b.DynamicBlockTableRecord:b.BlockTableRecord,OpenMode.ForRead)).Name;
        private static void Need(bool ok,string message) { if(!ok) throw new InvalidOperationException(message); }
        private static double Number(object n)=>Convert.ToDouble(n,CultureInfo.InvariantCulture);
        private static ObjectId Id(Database db,string handle)=>db.GetObjectId(false,new Handle(long.Parse(handle,NumberStyles.HexNumber,CultureInfo.InvariantCulture)),0);
        private static List<U2Face> Faces(BlockReference block,double diameter)
        {
            var result=new List<U2Face>();
            var segments=new List<U2Face>();
            void Line(Point3d a,Point3d b)
            {
                double len=a.DistanceTo(b);
                if(len>1e-6 && Math.Abs(a.Z-b.Z)<1e-5)
                    segments.Add(new U2Face(V(a),V(b)));
            }
            void Walk(Entity entity,int depth)
            {
                if(!entity.Visible) return;
                if(entity is Line line) {Line(line.StartPoint,line.EndPoint);return;}
                // Projected up/down fittings use elliptical socket outlines rather than straight caps.
                if(entity is Ellipse ellipse) {Line(ellipse.Center-ellipse.MajorAxis,ellipse.Center+ellipse.MajorAxis);return;}
                if(entity is Circle circle)
                {
                    Line(circle.Center-Vector3d.XAxis*circle.Radius,circle.Center+Vector3d.XAxis*circle.Radius);
                    Line(circle.Center-Vector3d.YAxis*circle.Radius,circle.Center+Vector3d.YAxis*circle.Radius);return;
                }
                if(entity is Polyline poly)
                {
                    for(int i=0;i<poly.NumberOfVertices-(poly.Closed?0:1);i++)
                        if(Math.Abs(poly.GetBulgeAt(i))<1e-8) Line(poly.GetPoint3dAt(i),poly.GetPoint3dAt((i+1)%poly.NumberOfVertices));
                    return;
                }
                if(entity is BlockReference || entity is Polyline2d)
                {
                    Need(depth<8,"Block long qua nhieu cap.");
                    using(var children=new DBObjectCollection())
                    {
                        entity.Explode(children);
                        foreach(DBObject child in children) using(child) { if(child is Entity e) Walk(e,depth+1); }
                    }
                }
            }
            Walk(block,0);
            result=Upvc2Geometry.JoinCaps(segments).Where(f=>f.Width>=diameter*0.95 && f.Width<=diameter*1.65).ToList();
            Need(result.Count>0,"Khong doc duoc mat cong noi block. Kiem tra block/visibility.");
            return result;
        }
        private static void States(BlockReference source,BlockReference target)
        {
            Need(source.IsDynamicBlock,"Mau UPVCPRO mat dynamic properties.");
            Need(target.IsDynamicBlock,"Block thu vien phai la block dong co trang thai nhu UPVCPRO.");
            foreach(DynamicBlockReferenceProperty from in source.DynamicBlockReferencePropertyCollection)
            {
                // Copy visibility/lookup states and flip only. Never copy size/length parameters from D114.
                var options=from.GetAllowedValues();
                bool state=from.Value is string && options.Length>0;
                bool flip=from.PropertyName.IndexOf("flip",StringComparison.OrdinalIgnoreCase)>=0;
                if(!state && !flip) continue;
                DynamicBlockReferenceProperty match=null;
                foreach(DynamicBlockReferenceProperty to in target.DynamicBlockReferencePropertyCollection)
                {
                    if(to.ReadOnly) continue;
                    bool named=string.Equals(to.PropertyName,from.PropertyName,StringComparison.OrdinalIgnoreCase);
                    if(named || (state && to.GetAllowedValues().Any(v=>Equals(v,from.Value)))) {match=to;if(named) break;}
                }
                Need(match!=null,"Block thieu trang thai "+from.PropertyName+" = "+from.Value);
                Need(match.GetAllowedValues().Length==0 || match.GetAllowedValues().Any(v=>Equals(v,from.Value)),"Gia tri trang thai khong ho tro: "+from.Value);
                match.Value=from.Value;
                Need(Equals(match.Value,from.Value),"Khong dat duoc visibility/flip.");
            }
            target.RecordGraphicsModified(true);
        }
        private static U2Face MainFace(List<U2Face> faces,double sign)
        {
            var eligible=faces.Where(f=>Math.Abs(f.Tangent.X)>0.9998 && Math.Abs(f.Center.X)<f.Width*0.05).ToArray();
            Need(eligible.Length>0,"Khong tim thay cong thang cua chac Y.");
            return eligible.OrderByDescending(f=>sign*f.Center.Y).First();
        }
        private static U2Face OutFace(List<U2Face> faces,U2Point outward)
        {
            var eligible=faces.Where(f=>Math.Abs(f.Tangent.Dot(outward))<0.02).ToArray();
            Need(eligible.Length>0,"Khong tim thay cong ngang cua cum phu kien.");
            return eligible.OrderByDescending(f=>f.Center.Dot(outward)).First();
        }
        private static void Meta(Entity e,Transaction tr,Database db,string key,string value)
        {
            var apps=(RegAppTable)tr.GetObject(db.RegAppTableId,OpenMode.ForRead);
            if(!apps.Has(key)) {apps.UpgradeOpen();var app=new RegAppTableRecord{Name=key};apps.Add(app);tr.AddNewlyCreatedDBObject(app,true);}
            using(var data=new ResultBuffer(new TypedValue(1001,key),new TypedValue(1000,value))) e.XData=data;
        }
        private static Mline Pipe(BlockTableRecord space,Transaction tr,Mline source,U2Point a,U2Point b,double diameter,Database db,string material)
        {
            Need((b-a).Length>1e-5,"Doan ong con lai qua ngan.");
            var pipe=(Mline)source.Clone();
            pipe.MoveVertexAt(0,P(a));pipe.MoveVertexAt(1,P(b));
            var style=(MlineStyle)tr.GetObject(pipe.Style,OpenMode.ForRead);
            var offsets=style.Elements.Cast<MlineStyleElement>().Select(e=>e.Offset).ToArray();
            pipe.Scale=diameter/(offsets.Max()-offsets.Min());pipe.ColorIndex=256;
            space.AppendEntity(pipe);tr.AddNewlyCreatedDBObject(pipe,true);
            Meta(pipe,tr,db,"TC_SYSTEM","UPVC");Meta(pipe,tr,db,"VAT LIEU",material);
            Meta(pipe,tr,db,"TC_DN",diameter.ToString(CultureInfo.InvariantCulture));
            Meta(pipe,tr,db,"TC_WIDTH",diameter.ToString(CultureInfo.InvariantCulture));
            return pipe;
        }
        private static Mline Run(Entity entity,Transaction tr,double expected)
        {
            var ml=entity as Mline;Need(ml!=null && ml.NumberOfVertices==2 && ml.Justification==MlineJustification.Zero,"Chon MLINE thang, can tim (Zero), hai diem.");
            Need(Math.Abs(ml.VertexAt(0).Z)<1e-5 && Math.Abs(ml.VertexAt(1).Z)<1e-5 && ml.Normal.IsParallelTo(Vector3d.ZAxis),"UPVC2 ho tro WCS XY, Z=0.");
            var style=(MlineStyle)tr.GetObject(ml.Style,OpenMode.ForRead);
            var offsets=style.Elements.Cast<MlineStyleElement>().Select(e=>e.Offset).ToArray();
            Need(offsets.Length>=2,"MLINE style thieu hai bien ngoai.");
            Need(Math.Abs(Upvc2Geometry.Width(ml.Scale,offsets.Min(),offsets.Max())-expected)<0.1,"Size MLINE thay doi; chon lai ong.");return ml;
        }
        [LispFunction("TC_UPVC2_JOIN_017")]
        public static string Join(ResultBuffer args) => JoinCore(args, false);

        [LispFunction("TC_UPVC2_BATCH_JOIN_021")]
        public static string BatchJoin(ResultBuffer args)
        {
            try
            {
                var values=args.AsArray();
                Need(values.Length==12,"Du lieu noi hang loat khong hop le.");
                return Upvc2Batch.Join((string)values[1].Value,(string)values[2].Value,handle =>
                {
                    var one=(TypedValue[])values.Clone();
                    one[1]=new TypedValue((int)LispDataType.Text,handle);
                    using(var request=new ResultBuffer(one)) return JoinCore(request,true);
                });
            }
            catch(System.Exception ex) {return "ERROR: UPVC+ Select: "+ex.Message;}
        }

        private static string JoinCore(ResultBuffer args, bool returnMainHandles)
        {
            string path=null;
            try
            {
                var v=args.AsArray();string code=(string)v[0].Value;var recipe=Upvc2Recipe.For(code);bool riser=recipe.Riser;
                double dn=Number(v[3].Value),dn2=Number(v[4].Value),overlap=Number(v[7].Value);
                bool trim=(string)v[8].Value=="1";string material=(string)v[9].Value;
                Need(Profile.Diameters("UPVC").Contains(dn)&&Profile.Diameters("UPVC").Contains(dn2)&&dn>=dn2,"Size UPVC khong hop le hoac nhanh lon hon ong chinh.");
                Need(overlap>=0 && !double.IsInfinity(overlap) && !double.IsNaN(overlap),"Khoang ngam khong hop le.");
                var doc=AcApp.DocumentManager.MdiActiveDocument;Need(doc!=null,"Mo ban ve truoc.");var db=doc.Database;
                path=Path.Combine(Path.GetTempPath(),"ToolsCadHL-UPVC2-"+Guid.NewGuid().ToString("N")+".dwg");
                using(var input=Assembly.GetExecutingAssembly().GetManifestResourceStream("ToolsCad.UPVCPRO.dwg"))
                using(var output=File.Create(path)) {Need(input!=null,"Thieu mau UPVCPRO trong DLL.");input.CopyTo(output);}
                using(var sample=new Database(false,true))
                {
                    sample.ReadDwgFile(path,FileOpenMode.OpenForReadAndAllShare,true,null);sample.CloseInput(true);
                    using(var sr=sample.TransactionManager.StartTransaction())
                    using(var tr=db.TransactionManager.StartTransaction())
                    {
                        var main=Run((Entity)tr.GetObject(Id(db,(string)v[1].Value),OpenMode.ForRead),tr,dn);
                        var branch=(Entity)tr.GetObject(Id(db,(string)v[2].Value),OpenMode.ForRead);
                        Need(branch.ObjectId!=main.ObjectId,"Chon hai doi tuong khac nhau.");
                        Need(branch.OwnerId==main.OwnerId,"Hai doi tuong phai cung Model Space.");
                        Need(branch.LayerId==main.LayerId,"Ong chinh va nhanh phai cung layer.");
                        foreach(var entity in new Entity[]{main,branch})
                            Need(!((LayerTableRecord)tr.GetObject(entity.LayerId,OpenMode.ForRead)).IsLocked,"Layer dang khoa.");
                        var a=V(main.VertexAt(0));var b=V(main.VertexAt(1));var y=(b-a).Unit;
                        var flow=new U2Point(Number(v[5].Value),Number(v[6].Value));
                        
                        var x=new U2Point(y.Y,-y.X);U2Point branchPoint;
                        Mline branchRun=null; U2Point? branchReplacement=null; int branchNearIndex=-1;
                        if(!riser) {branchRun=Run(branch,tr,dn2);var bp0=V(branchRun.VertexAt(0));var bp1=V(branchRun.VertexAt(1));branchPoint=Math.Abs((bp0-a).Dot(x))>Math.Abs((bp1-a).Dot(x))?bp0:bp1;}
                        else if(branch is Circle circle) {Need(Math.Abs(circle.Radius*2-dn2)<0.1 && Math.Abs(circle.Center.Z)<1e-5,"Size/truc dung khong hop le.");branchPoint=V(circle.Center);}
                        else if(branch is BlockReference symbol) {Need(Math.Abs(symbol.ScaleFactors.X-1)<1e-6 && Math.Abs(symbol.ScaleFactors.Y-1)<1e-6 && Math.Abs(symbol.Position.Z)<1e-5,"Ky hieu truc dung phai scale 1, Z=0.");Need(string.Equals(Name(symbol,tr),"D"+dn2.ToString("0",CultureInfo.InvariantCulture),StringComparison.OrdinalIgnoreCase)||(dn2==168&&Name(symbol,tr)=="168"),"Chon block D<size> cua truc dung.");branchPoint=V(symbol.Position);}
                        else throw new InvalidOperationException("Mau RS: chon Circle hoac block D<size>.");
                        // Direction is relative to the branch junction, not the whole main midpoint.
                        var directionAnchor=new U2Point(Number(v[10].Value),Number(v[11].Value));
                        var junction=a+y*((directionAnchor-a).Dot(y));
                        Need(Math.Abs((flow-junction).Dot(y))>1e-5,"Click ve mot phia tren ong chinh, khong click ngay vi tri noi nhanh.");
                        if((flow-junction).Dot(y)<0) y=y*(-1);
                        x=new U2Point(y.Y,-y.X);
                        double lateral=(branchPoint-a).Dot(x);Need(Math.Abs(lateral)>dn,"Nhanh/truc dung qua gan ong chinh.");if(lateral>0)x=x*(-1);
                        var sourceSpace=(BlockTableRecord)sr.GetObject(SymbolUtilityServices.GetBlockModelSpaceId(sample),OpenMode.ForRead);
                        var refs=sourceSpace.Cast<ObjectId>().Select(id=>sr.GetObject(id,OpenMode.ForRead)).OfType<BlockReference>().ToArray();
                        var table=(BlockTable)tr.GetObject(db.BlockTableId,OpenMode.ForRead);
                        var space=(BlockTableRecord)tr.GetObject(main.OwnerId,OpenMode.ForWrite);
                        var parts=new List<Part>();
                        Part Make(U2Point location,bool first)
                        {
                            var reference=refs.Where(r=>Name(r,sr)==(first?"Y-D140x114":"ELB45-D114")).OrderBy(r=>(V(r.Position)-location).Length).First();Need((V(reference.Position)-location).Length<1,"Mau UPVCPRO khong dung phien ban.");
                            string name=first?"Y-D"+dn.ToString("0",CultureInfo.InvariantCulture)+"x"+dn2.ToString("0",CultureInfo.InvariantCulture):"ELB45-D"+dn2.ToString("0",CultureInfo.InvariantCulture);
                            Need(table.Has(name),"Thu vien thieu block "+name+". Chon/nap lai thu vien UPVC day du.");
                            var target=new BlockReference(Point3d.Origin,table[name]);
                            target.Rotation=reference.Rotation;target.ScaleFactors=reference.ScaleFactors;target.LayerId=main.LayerId;target.ColorIndex=256;
                            space.AppendEntity(target);tr.AddNewlyCreatedDBObject(target,true);States(reference,target);
                            return new Part{Source=reference,Target=target,SourcePosition=V(reference.Position),Position=new U2Point(0,0),
                                ReferenceFaces=Faces(reference,114).Select(f=>f.Shift(V(reference.Position)*(-1))).ToList(),TargetFaces=Faces(target,dn2)};
                        }
                        foreach(var location in recipe.Parts) parts.Add(Make(location,parts.Count==0));
                        var connections=new List<(Part A,Part B,U2Face AFace,U2Face BFace)>();
                        for(int i=1;i<parts.Count;i++)
                        {
                            var left=parts[i-1];var right=parts[i];
                            var link=Upvc2Geometry.Link(left.ReferenceFaces.Select(f=>f.Shift(left.SourcePosition)).ToArray(),right.ReferenceFaces.Select(f=>f.Shift(right.SourcePosition)).ToArray(),114);
                            var lf=Upvc2Geometry.Match(link.A.Shift(left.SourcePosition*(-1)),left.TargetFaces,dn2/114);
                            var rf=Upvc2Geometry.Match(link.B.Shift(right.SourcePosition*(-1)),right.TargetFaces,dn2/114);
                            var delta=link.B.Center-link.A.Center;
                            // Remove the sample's small drafting error perpendicular to the socket axis.
                            var normal=lf.Tangent.Perp;var gap=normal*(delta.Dot(normal)*dn2/114);
                            right.Position=left.Position+lf.Center+gap-rf.Center;
                            connections.Add((left,right,lf,rf));
                        }
                        var last=parts.Last();var outFace=Upvc2Geometry.Match(OutFace(last.ReferenceFaces,recipe.Outlet),last.TargetFaces,dn2/114);
                        U2Point outPoint=last.Position+outFace.Center;
                        Need(Math.Abs(outFace.Tangent.Dot(recipe.Outlet))<0.02,"Cong ra khong dung huong cua mau.");
                        var worldOutlet=x*recipe.Outlet.X+y*recipe.Outlet.Y;
                        Part near=null,end=null;U2Face face=null;U2Point riseOffset=new U2Point(0,0);
                        if(riser)
                        {
                            near=Make(recipe.RiserNear,false);end=Make(recipe.RiserEnd,false);
                            face=Upvc2Geometry.Match(OutFace(near.ReferenceFaces,recipe.Outlet*(-1)),near.TargetFaces,dn2/114);
                            riseOffset=(near.SourcePosition-end.SourcePosition)*(dn2/114)+face.Center;
                        }
                        else
                        {
                            var branchAxis=(V(branchRun.VertexAt(1))-V(branchRun.VertexAt(0))).Unit;
                            Need(Math.Abs(branchAxis.Dot(worldOutlet))>=Math.Cos(Math.PI/36)-1e-9,
                                "Nhanh khong khop mau (+/-5 do). 1E1: nhanh 90 do; 1E2: nhanh 45/135 do. Kiem tra hai click huong Y.");
                        }
                        var branchLocal=new U2Point((branchPoint-a).Dot(x),(branchPoint-a).Dot(y));
                        U2Point origin=a+y*Upvc2Recipe.OriginY(outPoint,branchLocal+riseOffset,recipe.Outlet);
                        Func<U2Point,U2Point> world=p=>Upvc2Geometry.Map(p,origin,x,y);
                        // Use true main ports, not overall bounding box or a uniform assembly scale.
                        var referenceMain=Faces(parts[0].Source,140).Select(f=>f.Shift(parts[0].SourcePosition*(-1))).ToList();
                        var targetMain=Faces(parts[0].Target,dn);
                        var mainLow=Upvc2Geometry.Match(MainFace(referenceMain,-1),targetMain,dn/140);
                        var mainHigh=Upvc2Geometry.Match(MainFace(referenceMain,1),targetMain,dn/140);
                        Need(Math.Abs(mainLow.Center.X)<dn*0.05&&Math.Abs(mainHigh.Center.X)<dn*0.05,"Cong Y khong nam tren tim ong chinh.");
                        var pipes=new List<(U2Point A,U2Point B)>();
                        foreach(var link in connections)
                        {
                            var pa=link.A.Position+link.AFace.Center;var pb=link.B.Position+link.BFace.Center;
                            if((pb-pa).Length>dn2*0.05) pipes.Add((pa,pb));
                        }
                        if(riser)
                        {
                            end.Position=new U2Point((branchPoint-origin).Dot(x),(branchPoint-origin).Dot(y));
                            near.Position=end.Position+(near.SourcePosition-end.SourcePosition)*(dn2/114);
                            var endpoint=near.Position+face.Center;
                            Need((endpoint-outPoint).Dot(recipe.Outlet)>dn2*0.1,"Truc dung qua gan: khong du cho cum co.");
                            Need(Math.Abs((endpoint-outPoint).Dot(recipe.Outlet.Perp))<dn2*0.1,"Mau truc dung khong dong truc voi cong nhanh.");
                            pipes.Add((endpoint,outPoint));
                            var riseLink=Upvc2Geometry.Link(near.ReferenceFaces.Select(f=>f.Shift(near.SourcePosition)).ToArray(),end.ReferenceFaces.Select(f=>f.Shift(end.SourcePosition)).ToArray(),114);
                            var nearEnd=Upvc2Geometry.Match(riseLink.A.Shift(near.SourcePosition*(-1)),near.TargetFaces,dn2/114);
                            var endStart=Upvc2Geometry.Match(riseLink.B.Shift(end.SourcePosition*(-1)),end.TargetFaces,dn2/114);
                            var jointA=near.Position+nearEnd.Center;var jointB=end.Position+endStart.Center;
                            Need(Math.Abs((jointB-jointA).Dot(nearEnd.Tangent))<dn2*0.045,"Hai co truc dung khong dong truc.");
                            if((jointB-jointA).Length>dn2*0.05) pipes.Add((jointA,jointB));
                            parts.Add(near);parts.Add(end);
                        }
                        else
                        {
                            var p0=V(branchRun.VertexAt(0));var p1=V(branchRun.VertexAt(1));
                            var far=branchPoint;
                            Need((far-world(outPoint)).Dot(worldOutlet)>dn2*0.1,"Ong nhanh qua ngan cho cum phu kien.");
                            if(trim)
                            {
                                var replacement=world(outPoint)-worldOutlet*Math.Min(overlap,dn2*0.2);
                                Need(Math.Abs((replacement-far).Dot(worldOutlet.Perp))<0.01,"Cong ra khong nam tren tim nhanh; giu nguyen MLINE.");
                                branchNearIndex=(far-p0).Length<1e-5?1:0;
                                branchReplacement=replacement;
                            }
                        }
                        // Validate the complete main interval before erasing any selected pipe.
                        var u=(b-a).Unit;double length=(b-a).Length;
                        double c0=(world(mainLow.Center)-a).Dot(u),c1=(world(mainHigh.Center)-a).Dot(u);
                        double lo=Math.Min(c0,c1),hi=Math.Max(c0,c1);
                        Need(lo>dn*0.1 && hi<length-dn*0.1,"Chac Y vuot dau ong chinh. Can ong chinh dai hon.");
                        foreach(var part in parts)
                        {
                            part.Target.Position=P(part.Position);
                            var matrix=new Matrix3d(new[]{x.X,y.X,0,origin.X,x.Y,y.Y,0,origin.Y,0,0,1,0,0,0,0,1});
                            part.Target.TransformBy(matrix);
                            Meta(part.Target,tr,db,"TC_SYSTEM","UPVC");Meta(part.Target,tr,db,"VAT LIEU",material);
                            Meta(part.Target,tr,db,"TC_FITTING","1");Meta(part.Target,tr,db,"TC_UPVC2",code);
                            Meta(part.Target,tr,db,"TC_DN",(part==parts[0]?dn:dn2).ToString(CultureInfo.InvariantCulture));
                            Meta(part.Target,tr,db,"TC_WIDTH",(part==parts[0]?dn:dn2).ToString(CultureInfo.InvariantCulture));
                            foreach(var key in new[]{"SYSTEM","TC_ELEVATION"})
                                using(var values=main.GetXDataForApplication(key))
                                    if(values!=null) {var text=values.AsArray().FirstOrDefault(t=>t.TypeCode==1000).Value as string;if(text!=null)Meta(part.Target,tr,db,key,text);}
                        }
                        foreach(var pipe in pipes) Pipe(space,tr,branchRun??main,world(pipe.A),world(pipe.B),dn2,db,material);
                        string remainingMain=main.Handle.ToString();
                        if(trim)
                        {
                            double lap=Math.Min(overlap,dn*0.2);
                            var left=Pipe(space,tr,main,a,a+u*(lo+lap),dn,db,material);
                            var right=Pipe(space,tr,main,a+u*(hi-lap),b,dn,db,material);
                            remainingMain=left.Handle.ToString()+","+right.Handle.ToString();
                            main.UpgradeOpen();main.Erase();if(branchRun!=null && branchReplacement.HasValue){branchRun.UpgradeOpen();branchRun.MoveVertexAt(branchNearIndex,P(branchReplacement.Value));branchRun.RecordGraphicsModified(true);}
                        }
                        tr.Commit();return returnMainHandles ? "OK|"+remainingMain : "OK";
                    }
                }
            }
            catch(System.Exception ex) {return "ERROR: UPVC2: "+ex.Message;}
            finally {if(path!=null)try{File.Delete(path);}catch(IOException){} }
        }
    }
}
