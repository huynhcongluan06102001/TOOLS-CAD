using System;
using System.Collections.Generic;
using System.Linq;

namespace ToolsCad
{
    // Only descendants of the selected main are eligible. Never search the drawing
    // for a nearby pipe: that could connect a branch to an unrelated system.
    public static class Upvc2Batch
    {
        public static string Join(string pool, string branch, Func<string, string> join)
        {
            var handles = pool.Split(',').Where(h => h.Length > 0).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            var errors = new List<string>();
            foreach (var handle in handles.ToArray())
            {
                if (string.Equals(handle, branch, StringComparison.OrdinalIgnoreCase)) continue;
                // A failed attempt must roll back its transaction before returning.
                string result = join(handle);
                if (result != null && result.StartsWith("OK|", StringComparison.Ordinal))
                {
                    handles.Remove(handle);
                    handles.AddRange(result.Substring(3).Split(',').Where(h => h.Length > 0));
                    return "OK|" + string.Join(",", handles.Distinct(StringComparer.OrdinalIgnoreCase));
                }
                if (!string.IsNullOrEmpty(result) && !errors.Contains(result)) errors.Add(result);
            }
            return errors.Count == 0 ? "ERROR: Khong con doan ong chinh hop le." : string.Join(" / ", errors.Take(3));
        }
    }
}
