using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.Runtime;
using AcApp=Autodesk.AutoCAD.ApplicationServices.Core.Application;
[assembly: CommandClass(typeof(ToolsCad.HiddenMasks))]
namespace ToolsCad {
 public static class HiddenMasks {
  const string Link="HLH_MASK035",Owner="HLH_OWNER035";
  static Database watching;
  static readonly HashSet<ObjectId> touched=new HashSet<ObjectId>();
  static bool creating;
  internal static bool Mode => watching!=null ? creating : Entry.HiddenLineEnabled;
  static void Track(object sender,ObjectEventArgs e){if(e.DBObject is Mline||e.DBObject is BlockReference)touched.Add(e.DBObject.ObjectId);}
  static void Erased(object sender,ObjectErasedEventArgs e){if(e.DBObject is Mline)touched.Add(e.DBObject.ObjectId);}
  static void Stop(){if(watching!=null){watching.ObjectAppended-=Track;watching.ObjectModified-=Track;watching.ObjectErased-=Erased;watching=null;}}
  [LispFunction("TC_HIDDEN_BEGIN_035")]
  public static string Begin(ResultBuffer args){Stop();touched.Clear();creating=Entry.HiddenLineEnabled;watching=AcApp.DocumentManager.MdiActiveDocument.Database;watching.ObjectAppended+=Track;watching.ObjectModified+=Track;watching.ObjectErased+=Erased;return "OK";}
  [LispFunction("TC_HIDDEN_ABORT_035")]
  public static string Abort(ResultBuffer args){Stop();touched.Clear();return "OK";}
  static string Get(Entity e,string key){using(var data=e.GetXDataForApplication(key))return data?.AsArray().Skip(1).Select(v=>v.Value as string).FirstOrDefault();}
  static void Set(Entity e,string key,string value,Transaction tr,Database db){var table=(RegAppTable)tr.GetObject(db.RegAppTableId,OpenMode.ForRead);if(!table.Has(key)){table.UpgradeOpen();var rec=new RegAppTableRecord{Name=key};table.Add(rec);tr.AddNewlyCreatedDBObject(rec,true);}using(var data=new ResultBuffer(new TypedValue(1001,key),new TypedValue(1000,value)))e.XData=data;}
  static Wipeout OwnedMask(Mline line,Transaction tr,Database db){var handle=Get(line,Link);if(string.IsNullOrEmpty(handle))return null;try{var id=db.GetObjectId(false,new Handle(long.Parse(handle,NumberStyles.HexNumber)),0);if(id.IsNull||id.IsErased)return null;var w=tr.GetObject(id,OpenMode.ForRead) as Wipeout;return w!=null&&Get(w,Owner)==line.Handle.ToString()?w:null;}catch(Autodesk.AutoCAD.Runtime.Exception){return null;}}
  static void Update(Mline line,Transaction tr,Database db) {
   var old=OwnedMask(line,tr,db);
   if(line.IsErased){if(old!=null){old.UpgradeOpen();old.Erase();}return;}
   if(old==null&&!creating)return;
   if(line.IsClosed||line.NumberOfVertices<2||line.Scale<=0||!line.Normal.IsParallelTo(Vector3d.ZAxis))throw new InvalidOperationException("Hidden line: can MLINE mo, WCS XY, scale duong.");
   var style=(MlineStyle)tr.GetObject(line.Style,OpenMode.ForRead);
   if(Math.Abs(style.StartAngle-Math.PI/2)>1e-6||Math.Abs(style.EndAngle-Math.PI/2)>1e-6)throw new InvalidOperationException("Hidden line: dau MLINE phai vuong goc truc ong.");
   if(style.StartRoundCap||style.EndRoundCap)throw new InvalidOperationException("Hidden line: chua ho tro MLINE style co dau cung tron.");
   var offsets=style.Elements.Cast<MlineStyleElement>().Select(e=>e.Offset*line.Scale).ToArray();
   if(offsets.Length<2)throw new InvalidOperationException("Hidden line: MLINE can hai bien ngoai.");
   double low=offsets.Min(),high=offsets.Max(),shift=line.Justification==MlineJustification.Top?high:line.Justification==MlineJustification.Bottom?low:0;
   low-=shift;high-=shift;if(line.Normal.Z<0){var nlow=-high;high=-low;low=nlow;}
   var pts=Enumerable.Range(0,line.NumberOfVertices).Select(i=>line.VertexAt(i)).ToArray();
   if(pts.Any(p=>Math.Abs(p.Z)>1e-6))throw new InvalidOperationException("Hidden line: Z phai bang 0.");
   var ring=HiddenBoundary.Build(pts.Select(p=>new HPoint(p.X,p.Y)).ToArray(),low,high);
   var boundary=new Point2dCollection(ring.Concat(new[]{ring[0]}).Select(p=>new Point2d(p.X,p.Y)).ToArray());
   var space=(BlockTableRecord)tr.GetObject(line.OwnerId,OpenMode.ForWrite);
   using var mask=new Wipeout();mask.SetDatabaseDefaults(db);mask.SetFrom(boundary,Vector3d.ZAxis);mask.LayerId=line.LayerId;mask.ColorIndex=256;
   space.AppendEntity(mask);tr.AddNewlyCreatedDBObject(mask,true);
   Set(mask,Owner,line.Handle.ToString(),tr,db);line.UpgradeOpen();Set(line,Link,mask.Handle.ToString(),tr,db);
   var order=(DrawOrderTable)tr.GetObject(space.DrawOrderTableId,OpenMode.ForWrite);order.MoveBelow(new ObjectIdCollection(new[]{mask.ObjectId}),line.ObjectId);
   if(old!=null){old.UpgradeOpen();old.Erase();}
  }
  [LispFunction("TC_HIDDEN_END_035")]
  public static string End(ResultBuffer args) {
   var db=watching;Stop();if(db==null)return "OK";
   try {
    using(var tr=db.TransactionManager.StartTransaction()) {
     foreach(var id in touched.ToArray()) {
      if(!id.IsValid)continue;
      var e=tr.GetObject(id,OpenMode.ForRead,true) as Entity;
      if(e is Mline line)Update(line,tr,db);
     }
     // Newly created fittings remain above masks from this command.
     foreach(var id in touched.Where(id=>creating&&id.IsValid&&!id.IsErased))if(tr.GetObject(id,OpenMode.ForRead) is BlockReference b) {
      var space=(BlockTableRecord)tr.GetObject(b.OwnerId,OpenMode.ForRead);
      var order=(DrawOrderTable)tr.GetObject(space.DrawOrderTableId,OpenMode.ForWrite);order.MoveToTop(new ObjectIdCollection(new[]{id}));
     }
     tr.Commit();
    }return "OK";
   }catch(System.Exception ex){return "ERROR: Hidden line: "+ex.Message;}finally{touched.Clear();}
  }
 }
}
