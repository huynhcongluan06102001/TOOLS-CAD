using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.Json;

namespace ToolsCad
{
    public sealed class Profile
    {
        public string MlineStyle { get; set; } = "TC_MC";
        public string TurnMode { get; set; } = "FREE";
        public string System { get; set; } = "PPR";
        public string Material { get; set; } = "PPR";
        public double Dn { get; set; } = 25;
        public double Dn2 { get; set; } = 20;
        public double FitDn { get; set; } = 25;
        public double Width { get; set; } = 300;
        public double Height { get; set; } = 100;
        public double FitWidth { get; set; } = 300;
        public double FitWidth2 { get; set; } = 200;
        public double FitHeight { get; set; } = 100;
        public double TextHeight { get; set; } = 100;
        public double Gap { get; set; } = 150;
        public double EndpointTolerance { get; set; } = 1;
        public double Overlap { get; set; } = 20;
        public double UnitsPerMetre { get; set; } = 1000;
        public double Fillet { get; set; } = 100;
        public double Allowance { get; set; }
        public double RowTolerance { get; set; } = 100;
        public double ArcRise { get; set; } = 300;
        public double BlockScale { get; set; } = 1;
        public string Layer { get; set; } = "TC_PPR";
        public string Service { get; set; } = "CW";
        public string Elevation { get; set; } = "0";
        public string Prefix { get; set; } = "";
        public string Suffix { get; set; } = "BOT = 3000 FFL";
        public string Fitting { get; set; } = "ELB90";
        public string Visibility { get; set; } = "";
        public bool Trim { get; set; } = true;
        public string Branch { get; set; } = "TEE";
        public string SteelJoint { get; set; } = "AUTO";
        public bool Polyline { get; set; }
        public bool Notes { get; set; } = true;
        public bool Erase { get; set; }
        public bool AutoConnect { get; set; } = true;
        public bool Flip { get; set; }

        public static Profile Create(string system)
        {
            var p = new Profile { System = system, Layer = "TC_" + system };
            switch (system)
            {
                case "DUCT": p.Material = "nep TDC"; p.Service = "SA"; p.Branch = "SHOE"; break;
                case "TRAY": p.Material = "Trunking"; p.Service = "ELE"; p.Prefix = "ELE"; break;
                case "UPVC": p.Material = "UPVC"; p.Dn = 60; p.FitDn = 60; p.Dn2 = 49; p.Service = "DRAIN"; break;
                case "STEEL": p.Material = "STK"; break;
            }
            return p;
        }

        public static string[] Materials(string system)
        {
            switch (system)
            {
                case "DUCT": return new[] { "nep TDC", "nep C", "tron", "tieu am nep TDC", "cach nhiet nep TDC", "cach nhiet nep C" };
                case "TRAY": return new[] { "Trunking", "Cable tray", "Ladder" };
                case "UPVC": return new[] { "UPVC", "UPVC_m" };
                case "STEEL": return new[] { "STK" };
                default: return new[] { "PPR", "HDPE" };
            }
        }

        public static readonly Dictionary<string, string> FittingLabels = new Dictionary<string, string>
        {
            {"ELB90", "Co 90°"}, {"ELB45", "Co 45°"}, {"TEE", "Tê / chạc ba"},
            {"SHOE", "Chạc chữ T cong / gót giày"}, {"RED", "Côn / bầu giảm"}, {"Y", "Chạc Y 45°"},
            {"CROSS", "Ngã tư"}, {"UP90", "Co lên 90°"}, {"DOWN90", "Co xuống 90°"},
            {"UP45", "Co lên 45°"}, {"DOWN45", "Co xuống 45°"}, {"DOUBLEUP", "2 lơi lên (UP90 + UP45)"},
            {"DOUBLEDOWN", "2 lơi xuống (DN90 + DN45)"}, {"RISER", "Kết trục đứng"}, {"YUP", "Y + lơi hướng lên"},
            {"VALVE_UPVC", "Van uPVC"}, {"MALE", "Nối ren ngoài"}, {"FEMALE", "Nối ren trong"},
            {"CLEANOUT", "Thông tắc"}, {"TRAP", "Thỏ"}, {"TRAP_SA", "SA (D1 × D2)"}, {"FLANGE", "Mặt bích"},
            {"VALVE", "Van"}, {"VALVE_FEMALE", "Van ren trong"}, {"UNION", "Rắc co / U"}, {"CAP", "Nắp bịt"},
            {"WATER_METER", "Đồng hồ nước"}, {"BALL", "Van bi"}, {"GATE", "Van cổng"}, {"BUTTERFLY", "Van bướm tay gạt"},
            {"YFILTER", "Y lọc"}, {"CHECKVALVE", "Van một chiều"}, {"FLAP", "Van một chiều lá lật"}, {"FLEX", "Khớp nối mềm"},
            {"UNION_MF", "Nối ren ngoài - ren trong"}, {"UNION_FF", "Nối ren trong - ren trong"},
            {"NIPPLE", "Nối ren ngoài - ren ngoài"}, {"BUSH", "Cà rá / lơ thu"}
        };

        public static string[] Fittings(string system)
        {
            switch (system)
            {
                case "DUCT": return new[] {"ELB90","ELB45","SHOE","TEE","RED","Y","UP90","DOWN90","UP45","DOWN45"};
                case "TRAY": return new[] {"ELB90","ELB45","TEE","CROSS","RED","UP90","DOWN90"};
                case "UPVC": return new[] {"DOUBLEUP","DOUBLEDOWN","RISER","YUP","VALVE_UPVC","MALE","FEMALE","CLEANOUT","TRAP","TRAP_SA","FLANGE","ELB45","ELB90","Y","TEE","RED","UP90","DOWN90","UP45","DOWN45"};
                case "STEEL": return new[] {"ELB90","ELB45","TEE","RED","UNION_MF","UNION_FF","NIPPLE","BUSH","CAP","BALL","GATE","BUTTERFLY","YFILTER","CHECKVALVE","FLAP","FLEX","UP90","DOWN90"};
                default: return new[] {"ELB90","ELB45","TEE","RED","MALE","FEMALE","UNION","VALVE","VALVE_FEMALE","CAP","WATER_METER","UP90","DOWN90"};
            }
        }
        public static string[] FittingsFor(string system, string material)
        {
            var all = Fittings(system);
            if (system != "DUCT") return all;
            var result = new List<string>();
            foreach (var kind in all)
            {
                if (material == "tron" && (kind == "SHOE" || kind == "Y")) continue;
                if ((material.Contains("cach nhiet") || material.Contains("tieu am")) && kind == "Y") continue;
                result.Add(kind);
            }
            result.AddRange(NativeCatalog.Extras(system, material));
            return result.ToArray();
        }
        public static string Label(string kind) => FittingLabels.TryGetValue(kind, out var label) ? label : NativeCatalog.Label(kind);

        public Dictionary<string, object> Settings()
        {
            return new Dictionary<string, object>
            {
                {"mline-style",MlineStyle},{"turn-mode",TurnMode},{"system",System},{"material",Material},{"dn",Dn},{"dn2",Dn2},{"width",Width},{"height",Height},
                {"fit-width",FitWidth},{"fit-width2",FitWidth2},{"fit-height",FitHeight},{"fit-kind",Fitting},{"fit-dn",FitDn},
                {"layer",Layer},{"service",Service},{"elevation",Elevation},{"text",TextHeight},
                {"note-prefix",Prefix},{"note-suffix",Suffix},{"gap",Gap},{"endpoint-tol",EndpointTolerance},
                {"overlap",Overlap},{"unit",UnitsPerMetre},{"fillet",Fillet},{"allowance",Allowance},
                {"rowtol",RowTolerance},{"drop",ArcRise},{"scale",BlockScale},
                {"note",Notes?"1":"0"},{"erase",Erase?"1":"0"},{"auto-connect",AutoConnect?"1":"0"},
                {"fit-flip",Flip?"1":"0"},{"duct-branch",System == "DUCT" && Material == "tron" ? "TEE" : Branch},{"fit-mode","Batch"},
                {"source",Polyline?"Polyline":"Pick"},{"steeljoint",SteelJoint},{"trim",Trim?"1":"0"},{"fit-state",Visibility}
            };
        }

        public string Validate()
        {
            if (Array.IndexOf(new[] {"PPR", "UPVC", "STEEL", "TRAY", "DUCT"}, System) < 0) return "Hệ thống không hợp lệ.";
            if (Array.IndexOf(Materials(System), Material) < 0) return "Vật liệu không đúng hệ đang chọn.";
            if (Array.IndexOf(new[] {"AUTO","SCREW","WELD"}, SteelJoint) < 0) return "Kiểu nối thép không hợp lệ.";
            foreach (var n in new[] {Dn, Dn2, FitDn, Width, Height, FitWidth, FitWidth2, FitHeight, TextHeight, Gap, EndpointTolerance, UnitsPerMetre, RowTolerance, ArcRise, BlockScale})
                if (double.IsNaN(n) || double.IsInfinity(n) || n <= 0) return "Kích thước, chiều cao chữ và đơn vị phải lớn hơn 0.";
            if (new[] {Overlap, Allowance, Fillet}.Any(n => double.IsNaN(n) || double.IsInfinity(n) || n < 0)) return "Khoảng ngậm, dây chờ và bán kính không được âm.";
            return null;
        }
        public static double[] Diameters(string system)
        {
            if (system == "UPVC") return new double[] {21,27,34,42,49,60,75,90,114,140,168,220,280};
            if (system == "STEEL") return new double[] {15,20,25,32,40,50,65,80,100,125,150};
            return new double[] {20,25,32,40,50,63,75,90,110,125};
        }
    }

    public sealed class Preferences
    {
        public Dictionary<string, Profile> Pages { get; set; } = new Dictionary<string, Profile>();
        public int SelectedTab { get; set; }
        public bool PlacementInitialized { get; set; }
        public int DockRevision { get; set; }
        public static string Folder => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "ToolsCadHL", "2025");
        public static string FileName => Path.Combine(Folder, "palette-settings.json");
        public static Preferences Load()
        {
            try
            {
                if (File.Exists(FileName))
                {
                    var p = JsonSerializer.Deserialize<Preferences>(File.ReadAllText(FileName));
                    if (p != null && p.Pages != null) return p;
                }
            }
            catch (Exception) { /* Preserve the unreadable file until the user explicitly saves. */ }
            return new Preferences();
        }
        public void Save()
        {
            Directory.CreateDirectory(Folder);
            string temp = FileName + ".tmp";
            File.WriteAllText(temp, JsonSerializer.Serialize(this));
            if (File.Exists(FileName)) File.Replace(temp, FileName, FileName + ".previous");
            else File.Move(temp, FileName);
        }
        public Profile For(string system)
        {
            if (!Pages.TryGetValue(system, out var p) || p == null) Pages[system] = p = Profile.Create(system);
            return p;
        }
    }
}
