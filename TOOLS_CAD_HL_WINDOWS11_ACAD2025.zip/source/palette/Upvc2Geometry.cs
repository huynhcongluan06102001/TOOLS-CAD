using System;
using System.Collections.Generic;
using System.Linq;
namespace ToolsCad
{
    // Geometry of socket faces. Independent of AutoCAD; used by the native assembler.
    public readonly struct U2Point
    {
        public readonly double X, Y;
        public U2Point(double x, double y) { X=x; Y=y; }
        public double Length => Math.Sqrt(X*X+Y*Y);
        public U2Point Unit => Length > 1e-9 ? this/Length : throw new InvalidOperationException("Huong noi bang 0.");
        public U2Point Perp => new U2Point(-Y,X);
        public double Dot(U2Point p) => X*p.X+Y*p.Y;
        public static U2Point operator +(U2Point a,U2Point b)=>new U2Point(a.X+b.X,a.Y+b.Y);
        public static U2Point operator -(U2Point a,U2Point b)=>new U2Point(a.X-b.X,a.Y-b.Y);
        public static U2Point operator *(U2Point a,double b)=>new U2Point(a.X*b,a.Y*b);
        public static U2Point operator /(U2Point a,double b)=>new U2Point(a.X/b,a.Y/b);
    }
    public sealed class U2Face
    {
        public U2Point Center, Tangent;
        public double Width;
        public U2Face(U2Point a,U2Point b) { Center=(a+b)/2; Width=(b-a).Length; Tangent=(b-a).Unit; }
        public U2Face Shift(U2Point p)=>new U2Face(Center+p-Tangent*(Width/2),Center+p+Tangent*(Width/2));
    }
    public static class Upvc2Geometry
    {
        public static readonly string[] Codes={"MP1Y+2E1","MP1Y+2E2","MP1Y+3E1","MP1Y+3E2","RS1Y+2E1","RS1Y+2E2","RS1Y+3E1","RS1Y+3E2"};
        public static int Pattern(string code) { int n=Array.IndexOf(Codes,code); if(n<0) throw new ArgumentException("Mau UPVC2 khong hop le."); return n; }
        public static (U2Face A,U2Face B) Link(IReadOnlyList<U2Face> a,IReadOnlyList<U2Face> b,double diameter)
        {
            (U2Face A,U2Face B) best=(null,null); double score=double.MaxValue;
            foreach(var p in a) foreach(var q in b)
            {
                if(Math.Abs(p.Tangent.Dot(q.Tangent))<0.9998) continue;
                var delta=q.Center-p.Center;
                // Sample 3E2 has a 0.392-degree drafting deviation: tolerate at most 5 mm at D114.
                if(Math.Abs(delta.Dot(p.Tangent))>diameter*0.045) continue;
                double cost=delta.Length+Math.Abs(p.Width-q.Width)*2;
                if(cost<score) {score=cost;best=(p,q);}
            }
            if(best.A==null) throw new InvalidOperationException("Khong ghep duoc cong noi trong mau UPVCPRO. Khong sua ong goc.");
            return best;
        }
        public static U2Face Match(U2Face reference,IReadOnlyList<U2Face> candidates,double ratio)
        {
            if(!(ratio>0) || double.IsInfinity(ratio)) throw new ArgumentException("Ti le size khong hop le.");
            U2Point expected=reference.Center*ratio;
            var found=candidates.Where(p=>Math.Abs(p.Tangent.Dot(reference.Tangent))>0.9998)
                .OrderBy(p=>(p.Center-expected).Length+Math.Abs(p.Width-reference.Width*ratio)*2).FirstOrDefault();
            if(found==null || (found.Center-expected).Length>reference.Width*ratio*1.5)
                throw new InvalidOperationException("Cong noi block khac cau truc mau. Kiem tra thu vien; khong sua ong goc.");
            return found;
        }
        public static List<U2Face> JoinCaps(IReadOnlyList<U2Face> segments)
        {
            // A cap may be drawn as two half-lines meeting at the pipe axis.
            // Merge only collinear, touching/overlapping pieces; never bridge a real gap.
            var merged=new List<U2Face>(segments);
            bool changed=true;
            while(changed)
            {
                changed=false;
                for(int i=0;i<merged.Count && !changed;i++) for(int j=i+1;j<merged.Count;j++)
                {
                    var a=merged[i];var b=merged[j];var delta=b.Center-a.Center;
                    if(Math.Abs(a.Tangent.Dot(b.Tangent))<0.999999 || Math.Abs(delta.Dot(a.Tangent.Perp))>1e-5)continue;
                    double middle=delta.Dot(a.Tangent),lo=middle-b.Width/2,hi=middle+b.Width/2;
                    if(lo>a.Width/2+1e-5 || hi<-a.Width/2-1e-5)continue;
                    merged[i]=new U2Face(a.Center+a.Tangent*Math.Min(-a.Width/2,lo),a.Center+a.Tangent*Math.Max(a.Width/2,hi));
                    merged.RemoveAt(j);changed=true;break;
                }
            }
            return merged;
        }
        public static double Width(double scale,double lo,double hi)
        {
            if(hi<=lo || Math.Abs(hi+lo)>1e-6) throw new InvalidOperationException("MLINE style phai doi xung qua tim.");
            return Math.Abs(scale)*(hi-lo);
        }
        public static U2Point Map(U2Point local,U2Point origin,U2Point x,U2Point y)=>origin+x*local.X+y*local.Y;
    }
}
