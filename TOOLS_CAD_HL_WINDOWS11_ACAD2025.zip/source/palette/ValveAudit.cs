using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Globalization;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Runtime;
using AcApp=Autodesk.AutoCAD.ApplicationServices.Core.Application;
namespace ToolsCad
{
    public static partial class Upvc2Bridge
    {
        // Runs in AutoCAD against a disposable in-memory DWG, never saves the library or drawing.
        [CommandMethod("HLVALVEAUDIT")]
        public static void ValveAudit()
        {
            var doc=AcApp.DocumentManager.MdiActiveDocument;if(doc==null)return;var ed=doc.Editor;
            var open=ed.GetFileNameForOpen(new PromptOpenFileOptions("\nChon thu vien VALVES de kiem tra tat ca trang thai:"){Filter="DWG (*.dwg)|*.dwg"});
            if(open.Status!=PromptStatus.OK)return;
            var save=ed.GetFileNameForSave(new PromptSaveFileOptions("\nLuu bao cao diem chen/cac cong van:"){Filter="CSV (*.csv)|*.csv",InitialFileName="VALVES-insertion-audit.csv"});
            if(save.Status!=PromptStatus.OK)return;
            var csv=new StringBuilder("Group,DN,Block,State,InsertionRule,PortA_X,PortA_Y,PortB_X,PortB_Y,Result\r\n");
            string Q(string value)=>"\""+(value??"").Replace("\"","\"\"")+"\"";
            string N(double value)=>value.ToString("0.######",CultureInfo.InvariantCulture);
            int checkedStates=0,issues=0;var working=HostApplicationServices.WorkingDatabase;
            try {
                using(var source=new Database(false,true)) {
                    source.ReadDwgFile(open.StringResult,FileOpenMode.OpenForReadAndAllShare,true,null);source.CloseInput(true);
                    HostApplicationServices.WorkingDatabase=source;
                    foreach(var group in ValveCatalog.Groups)foreach(var size in group.items) {
                        ObjectId id=ObjectId.Null;string[] states;
                        using(var tr=source.TransactionManager.StartTransaction()) {
                            var space=(BlockTableRecord)tr.GetObject(SymbolUtilityServices.GetBlockModelSpaceId(source),OpenMode.ForRead);
                            var sample=space.Cast<ObjectId>().Select(i=>tr.GetObject(i,OpenMode.ForRead)).OfType<BlockReference>()
                                .Where(b=>string.Equals(Name(b,tr),size.name,StringComparison.OrdinalIgnoreCase))
                                .OrderBy(b=>(V(b.Position)-new U2Point(size.x,size.y)).Length).FirstOrDefault();
                            if(sample==null) {
                                csv.AppendLine(string.Join(",",Q(group.label),size.dn,Q(size.name),Q(""),Q("DWG base point"),"","","","",Q("MISSING SAMPLE")));issues++;continue;
                            }
                            id=sample.ObjectId;var property=ValveState(sample);
                            states=property==null?new[]{"(default)"}:property.GetAllowedValues().OfType<string>().ToArray();
                        }
                        foreach(var state in states) {
                            var s=new ValveSession{Db=source,Id=id,Group=group,Size=size};string result;string ax="",ay="",bx="",by="";
                            try {
                                using(var tr=source.TransactionManager.StartTransaction()) {
                                    var block=(BlockReference)tr.GetObject(id,OpenMode.ForWrite);var property=ValveState(block);
                                    if(property!=null)property.Value=state;block.RecordGraphicsModified(true);tr.Commit();
                                }
                                using(var tr=source.TransactionManager.StartTransaction()) {
                                    var block=(BlockReference)tr.GetObject(id,OpenMode.ForWrite);
                                    ValvePorts(block,s,tr);
                                    ax=N(s.PortA.X);ay=N(s.PortA.Y);bx=N(s.PortB.X);by=N(s.PortB.Y);
                                    result=Math.Abs(s.PortA.Y)<.05&&Math.Abs(s.PortB.Y)<.05?"PORT AXIS THROUGH INSERTION":"PORT AXIS OFFSET - CHECK DWG BEFORE INLINE CUT";
                                    if(result.StartsWith("PORT AXIS OFFSET"))issues++;
                                }
                            }catch(System.Exception ex){result="FREE INSERTION ONLY / "+ex.Message;issues++;}
                            csv.AppendLine(string.Join(",",Q(group.label),size.dn,Q(size.name),Q(state),Q("DWG base point (0,0,0)"),ax,ay,bx,by,Q(result)));checkedStates++;
                        }
                    }
                }
                File.WriteAllText(save.StringResult,csv.ToString(),new UTF8Encoding(true));
                ed.WriteMessage("\nDa kiem tra "+checkedStates+" trang thai; "+issues+" muc can xem lai. Bao cao: "+save.StringResult);
            }catch(System.Exception ex){ed.WriteMessage("\nKhong hoan tat kiem tra: "+ex.Message);}
            finally{HostApplicationServices.WorkingDatabase=working;}
        }
    }
}
