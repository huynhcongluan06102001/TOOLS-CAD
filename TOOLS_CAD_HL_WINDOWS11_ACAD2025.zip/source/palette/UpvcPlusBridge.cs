using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.Runtime;
using AcApp=Autodesk.AutoCAD.ApplicationServices.Core.Application;
namespace ToolsCad
{
    public static partial class Upvc2Bridge
    {
        private static U2Point Riser(Entity e,Transaction tr,double size)
        {
            if(e is Circle c) {
                Need(Math.Abs(c.Center.Z)<1e-5&&c.Normal.IsParallelTo(Vector3d.ZAxis)&&Math.Abs(c.Radius*2-size)<.1,"Circle truc dung sai size/khong nam XY.");return V(c.Center);
            }
            var b=e as BlockReference;
            Need(b!=null,"Chon Circle hoac block D<size> truc dung.");
            Need(string.Equals(Name(b,tr),"D"+size.ToString("0",CultureInfo.InvariantCulture),StringComparison.OrdinalIgnoreCase)||(size==168&&Name(b,tr)=="168"),"Ten block truc dung phai la D<size>.");
            Need(Math.Abs(b.ScaleFactors.X-1)<1e-6&&Math.Abs(b.ScaleFactors.Y-1)<1e-6&&Math.Abs(b.ScaleFactors.Z-1)<1e-6&&Math.Abs(b.Position.Z)<1e-5&&b.Normal.IsParallelTo(Vector3d.ZAxis),"Block truc dung can scale 1, WCS XY, Z=0.");
            return V(b.Position);
        }
        private static U2Point PlusSocket(BlockReference target,U2Point expected,double size,double sampleSize,U2Point direction)
        {
            // The projected sockets at the insertion point have no straight cap in the sample.
            if(expected.Length<.01)return new U2Point(0,0);
            return PlusGeometry.Socket(Faces(target,size),expected,size,sampleSize);
        }
        private static Mline PlusPipe(BlockTableRecord space,Transaction tr,Database db,Mline template,ObjectId layer,ObjectId style,U2Point a,U2Point b,double dn,string material)
        {
            if(template!=null)return Pipe(space,tr,template,a,b,dn,db,material);
            Need((b-a).Length>.01,"MLINE noi qua ngan.");
            var definition=(MlineStyle)tr.GetObject(style,OpenMode.ForRead);
            var offsets=definition.Elements.Cast<MlineStyleElement>().Select(e=>e.Offset).ToArray();
            Need(offsets.Length>=2,"MLINE style thieu hai bien.");
            double width=Upvc2Geometry.Width(1,offsets.Min(),offsets.Max());
            var pipe=new Mline();pipe.SetDatabaseDefaults(db);
            space.AppendEntity(pipe);tr.AddNewlyCreatedDBObject(pipe,true);pipe.Style=style;pipe.Normal=Vector3d.ZAxis;
            pipe.Justification=MlineJustification.Zero;pipe.Scale=dn/width;pipe.LayerId=layer;pipe.ColorIndex=256;
            pipe.AppendSegment(P(a));pipe.AppendSegment(P(b));
            Meta(pipe,tr,db,"TC_SYSTEM","UPVC");Meta(pipe,tr,db,"VAT LIEU",material);
            Meta(pipe,tr,db,"TC_DN",dn.ToString(CultureInfo.InvariantCulture));Meta(pipe,tr,db,"TC_WIDTH",dn.ToString(CultureInfo.InvariantCulture));return pipe;
        }
        [LispFunction("TC_UPVCPLUS_JOIN_026")]
        public static string PlusJoin(ResultBuffer args)
        {
            string path=null;
            try {
                var v=args.AsArray();Need(v.Length==10,"Du lieu UPVC+ khong hop le.");
                var recipe=PlusRecipe.For((string)v[0].Value);double dn=Number(v[3].Value),dn2=Number(v[4].Value),lap=Number(v[5].Value);
                bool trim=(string)v[6].Value=="1";string mat=(string)v[7].Value,mat2=(string)v[8].Value,styleName=(string)v[9].Value;
                Need(Profile.Diameters("UPVC").Contains(dn)&&Profile.Diameters("UPVC").Contains(dn2)&&dn>=dn2,"Size UPVC khong hop le hoac nhanh lon hon truc chinh.");
                Need(!recipe.Corner||dn==dn2,"1E45/2E45 can hai ong cung size; mau khong co con thu.");
                Need(lap>=0&&!double.IsInfinity(lap)&&!double.IsNaN(lap),"Ngam UPVC khong hop le.");lap=Math.Min(lap,dn2*.2);
                var doc=AcApp.DocumentManager.MdiActiveDocument;Need(doc!=null,"Mo ban ve truoc.");var db=doc.Database;
                path=Path.Combine(Path.GetTempPath(),"ToolsCadPlus-"+Guid.NewGuid().ToString("N")+".dwg");
                using(var input=Assembly.GetExecutingAssembly().GetManifestResourceStream("ToolsCad.UPVCPLUS026.dwg"))
                using(var output=File.Create(path)){Need(input!=null,"Thieu mau upvc.dwg trong DLL.");input.CopyTo(output);}
                using(var sample=new Database(false,true)) {
                    sample.ReadDwgFile(path,FileOpenMode.OpenForReadAndAllShare,true,null);sample.CloseInput(true);
                    using(var sr=sample.TransactionManager.StartTransaction())
                    using(var tr=db.TransactionManager.StartTransaction()) {
                        var main=(Entity)tr.GetObject(Id(db,(string)v[1].Value),OpenMode.ForRead);
                        var branch=(Entity)tr.GetObject(Id(db,(string)v[2].Value),OpenMode.ForRead);
                        Need(main.ObjectId!=branch.ObjectId&&main.OwnerId==branch.OwnerId&&main.OwnerId==SymbolUtilityServices.GetBlockModelSpaceId(db),"Chon hai doi tuong khac nhau trong Model Space.");
                        foreach(var e in new[]{main,branch})Need(!((LayerTableRecord)tr.GetObject(e.LayerId,OpenMode.ForRead)).IsLocked,"Layer dang khoa.");
                        Mline first=null,second=null;U2Point center=new U2Point(),end=new U2Point();
                        if(recipe.Corner){first=Run(main,tr,dn);second=Run(branch,tr,dn2);}
                        else {center=Riser(main,tr,dn);if(recipe.TwoRisers)end=Riser(branch,tr,dn2);else second=Run(branch,tr,dn2);}
                        var styles=(DBDictionary)tr.GetObject(db.MLStyleDictionaryId,OpenMode.ForRead);
                        Need(styles.Contains(styleName),"MLINE style chua nap: "+styleName);var style=styles.GetAt(styleName);
                        var sourceSpace=(BlockTableRecord)sr.GetObject(SymbolUtilityServices.GetBlockModelSpaceId(sample),OpenMode.ForRead);
                        var refs=sourceSpace.Cast<ObjectId>().Select(id=>sr.GetObject(id,OpenMode.ForRead)).OfType<BlockReference>().ToArray();
                        var table=(BlockTable)tr.GetObject(db.BlockTableId,OpenMode.ForRead);var space=(BlockTableRecord)tr.GetObject(main.OwnerId,OpenMode.ForWrite);
                        var parts=new List<BlockReference>();var inPorts=new List<U2Point>();var outPorts=new List<U2Point>();
                        string N(double n)=>n.ToString("0",CultureInfo.InvariantCulture);
                        for(int i=0;i<recipe.Parts.Length;i++) {
                            var spec=recipe.Parts[i];var reference=refs.Where(r=>Name(r,sr)==spec.Name).OrderBy(r=>(V(r.Position)-spec.At).Length).FirstOrDefault();
                            Need(reference!=null&&(V(reference.Position)-spec.At).Length<.1,"Mau DWG khong khop cong thuc.");
                            string name=spec.Name.StartsWith("Y-",StringComparison.Ordinal)?"Y-D"+N(dn)+"x"+N(dn2):"ELB45-D"+N(dn2);
                            name=HiddenLibrary.Resolve(name);
                            Need(table.Has(name),"Thu vien thieu block "+name+". Nap lai thu vien day du size.");
                            var target=new BlockReference(Point3d.Origin,table[name]) {
                                Rotation=Math.Round((reference.Rotation-recipe.Heading)/(Math.PI/4))*(Math.PI/4),
                                ScaleFactors=reference.ScaleFactors,LayerId=i==0?main.LayerId:branch.LayerId,ColorIndex=256};
                            space.AppendEntity(target);tr.AddNewlyCreatedDBObject(target,true);HiddenLibrary.Configure(target,tr);States(reference,target);parts.Add(target);
                            var inputPoint=recipe.Local(spec.In);var outputPoint=recipe.Local(spec.Out);
                            inPorts.Add(PlusSocket(target,inputPoint,dn2,recipe.SampleSize,inputPoint.Length>.01?inputPoint:new U2Point(1,0)));
                            outPorts.Add(PlusSocket(target,outputPoint,dn2,recipe.SampleSize,outputPoint.Length>.01?outputPoint:new U2Point(1,0)));
                        }
                        U2Point origin,x,y;int nearA=-1,nearB=-1;U2Point[] positions;
                        if(recipe.Corner) {
                            positions=PlusGeometry.Chain(recipe,inPorts.ToArray(),outPorts.ToArray(),dn2/recipe.SampleSize);
                            var plan=PlusGeometry.Corner(V(first.VertexAt(0)),V(first.VertexAt(1)),V(second.VertexAt(0)),V(second.VertexAt(1)),recipe.Code=="1E45",inPorts[0],positions.Last()+outPorts.Last(),dn);
                            origin=plan.Origin;x=plan.X;y=plan.Y;nearA=plan.NearA;nearB=plan.NearB;
                        } else {
                            if(!recipe.TwoRisers) {
                                var a=V(second.VertexAt(0));var b=V(second.VertexAt(1));nearB=(a-center).Length<=(b-center).Length?0:1;
                                end=V(second.VertexAt(1-nearB));var axis=(end-V(second.VertexAt(nearB))).Unit;
                                Need(axis.Dot((end-center).Unit)>=Math.Cos(Math.PI/36)-1e-9,"MLINE nhanh phai huong ve truc dung (+/-5 do).");
                            }
                            x=(end-center).Unit;y=x.Perp;origin=center;
                            positions=PlusGeometry.Chain(recipe,inPorts.ToArray(),outPorts.ToArray(),dn2/recipe.SampleSize,recipe.TwoRisers?(double?)(end-center).Length:null);
                            if(!recipe.TwoRisers)Need((end-center).Length-(positions.Last()+outPorts.Last()).X>dn2*.1,"MLINE nhanh qua ngan de chen cum Y/co.");
                        }
                        U2Point World(U2Point p)=>origin+x*p.X+y*p.Y;
                        for(int i=0;i<parts.Count;i++) {
                            var block=parts[i];block.Position=P(positions[i]);
                            block.TransformBy(new Matrix3d(new[]{x.X,y.X,0,origin.X,x.Y,y.Y,0,origin.Y,0,0,1,0,0,0,0,1}));
                            Meta(block,tr,db,"TC_SYSTEM","UPVC");Meta(block,tr,db,"TC_FITTING","1");Meta(block,tr,db,"TC_UPVC2",recipe.Code);
                            Meta(block,tr,db,"VAT LIEU",i==0?mat:mat2);Meta(block,tr,db,"TC_DN",N(i==0?dn:dn2));Meta(block,tr,db,"TC_WIDTH",N(i==0?dn:dn2));
                        }
                        for(int i=1;i<parts.Count;i++) {
                            var a=World(positions[i-1]+outPorts[i-1]);var b=World(positions[i]+inPorts[i]);var axis=(b-a).Unit;
                            var pipe=PlusPipe(space,tr,db,second,branch.LayerId,style,a-axis*lap,b+axis*lap,dn2,mat2);Meta(pipe,tr,db,"TC_UPVC2",recipe.Code);
                        }
                        if(trim) {
                            if(first!=null) {
                                var p=World(inPorts[0]);var far=V(first.VertexAt(1-nearA));first.UpgradeOpen();first.MoveVertexAt(nearA,P(p-(far-p).Unit*lap));first.RecordGraphicsModified(true);
                            }
                            if(second!=null) {
                                var p=World(positions.Last()+outPorts.Last());var far=V(second.VertexAt(1-nearB));second.UpgradeOpen();second.MoveVertexAt(nearB,P(p-(far-p).Unit*lap));second.RecordGraphicsModified(true);
                            }
                        }
                        tr.Commit();return "OK";
                    }
                }
            } catch(System.Exception ex){return "ERROR: UPVC+: "+ex.Message;}
            finally{if(path!=null)try{File.Delete(path);}catch(IOException){}}
        }
    }
}
