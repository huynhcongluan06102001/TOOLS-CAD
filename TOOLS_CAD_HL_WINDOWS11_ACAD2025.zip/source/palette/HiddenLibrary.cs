using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.Json;
using System.Text.RegularExpressions;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Runtime;
using AcApp=Autodesk.AutoCAD.ApplicationServices.Core.Application;
[assembly: CommandClass(typeof(ToolsCad.HiddenLibrary))]
namespace ToolsCad {
 public static class HiddenLibrary {
  public const string Prefix="HLH035$";
  static Dictionary<string,string> catalog;
  static Database source;
  sealed class Calibration {public double X,Y,Z;public Dictionary<string,object> Properties=new Dictionary<string,object>();}
  static readonly Dictionary<string,Calibration> samples=new Dictionary<string,Calibration>(StringComparer.OrdinalIgnoreCase);
  static readonly object gate=new object();
  static Dictionary<string,string> Catalog {
   get {if(catalog==null)using(var s=Assembly.GetExecutingAssembly().GetManifestResourceStream("ToolsCad.HiddenCatalog.json"))
    catalog=new Dictionary<string,string>(JsonSerializer.Deserialize<Dictionary<string,string>>(s),StringComparer.OrdinalIgnoreCase);return catalog;}
  }
  public static string Resolve(string name) {
   if(!HiddenMasks.Mode||name.StartsWith(Prefix,StringComparison.Ordinal))return name;
   if(Catalog.TryGetValue(name,out var actual))return Prefix+actual;
   if(Regex.IsMatch(name,@"^(?:(?:WELD|SCREW)-)?(?:ELB\d+|TEE|RED|Y|SA|AD-MALE|AD-FEMALE|CAP|U)-D",RegexOptions.IgnoreCase)
     ||Regex.IsMatch(name,@"^(?:Tho D|thong tac D|FLANGE - uPVC D|Valve uPVC D|VALVE-D|VALVE-FEMALE-D)",RegexOptions.IgnoreCase))
    throw new InvalidOperationException("Hidden line: thu vien khong co anh xa duy nhat cho "+name+". Khong thay bang phu kien khac; tat Hidden line de dung bo cu.");
   return name;
  }
  static Database Source() {
   if(source!=null)return source;
   var path=Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location),"Libraries","HiddenLine.dwg");
   string temporary=null;
   if(!File.Exists(path)) {
    temporary=Path.Combine(Path.GetTempPath(),"ToolsCadHidden-"+Guid.NewGuid().ToString("N")+".dwg");
    using(var input=Assembly.GetExecutingAssembly().GetManifestResourceStream("ToolsCad.HiddenLine.dwg"))
    using(var output=File.Create(temporary))input.CopyTo(output);
    path=temporary;
   }
   var db=new Database(false,true);
   try {
    db.ReadDwgFile(path,FileOpenMode.OpenForReadAndAllShare,true,null);db.CloseInput(true);
    using(var tr=db.TransactionManager.StartTransaction()) {
     foreach(ObjectId id in (BlockTable)tr.GetObject(db.BlockTableId,OpenMode.ForRead)) {
      var b=(BlockTableRecord)tr.GetObject(id,OpenMode.ForRead);
      if(!b.IsLayout&&!b.IsAnonymous&&!b.IsFromExternalReference) {b.UpgradeOpen();b.Name=Prefix+b.Name;}
     }
     var model=(BlockTableRecord)tr.GetObject(SymbolUtilityServices.GetBlockModelSpaceId(db),OpenMode.ForRead);
     foreach(ObjectId id in model)if(tr.GetObject(id,OpenMode.ForRead) is BlockReference b) {
      var definition=(BlockTableRecord)tr.GetObject(b.IsDynamicBlock?b.DynamicBlockTableRecord:b.BlockTableRecord,OpenMode.ForRead);
      if(!Catalog.Values.Any(n=>string.Equals(Prefix+n,definition.Name,StringComparison.OrdinalIgnoreCase)))continue;
      if(samples.ContainsKey(definition.Name))continue;
      var c=new Calibration{X=b.ScaleFactors.X,Y=b.ScaleFactors.Y,Z=b.ScaleFactors.Z};
      if(b.IsDynamicBlock)foreach(DynamicBlockReferenceProperty prop in b.DynamicBlockReferencePropertyCollection)
       if(!prop.ReadOnly)c.Properties[prop.PropertyName]=prop.Value;
      samples.Add(definition.Name,c);
     }
     tr.Commit();
    }source=db;return db;
   }catch{samples.Clear();db.Dispose();throw;}finally{if(temporary!=null)File.Delete(temporary);}
  }

  public static void Configure(BlockReference block,Transaction tr) {
   var name=((BlockTableRecord)tr.GetObject(block.IsDynamicBlock?block.DynamicBlockTableRecord:block.BlockTableRecord,OpenMode.ForRead)).Name;
   if(!name.StartsWith(Prefix,StringComparison.Ordinal))return;
   lock(gate) {
    Source();
    if(!samples.TryGetValue(name,out var sample))throw new InvalidOperationException("Hidden line: thieu mau kich thuoc "+name);
    block.ScaleFactors=new Autodesk.AutoCAD.Geometry.Scale3d(block.ScaleFactors.X*sample.X,block.ScaleFactors.Y*sample.Y,block.ScaleFactors.Z*sample.Z);
    if(block.IsDynamicBlock)foreach(DynamicBlockReferenceProperty prop in block.DynamicBlockReferencePropertyCollection)
     if(!prop.ReadOnly&&sample.Properties.TryGetValue(prop.PropertyName,out var value))prop.Value=value;
    block.RecordGraphicsModified(true);
   }
  }
  [LispFunction("TC_HIDDEN_CONFIGURE_035")]
  public static string ConfigureLisp(ResultBuffer args) {
   try {
    var db=AcApp.DocumentManager.MdiActiveDocument.Database;
    var id=db.GetObjectId(false,new Handle(long.Parse((string)args.AsArray()[0].Value,System.Globalization.NumberStyles.HexNumber)),0);
    using(var tr=db.TransactionManager.StartTransaction()){Configure((BlockReference)tr.GetObject(id,OpenMode.ForWrite),tr);tr.Commit();}return "OK";
   }catch(System.Exception ex){return "ERROR: "+ex.Message;}
  }
  [LispFunction("TC_HIDDEN_NAME_035")]
  public static string Ensure(ResultBuffer args) {
   try {
    var name=Resolve((string)args.AsArray()[0].Value);
    if(!name.StartsWith(Prefix,StringComparison.Ordinal))return name;
    var doc=AcApp.DocumentManager.MdiActiveDocument;
    using(doc.LockDocument()) {
     using(var tr=doc.Database.TransactionManager.StartOpenCloseTransaction())
      if(((BlockTable)tr.GetObject(doc.Database.BlockTableId,OpenMode.ForRead)).Has(name))return name;
     lock(gate) {
      var db=Source();
      using(var tr=db.TransactionManager.StartOpenCloseTransaction()) {
       var bt=(BlockTable)tr.GetObject(db.BlockTableId,OpenMode.ForRead);
       if(!bt.Has(name))throw new InvalidOperationException("Hidden line thieu block "+name);
       db.WblockCloneObjects(new ObjectIdCollection(new[]{bt[name]}),doc.Database.BlockTableId,new IdMapping(),DuplicateRecordCloning.Ignore,false);
      }
     }
    }return name;
   }catch(System.Exception ex){return "ERROR: "+ex.Message;}
  }
 }
}
