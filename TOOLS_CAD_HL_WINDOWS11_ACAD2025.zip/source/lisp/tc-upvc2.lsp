;;; UPVCPRO compound joints. Native transaction validates geometry before deleting sources.
(defun tc:upvc2 (code / main branch s1 s2 dn dn2 mat flow result name)
  (if (not (member code '("MP1Y+2E1" "MP1Y+2E2" "MP1Y+3E1" "MP1Y+3E2" "RS1Y+2E1" "RS1Y+2E2" "RS1Y+3E1" "RS1Y+3E2")))
    (tc:fail "Mau UPVC2 khong hop le."))
  (setq main (tc:pick "\nUPVC2 - chon MLINE ong chinh: " '("AcDbMline")))
  (if main
    (progn
      (setq s1 (tc:segment main "UPVC") dn (tc:s s1 'dn) mat (tc:s s1 'material))
      (setq branch (tc:pick
        (if (= (substr code 1 2) "MP") "\nChon MLINE nhanh vuong goc: " "\nChon Circle / block D<size> truc dung: ")
        (if (= (substr code 1 2) "MP") '("AcDbMline") '("AcDbCircle" "AcDbBlockReference"))))
      (if branch
        (progn
          (cond
            ((= (vla-get-ObjectName branch) "AcDbMline")
              (setq s2 (tc:segment branch "UPVC") dn2 (tc:s s2 'dn))
              (if (/= mat (tc:s s2 'material)) (tc:fail "Hai ong khac vat lieu.")))
            ((= (vla-get-ObjectName branch) "AcDbCircle") (setq dn2 (* 2.0 (vla-get-Radius branch))))
            (T (setq name (strcase (tc:name branch)) dn2
                (cond ((= name "168") 168.0) ((= (substr name 1 1) "D") (atof (substr name 2))) (T 0.0)))))
          (tc:diameter "UPVC" dn2)
          (if (> dn2 dn) (tc:fail "Ong nhanh khong duoc lon hon ong chinh."))
          (setq flow (tc:point "\nChi phia huong chay tren ong chinh (so voi giua doan): "))
          (if flow
            (progn
              (tc:writable main) (tc:writable branch)
              ;; Import exact names for both sizes. Never scale the D114 sample into another diameter.
              (tc:ensure-block (tc:branch-name "UPVC" mat "Y" dn dn2))
              (tc:ensure-block (tc:elbow-name "UPVC" mat dn2 45))
              (setq result (vl-catch-all-apply '(lambda ()
                (TC_UPVC2_JOIN_017 code (vla-get-Handle main) (vla-get-Handle branch)
                  dn dn2 (car flow) (cadr flow) (tc:cfg 'overlap) (tc:cfg 'trim) mat)) nil))
              (if (vl-catch-all-error-p result) (tc:fail (vl-catch-all-error-message result)))
              (if (/= result "OK") (tc:fail result))
              (tc:touch)
              (princ (strcat "\nUPVC2 " code ": da ghep phu kien va MLINE noi, D"
                (rtos dn 2 0) " x D" (rtos dn2 2 0) ". U de hoan tac."))))))))
  (princ))
(princ)
