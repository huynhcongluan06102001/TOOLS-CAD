(defun tc:upvc2-batch-item (code pool branch dn mat anchor flow)
 (if (= (substr code 1 2) "VP") (tc:vp-item code pool branch dn mat anchor flow)
 (tc:upvc2-batch-item-old code pool branch dn mat anchor flow)))
;;; UPVCPRO compound joints. Native transaction validates geometry before deleting sources.
(defun tc:upvc2 (code)
  (cond ((tc:plus-code-p code) (tc:plus code))
        ((= (substr code 1 2) "VP") (tc:vp code))
        ((= (tc:cfg 'upvc-batch-select) "1") (tc:upvc2-batch code))
        (T (tc:upvc2-single code))))

;;; One item is validated independently; no source entity is changed before the
;;; native transaction succeeds. The main pool contains only its surviving pieces.
(defun tc:upvc2-batch-item-old (code pool branch dn mat anchor flow / s2 dn2 name)
  (cond
    ((= (vla-get-ObjectName branch) "AcDbMline")
      (setq s2 (tc:segment branch "UPVC") dn2 (tc:s s2 'dn))
      (if (/= mat (tc:s s2 'material)) (tc:fail "Hai ong khac vat lieu.")))
    ((= (vla-get-ObjectName branch) "AcDbCircle") (setq dn2 (* 2.0 (vla-get-Radius branch))))
    (T (setq name (strcase (tc:name branch)) dn2
      (cond ((= name "168") 168.0) ((= (substr name 1 1) "D") (atof (substr name 2))) (T 0.0)))))
  (tc:diameter "UPVC" dn2)
  (if (> dn2 dn) (tc:fail "Ong nhanh khong duoc lon hon ong chinh."))
  (tc:writable branch)
  (tc:ensure-block (tc:branch-name "UPVC" mat "Y" dn dn2))
  (if (/= code "MP1Y+1E2") (tc:ensure-block (tc:elbow-name "UPVC" mat dn2 45)))
  ;; Invoked inside the caller's protected lambda, never apply a native symbol.
  (TC_UPVC2_BATCH_JOIN_021 code pool (vla-get-Handle branch)
    dn dn2 (car flow) (cadr flow) (tc:cfg 'overlap) (tc:cfg 'trim) mat (car anchor) (cadr anchor)))

(defun tc:upvc2-batch-run (code pool branches dn mat anchor flow / branch result message joined skipped)
  (setq joined 0 skipped 0)
  (foreach branch branches
    (setq *tc-failure* nil)
    (setq result (vl-catch-all-apply '(lambda () (tc:upvc2-batch-item code pool branch dn mat anchor flow)) nil))
    (cond
      ((and (not (vl-catch-all-error-p result)) (= (type result) 'STR) (= (substr result 1 3) "OK|"))
        (setq pool (substr result 4) joined (1+ joined)) (tc:touch))
      (T
        (setq message (if (vl-catch-all-error-p result)
          (if *tc-failure* *tc-failure* (vl-catch-all-error-message result)) (vl-princ-to-string result)))
        (if (wcmatch (strcase message) "*CANCEL*,*BREAK*") (tc:fail message))
        (setq skipped (1+ skipped))
        (princ (strcat "\nUPVC+ bo qua #" (itoa (+ joined skipped)) ": " message))))
    (setq *tc-failure* nil))
  (setq message (strcat "UPVC+ Select: da noi " (itoa joined) "; bo qua " (itoa skipped) "."))
  (if (> skipped 0) (setq *tc-warning* (strcat message " F2 xem ly do.")))
  (princ (strcat "\n" message " U de hoan tac ca luot."))
  (list joined skipped pool))

(defun tc:upvc2-batch (code / main main-handle s1 branches anchor flow)
  (setq main (tc:pick "\nUPVC+ Select - chon MLINE ong chinh: " '("AcDbMline")))
  (if main
    (progn
      (tc:writable main)
      (setq s1 (tc:segment main "UPVC") main-handle (vla-get-Handle main))
      (prompt (if (= (substr code 1 2) "MP")
        "\nQuet chon cac MLINE nhanh, Enter de ket thuc."
        "\nQuet chon cac Circle / block D<size> truc dung, Enter de ket thuc."))
      (setq branches (tc:selection (list (cons 0 (if (= (substr code 1 2) "MP") "MLINE" "CIRCLE,INSERT")))))
      ;; A crossing selection can include the main. Exclude it before it is split.
      (setq branches (vl-remove-if '(lambda (obj) (= (vla-get-Handle obj) main-handle)) branches))
      (if branches
        (progn
          (setq anchor (tc:point "\nClick 1 - diem tham chieu tren ong chinh: "))
          (setq flow (if anchor (tc:point "\nClick 2 - phia Y huong toi (dung chung ca nhom): ")))
          (if flow
            (progn
              (if (not (tc:ensure-palette)) (tc:fail "Chua nap duoc DLL cung phien ban."))
              (tc:upvc2-batch-run code main-handle branches (tc:s s1 'dn) (tc:s s1 'material) anchor flow))))
        (princ "\nKhong co nhanh duoc chon."))))
  (princ))

(defun tc:upvc2-single (code / main branch s1 s2 dn dn2 mat anchor flow result name)
  (if (not (member code '("MP1Y+1E1" "MP1Y+1E2" "RS1Y+1E1" "RS1Y+1E2" "MP1Y+2E1" "MP1Y+2E2" "MP1Y+3E1" "MP1Y+3E2" "RS1Y+2E1" "RS1Y+2E2" "RS1Y+3E1" "RS1Y+3E2")))
    (tc:fail "Mau UPVC2 khong hop le."))
  (setq main (tc:pick "\nUPVC2 - chon MLINE ong chinh: " '("AcDbMline")))
  (if main
    (progn
      (setq s1 (tc:segment main "UPVC") dn (tc:s s1 'dn) mat (tc:s s1 'material))
      (setq branch (tc:pick
        (if (= (substr code 1 2) "MP") "\nChon MLINE nhanh (1E2: 45/135 do; mau khac: 90 do): " "\nChon Circle / block D<size> truc dung: ")
        (if (= (substr code 1 2) "MP") '("AcDbMline") '("AcDbCircle" "AcDbBlockReference"))))
      (if branch
        (progn
          (cond
            ((= (vla-get-ObjectName branch) "AcDbMline")
              (setq s2 (tc:segment branch "UPVC") dn2 (tc:s s2 'dn))
              (if (/= mat (tc:s s2 'material)) (tc:fail "Hai ong khac vat lieu.")))
            ((= (vla-get-ObjectName branch) "AcDbCircle") (setq dn2 (* 2.0 (vla-get-Radius branch))))
            (T (setq name (strcase (tc:name branch)) dn2
                (cond ((= name "168") 168.0) ((= (substr name 1 1) "D") (atof (substr name 2))) (T 0.0)))))
          (tc:diameter "UPVC" dn2)
          (if (> dn2 dn) (tc:fail "Ong nhanh khong duoc lon hon ong chinh."))
          (setq anchor (tc:point "\nClick 1 - diem tham chieu huong Y tren ong chinh: "))
          (setq flow (if anchor (tc:point "\nClick 2 - phia Y huong toi tu diem vua chon: ")))
          (if flow
            (progn
              (tc:writable main) (tc:writable branch)
              ;; Import exact names for both sizes. Never scale the D114 sample into another diameter.
              (tc:ensure-block (tc:branch-name "UPVC" mat "Y" dn dn2))
              (if (/= code "MP1Y+1E2") (tc:ensure-block (tc:elbow-name "UPVC" mat dn2 45)))
              (if (not (tc:ensure-palette)) (tc:fail "Chua nap duoc DLL cung phien ban."))
              (setq result (vl-catch-all-apply '(lambda ()
                (TC_UPVC2_JOIN_017 code (vla-get-Handle main) (vla-get-Handle branch)
                  dn dn2 (car flow) (cadr flow) (tc:cfg 'overlap) (tc:cfg 'trim) mat (car anchor) (cadr anchor))) nil))
              (if (vl-catch-all-error-p result) (tc:fail (vl-catch-all-error-message result)))
              (if (/= result "OK") (tc:fail result))
              (tc:touch)
              (princ (strcat "\nUPVC2 " code ": da ghep phu kien va MLINE noi, D"
                (rtos dn 2 0) " x D" (rtos dn2 2 0) ". U de hoan tac."))))))))
  (princ))
(princ)

;;; Keep the user's library naming; D168 and legacy 168 are both accepted.
(defun tc:upvc-riser-insert ( / dn name names path point object)
  (setq dn (tc:cfg 'dn)) (tc:diameter "UPVC" dn)
  (setq name (strcat "D" (rtos dn 2 0)))
  (if (and (= dn 168.0) (not (tc:block-present name)))
    (if (tc:block-present "168") (setq name "168")
      (progn
        (setq path (tc:library-path))
        (if (null path) (tc:fail "Chua chon thu vien DWG."))
        (setq names (tc:library-names-at path))
        (if (and (not (member name names)) (member "168" names)) (setq name "168")))))
  (tc:ensure-block name)
  (if (setq point (tc:point "\nDiem dat block truc dung: "))
    (progn
      (setq object (tc:insert name point 0.0 (getvar "CLAYER")))
      (tc:metadata object "UPVC" (tc:cfg 'material) dn dn 0.0)
      (tc:xset object "TC_RISER" "1")
      (princ (strcat "\nDa chen truc dung " name " theo size da chon, scale 1."))))
  (princ))

;;; Optional command aliases: never overwrite another LISP command.
(if (not (boundp 'C:MP1Y+1E1))
  (defun C:MP1Y+1E1 () (tc:run '(lambda () (tc:set 'system "UPVC") (tc:upvc2 "MP1Y+1E1"))) (princ)))
(if (not (boundp 'C:MP1Y+1E2))
  (defun C:MP1Y+1E2 () (tc:run '(lambda () (tc:set 'system "UPVC") (tc:upvc2 "MP1Y+1E2"))) (princ)))
(if (not (boundp 'C:RS1Y+1E1))
  (defun C:RS1Y+1E1 () (tc:run '(lambda () (tc:set 'system "UPVC") (tc:upvc2 "RS1Y+1E1"))) (princ)))
(if (not (boundp 'C:RS1Y+1E2))
  (defun C:RS1Y+1E2 () (tc:run '(lambda () (tc:set 'system "UPVC") (tc:upvc2 "RS1Y+1E2"))) (princ)))
