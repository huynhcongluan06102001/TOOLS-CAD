;;; ============================================================
;;; ONG_GIO_MEM.lsp
;;; Flexible duct: Supply 1/2/3, Return 1/2/3.
;;; AutoCAD Windows with Visual LISP / ActiveX.
;;; Draw uses the native SPLINE command with dynamic preview.
;;; No external DWG, DCL, block or DLL is required.
;;; ============================================================

(setq *tc-ogm-loaded-version* nil)

;;; ------------------------------------------------------------
;;; Public commands
;;; ------------------------------------------------------------

(defun tc:ogm-entry (system style)
  (if (= *tc-ogm-loaded-version* "1.1.0")
    (tc:ogm-run system style)
    (prompt
      "\nOGM: File chua nap day du. Hay APPLOAD lai file nguyen ven."))
  (princ))

(defun c:HLOGM_S1 () (tc:ogm-entry "S" 1))
(defun c:HLOGM_S2 () (tc:ogm-entry "S" 2))
(defun c:HLOGM_S3 () (tc:ogm-entry "S" 3))

(defun c:HLOGM_R1 () (tc:ogm-entry "R" 1))
(defun c:HLOGM_R2 () (tc:ogm-entry "R" 2))
(defun c:HLOGM_R3 () (tc:ogm-entry "R" 3))

;;; Alternative names if short command names conflict.



(defun c:HLOGMINFO ()
  (if (= *tc-ogm-loaded-version* "1.1.0")
    (prompt
      "\nOGM: NAP DAY DU. Draw co xem truoc SPLINE. Lenh: S1 S2 S3 R1 R2 R3.")
    (prompt
      "\nOGM: CHUA NAP DAY DU. Hay APPLOAD lai file nguyen ven."))
  (princ))

;;; ------------------------------------------------------------
;;; Initialization
;;; ------------------------------------------------------------

(vl-load-com)

(if (not *tc-ogm-diameter*)
  (setq *tc-ogm-diameter* 250.0))

(if (not *tc-ogm-keep-source*)
  (setq *tc-ogm-keep-source* nil))

(if (not *tc-ogm-pitch-ratio*)
  (setq *tc-ogm-pitch-ratio* 0.25))

;;; ------------------------------------------------------------
;;; Vector utilities
;;; ------------------------------------------------------------

(defun tc:ogm-fail (msg)
  (prompt (strcat "\nOGM: " msg))
  (exit))

(defun tc:ogm-add (a b)
  (mapcar '+ a b))

(defun tc:ogm-sub (a b)
  (mapcar '- a b))

(defun tc:ogm-scale (a k)
  (mapcar
    '(lambda (x) (* x k))
    a))

(defun tc:ogm-dot (a b)
  (apply '+ (mapcar '* a b)))

(defun tc:ogm-norm (a)
  (sqrt (tc:ogm-dot a a)))

(defun tc:ogm-unit (a / m)
  (setq m (tc:ogm-norm a))
  (if (> m 0.000000000001)
    (tc:ogm-scale a (/ 1.0 m))))

(defun tc:ogm-normal (a)
  (list
    (cadr a)
    (- (car a))
    0.0))

(defun tc:ogm-ceil (x / n)
  (setq n (fix x))
  (if (> x n)
    (1+ n)
    n))

;;; ------------------------------------------------------------
;;; Entity creation
;;; ------------------------------------------------------------

(defun tc:ogm-emit (data / e)
  (if (not (entmake data))
    (tc:ogm-fail
      "Khong tao duoc doi tuong CAD. Kiem tra layer va khong gian ve."))

  (setq e (entlast)
        tc-ogm-made (cons e tc-ogm-made))
  e)

(defun tc:ogm-polybulge
  (vertices layer / data parts vertex p)

  (setq data
    (list
      '(0 . "LWPOLYLINE")
      '(100 . "AcDbEntity")
      (cons 8 layer)
      '(62 . 256)
      '(6 . "ByLayer")
      '(100 . "AcDbPolyline")
      (cons 90 (length vertices))
      '(70 . 0)
      (cons 38 (caddr (caar vertices)))))

  (foreach vertex vertices
    (setq p (car vertex)
          parts
            (cons
              (cons 42 (cadr vertex))
              (cons
                (cons 10
                  (list (car p) (cadr p)))
                parts))))

  (tc:ogm-emit
    (append data (reverse parts))))

;;; ------------------------------------------------------------
;;; Evaluate the centerline in WCS
;;; Station = point / unit tangent / right normal.
;;; ------------------------------------------------------------

(defun tc:ogm-station (e s / u p v)
  (setq u
          (vlax-curve-getParamAtDist e s)
        p
          (vlax-curve-getPointAtDist e s)
        v
          (tc:ogm-unit
            (vlax-curve-getFirstDeriv e u)))

  (if (or (not p) (not v))
    (tc:ogm-fail
      "Duong dan co tiep tuyen khong xac dinh."))

  (list p v (tc:ogm-normal v)))

(defun tc:ogm-stations (e len count / i out)
  (setq i 0)

  (repeat (1+ count)
    (setq out
      (cons
        (tc:ogm-station
          e
          (* len (/ (float i) count)))
        out)
      i (1+ i)))

  (reverse out))

(defun tc:ogm-offset (st d)
  (tc:ogm-add
    (car st)
    (tc:ogm-scale (caddr st) d)))

;;; ------------------------------------------------------------
;;; Validate the centerline before generating geometry.
;;; Open, planar, sufficiently long and sufficiently smooth.
;;; ------------------------------------------------------------

(defun tc:ogm-validate
  (e dia / ed kind len count sts st prev z ds dt msg)

  (setq ed (entget e)
        kind (cdr (assoc 0 ed)))

  (cond
    ((not
       (member kind
         '("LINE" "ARC" "LWPOLYLINE"
           "POLYLINE" "SPLINE")))
     "Chon LINE, ARC, polyline hoac SPLINE 2D mo.")

    ((and
       (= kind "POLYLINE")
       (/= 0
         (logand 80 (cdr (assoc 70 ed)))))
     "Khong ho tro mesh/polyface.")

    ((vlax-curve-isClosed e)
     "Duong dan phai la duong MO.")

    (t
     (setq len
       (vlax-curve-getDistAtParam
         e
         (vlax-curve-getEndParam e)))

     (cond
       ((or
          (not len)
          (< len (* dia 0.5)))
        "Duong dan ngan hon nua duong kinh.")

       ((>
          (/ len (* dia *tc-ogm-pitch-ratio*))
          3000.0)
        "Qua 3000 gan. Tang duong kinh hoac chia nho duong dan.")

       (t
        (setq count
                (max
                  16
                  (tc:ogm-ceil
                    (/ len (/ dia 32.0))))
              sts
                (tc:ogm-stations e len count)
              z
                (caddr (caar sts)))

        (foreach st sts
          (cond
            ((or
               (>
                 (abs (- (caddr (car st)) z))
                 (* dia 0.000001))
               (>
                 (abs (caddr (cadr st)))
                 0.000001))
             (setq msg
               "Chi ho tro duong dan phang song song WCS XY."))

            (prev
             (setq ds
               (tc:ogm-norm
                 (tc:ogm-sub
                   (car st)
                   (car prev)))
               dt
               (tc:ogm-norm
                 (tc:ogm-sub
                   (cadr st)
                   (cadr prev))))

             (if
               (and
                 (> dt 0.000000001)
                 (< (/ ds dt) (* dia 0.51)))
               (setq msg
                 "Goc gap/ban kinh uon qua nho. Lam tron hoac giam size."))))

          (setq prev st))

        msg)))))

;;; ------------------------------------------------------------
;;; Duct geometry matching the supplied DWG bulge patterns.
;;;
;;; S = outward side scallops.
;;; R = inward side scallops.
;;;
;;; Type 1: flat start / round end.
;;; Type 2: flat start / flat end.
;;; Type 3: round start / round end.
;;;
;;; Repeated vertices/arcs follow the reference topology.
;;; ------------------------------------------------------------

(defun tc:ogm-vertex (p bulge)
  (setq tc-ogm-vertices
    (cons
      (list p bulge)
      tc-ogm-vertices)))

(defun tc:ogm-pattern
  (stations dia system style step / tc-ogm-vertices st nxt a0 b0 am bm a1 b1 q c r temp remaining side cross)

  (setq q
          0.414213562373095
        c
          0.176326980708465
        r
          (/ dia 2.0)
        side
          (if (= system "R") (- q) q)
        st
          (car stations)
        a0
          (tc:ogm-offset st r)
        b0
          (tc:ogm-offset st (- r))
        temp
          (tc:ogm-scale (cadr st) (- step))
        am
          (tc:ogm-add a0 temp)
        bm
          (tc:ogm-add b0 temp))

  ;; Starting collar.

  (if (= style 3)
    (progn
      (tc:ogm-vertex a0 (- side))
      (tc:ogm-vertex am -1.0)
      (tc:ogm-vertex bm
        (if (= system "R") c (- c)))
      (tc:ogm-vertex am
        (if (= system "R") c (- q)))
      (tc:ogm-vertex bm (- side))
      (tc:ogm-vertex b0 (- c)))

    (progn
      (tc:ogm-vertex a0 0.0)
      (tc:ogm-vertex b0 0.0)
      (tc:ogm-vertex bm 0.0)
      (tc:ogm-vertex am 0.0)))

  ;; Repeated duct cells.

  (setq remaining (cdr stations))

  (while remaining
    (setq nxt
            (car remaining)
          a1
            (tc:ogm-offset nxt r)
          b1
            (tc:ogm-offset nxt (- r))
          temp
            (and
              (= style 2)
              (not (cdr remaining)))
          cross
            (if temp 0.0 c))

    (tc:ogm-vertex a0
      (if temp 0.0 side))
    (tc:ogm-vertex a1 cross)
    (tc:ogm-vertex b1
      (if temp 0.0 side))
    (tc:ogm-vertex b0 (- cross))
    (tc:ogm-vertex a0
      (if temp 0.0 side))

    (setq a0 a1
          b0 b1
          remaining (cdr remaining)))

  ;; Finishing collar.

  (if (= style 2)
    (tc:ogm-vertex a0 0.0)
    (progn
      (tc:ogm-vertex a0 q)
      (tc:ogm-vertex b0 -1.0)
      (tc:ogm-vertex a0 1.0)
      (tc:ogm-vertex b0 1.0)))

  (reverse tc-ogm-vertices))

(defun tc:ogm-build
  (e dia system style / msg len count stations vertices)

  (setq msg (tc:ogm-validate e dia))

  (if msg
    (tc:ogm-fail msg))

  (setq len
          (vlax-curve-getDistAtParam
            e
            (vlax-curve-getEndParam e))
        count
          (max
            2
            (fix
              (/ len
                (* dia *tc-ogm-pitch-ratio*))))
        stations
          (cdr
            (tc:ogm-stations e len count))
        vertices
          (tc:ogm-pattern
            stations
            dia
            system
            style
            (/ len count)))

  (tc:ogm-polybulge
    vertices
    (getvar "CLAYER"))

  (length vertices))

;;; ------------------------------------------------------------
;;; Cleanup and settings restoration
;;; ------------------------------------------------------------

(defun tc:ogm-erase-list (items / e)
  (foreach e items
    (if (entget e)
      (entdel e))))

(defun tc:ogm-restore (vars / item)
  (foreach item vars
    (setvar
      (car item)
      (cdr item))))

;;; ------------------------------------------------------------
;;; Draw with the native AutoCAD SPLINE dynamic preview.
;;;
;;; The caller's error handler is passed before localizing
;;; *error*, so ESC also restores the caller's settings.
;;; ------------------------------------------------------------

(defun tc:ogm-draw-path ()
  (tc:ogm-draw-native *error*))

(defun tc:ogm-draw-native
  (olderr / *error* olddrag before p e)

  (setq olddrag
          (getvar "DRAGMODE")
        before
          (entlast))

  (defun *error* (msg)
    ;; Cancel any remaining native drawing command.
    (if (> (getvar "CMDACTIVE") 0)
      (command-s))

    ;; Remove only a newly created temporary spline.
    (setq e (entlast))

    (if
      (and
        e
        (not (eq e before))
        (=
          "SPLINE"
          (cdr (assoc 0 (entget e)))))
      (progn
        (entdel e)
        (setq tc-ogm-temp nil)))

    (setvar "DRAGMODE" olddrag)

    ;; Let the main command clean up and restore its settings.
    (if olderr
      (apply olderr (list msg))
      (princ)))

  (setq p
    (getpoint
      "\nFirst point <Enter to exit>: "))

  (if p
    (progn
      ;; Enable native dynamic dragging.
      ;; Keep OSMODE unchanged for normal object snapping.
      (setvar "DRAGMODE" 2)
      (setvar "SPLMETHOD" 0)
      (setvar "SPLKNOTS" 0)

      (prompt
        "\nVe SPLINE: chon cac diem. Enter ket thuc; Enter chap nhan tiep tuyen mac dinh.")

      (command
        "_.SPLINE"
        "_non"
        p)

      ;; PAUSE hands control to AutoCAD's native spline jig.
      ;; The preview follows the cursor while points are picked.
      (while
        (= 1
          (logand 1
            (getvar "CMDACTIVE")))
        (command pause))

      (setq e (entlast))

      (if
        (and
          e
          (not (eq e before))
          (=
            "SPLINE"
            (cdr (assoc 0 (entget e)))))
        (setq tc-ogm-temp e)
        (setq e nil))))

  (setvar "DRAGMODE" olddrag)
  e)

;;; ------------------------------------------------------------
;;; Main workflow: diameter -> Draw/Select -> duct.
;;; ------------------------------------------------------------

(defun tc:ogm-run
  (system style / *error* vars doc mark tc-ogm-made tc-ogm-temp dia mode pick e msg result keep note-before)

  (setq *tc-last-ok* nil *tc-last-message* "OGM: da huy hoac chua tao ong.")
  (setq vars
    (mapcar
      '(lambda (v)
        (cons v (getvar v)))
      '("CMDECHO"
        "OSMODE"
        "SPLMETHOD"
        "SPLKNOTS"))
    doc
      (vla-get-ActiveDocument
        (vlax-get-acad-object))
    keep
      *tc-ogm-keep-source*)

  (defun *error* (msg)
    (setq *tc-last-ok* nil *tc-last-message* (if msg msg "OGM: da huy."))
    (tc:ogm-erase-list tc-ogm-made)

    (if
      (and
        tc-ogm-temp
        (entget tc-ogm-temp))
      (entdel tc-ogm-temp))

    (tc:ogm-restore vars)

    (if mark
      (vla-EndUndoMark doc))

    (if
      (and
        msg
        (not
          (wcmatch
            (strcase msg)
            "*CANCEL*,*QUIT*,*BREAK*,*HUY*")))
      (prompt
        (strcat "\nOGM: " msg)))

    (princ))

  (setvar "CMDECHO" 0)

  ;; Positive, nonzero diameter.
  (initget 6)

  (setq dia
    (getreal
      (strcat
        "\nPlease enter the diameter <"
        (rtos *tc-ogm-diameter* 2 2)
        ">: ")))

  (if (not dia)
    (setq dia *tc-ogm-diameter*))

  (setq *tc-ogm-diameter* dia)

  (if (not *tc-ogm-menu*) (initget "Draw Select"))

  (setq mode
    (if *tc-ogm-menu* (if (= (tc:cfg 'source) "Polyline") "Select" "Draw")
      (getkword "\nDraw part or Select part [Draw/Select] <Select>: ")))

  (vla-StartUndoMark doc)
  (setq mark t)

  (if (= mode "Draw")
    (setq e (tc:ogm-draw-path))

    (progn
      (while
        (and
          (not e)
          (setq pick
            (entsel
              "\nSelect object <Enter to exit>: ")))

        (setq msg
          (tc:ogm-validate
            (car pick)
            dia))

        (if msg
          (prompt
            (strcat "\n" msg))
          (setq e (car pick))))))

  (if e
    (progn
      (setq result
        (tc:ogm-build
          e
          dia
          system
          style))

      (if (and *tc-ogm-menu* (= (tc:cfg 'note) "1"))
        (progn
          (setq note-before (entlast))
          (tc:note (list (vlax-curve-getStartPoint e) (vlax-curve-getEndPoint e))
            "FLEX" "ONG GIO MEM" dia dia dia (getvar "CLAYER"))
          (if (not (eq note-before (entlast))) (setq tc-ogm-made (cons (entlast) tc-ogm-made)))))
      ;; Delete the centerline only after successful creation.
      ;; Draw's temporary spline is always removed.
      (if
        (or
          tc-ogm-temp
          (not keep))
        (if (not (entdel e))
          (tc:ogm-fail
            "Khong xoa duoc duong dan. Kiem tra layer bi khoa.")))

      (setq tc-ogm-temp nil
            tc-ogm-made nil
            *tc-last-ok* T *tc-last-message* "OGM: da tao ong gio mem.")

      (prompt
        (strcat
          "\n"
          system
          (itoa style)
          " - D="
          (rtos dia 2 2)
          ": da tao ong gio mem. UNDO de hoan tac."))))

  (tc:ogm-restore vars)

  (vla-EndUndoMark doc)
  (setq mark nil)

  (princ))

;;; ------------------------------------------------------------
;;; Menu
;;; ------------------------------------------------------------

(defun c:HLOGM (/ k)
  (initget "S1 S2 S3 R1 R2 R3")

  (setq k
    (getkword
      "\nOng gio mem [S1/S2/S3/R1/R2/R3] <S1>: "))

  (cond
    ((= k "S2") (c:HLOGM_S2))
    ((= k "S3") (c:HLOGM_S3))
    ((= k "R1") (c:HLOGM_R1))
    ((= k "R2") (c:HLOGM_R2))
    ((= k "R3") (c:HLOGM_R3))
    (t (c:HLOGM_S1))))

;;; ------------------------------------------------------------
;;; Successful-load marker. Keep this at the end of the file.
;;; ------------------------------------------------------------

(setq *tc-ogm-loaded-version* "1.1.0")

(prompt
  "\nOGM - NAP DAY DU. Draw co xem truoc SPLINE.")

(prompt
  "\nLenh: S1 S2 S3 R1 R2 R3 / HLOGM. Kiem tra: HLOGMINFO.")

(princ)

(if (not (boundp 'c:S1)) (defun c:S1 () (c:HLOGM_S1)))

(if (not (boundp 'c:S2)) (defun c:S2 () (c:HLOGM_S2)))

(if (not (boundp 'c:S3)) (defun c:S3 () (c:HLOGM_S3)))

(if (not (boundp 'c:R1)) (defun c:R1 () (c:HLOGM_R1)))

(if (not (boundp 'c:R2)) (defun c:R2 () (c:HLOGM_R2)))

(if (not (boundp 'c:R3)) (defun c:R3 () (c:HLOGM_R3)))

(defun tc:ogm-menu (request / command *tc-ogm-menu*)
  (setq command (cadr (assoc "command" request)) *tc-ogm-menu* T)
  (if (member command '("S1" "S2" "R1" "R2"))
    (progn
      (tc:run '(lambda () (tc:apply-palette-settings (cadr (assoc "settings" request)))))
      ;; Native SPLINE/PAUSE must run outside vl-catch-all-apply and the shared undo group.
      (if *tc-last-ok* (tc:ogm-entry (substr command 1 1) (atoi (substr command 2)))))
    (setq *tc-last-ok* nil *tc-last-message* "OGM: lenh khong hop le.")))
