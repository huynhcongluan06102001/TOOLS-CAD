;;; The native preview is disposable display geometry; final entities still use
;;; tc:build-sized-route and its existing fitting/size validation.
(defun tc:preview-native (system previous base / asset diameter)
  (if (not (tc:ensure-palette)) (tc:fail "Preview: chua nap DLL cung phien ban."))
  (setq diameter (tc:diameter system (tc:cfg 'dn)))
  (if (tc:pipe-p system)
    (progn
      (setq asset (tc:cfg 'mline-style))
      (if (= asset "TC_MC") (tc:mline-style))
      (tc:mline-span asset))
    (progn (setq asset (tc:straight-name system (tc:material system))) (tc:ensure-block asset)))
  (TC_ROUTE_POINT_023 (if (tc:pipe-p system) "PIPE" "BLOCK") asset
    diameter (tc:cfg 'width) (car base) (cadr base)
    (if previous (car previous) 0.0) (if previous (cadr previous) 0.0)
    (if previous "1" "0") (tc:cfg 'layer) (tc:cfg 'turn-mode)))

(defun tc:preview-point (system previous base / result message)
  (if (and (= (tc:cfg 'route-preview) "1") (not *tc-route-preview-off*))
    (progn
      (setq result (vl-catch-all-apply '(lambda () (tc:preview-native system previous base)) nil))
      (cond
        ((and (not (vl-catch-all-error-p result)) (= result "CANCEL")) (tc:fail "Function cancelled"))
        ((and (not (vl-catch-all-error-p result)) (= result "END")) nil)
        ((and (not (vl-catch-all-error-p result)) (member result '("Size" "Back" "Center"))) result)
        ((and (not (vl-catch-all-error-p result)) (= (type result) 'STR) (= (substr result 1 1) "("))
          ;; Native API returns WCS; the existing getpoint path expects UCS.
          (trans (read result) 0 1))
        (T
          (setq message (if (vl-catch-all-error-p result)
            (if *tc-failure* *tc-failure* (vl-catch-all-error-message result)) (vl-princ-to-string result)))
          (if (wcmatch (strcase message) "*CANCEL*,*BREAK*") (tc:fail message))
          (setq *tc-failure* nil *tc-route-preview-off* T)
          (princ (strcat "\nPreview tam tat cho luot nay: " message))
          (initget "Size Back Center")
          (getpoint (trans base 0 1) "\nDiem tiep / [Size/Back/Center] (Enter ket thuc): "))))
    (progn
      (initget "Size Back Center")
      (getpoint (trans base 0 1) "\nDiem tiep / [Size/Back/Center] (Enter ket thuc): "))))
(princ)
