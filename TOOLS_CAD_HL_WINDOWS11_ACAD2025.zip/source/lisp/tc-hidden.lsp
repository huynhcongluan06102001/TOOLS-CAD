;;; Hidden line integration: all mutations stay within tc:run UNDO group.
(defun tc:hidden-begin ( / result)
  (setq *tc-hidden-active* nil)
  (if (tc:ensure-palette)
    (progn
      (setq result (vl-catch-all-apply '(lambda () (TC_HIDDEN_BEGIN_035)) nil))
      (if (vl-catch-all-error-p result) (tc:fail (vl-catch-all-error-message result)))
      (if (/= result "OK") (tc:fail result))
      (setq *tc-hidden-active* T))))
(defun tc:hidden-end ( / result)
  (if *tc-hidden-active* (progn
  (setq result (vl-catch-all-apply '(lambda () (TC_HIDDEN_END_035)) nil))
  (if (vl-catch-all-error-p result) (tc:fail (vl-catch-all-error-message result)))
  (if (/= result "OK") (tc:fail result)))))
(defun tc:hidden-abort ()
  (vl-catch-all-apply '(lambda () (TC_HIDDEN_ABORT_035)) nil))
(princ)
