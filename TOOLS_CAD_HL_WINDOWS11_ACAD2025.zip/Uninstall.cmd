@echo off
powershell.exe -NoProfile -File "%~dp0Uninstall.ps1"
if errorlevel 1 echo Uninstall stopped. No modified user file will be overwritten.
pause
