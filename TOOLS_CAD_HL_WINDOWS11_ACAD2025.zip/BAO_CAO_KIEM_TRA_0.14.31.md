# Kiểm tra 0.14.31

Nguyên nhân mã 0.14.30: dùng trung điểm cổng để đặt block; khi không nhận ra
cổng thì dùng tâm bounding box. Các hình chiếu có tay van/bộ truyền động
lệch tâm làm điểm bám chuột bị dịch khỏi điểm chèn do tác giả DWG đặt.

Sửa: offset đặt/xoay là local (0,0), không có setter và không có nhánh dự
phòng hình học. Đo cổng chỉ phục vụ căn trục/cắt ống. Visibility giữ tọa độ
điểm chèn trước khi chuyển trạng thái. Không sửa thư viện gốc.

- Danh mục 19 nhóm / 176 mẫu giữ nguyên; scale gốc được giữ.
- Kiểm tra tĩnh cấm bbox/cổng thay thế điểm neo; mọi nhóm dùng cùng quy tắc.
- 17.585 kiểm tra domain hiện có qua; build không lỗi/cảnh báo.
- Bổ sung HLVALVEAUDIT đọc tất cả AllowedValues của mỗi mẫu trong AutoCAD,
  commit Visibility rồi đo cổng trong transaction mới; xuất CSV, không Save DWG.
- ZIP và DLL nhúng được kiểm tra checksum và CRC.

Giới hạn: kiểm tra tĩnh không chứng minh vị trí hình học của từng Visibility.
Không có AutoCAD Windows nên chưa thực thi audit, Space/DrawJig hoặc đánh giá
native dynamic block. Không khẳng định đã kiểm tra trực quan toàn bộ trạng thái.
