# Kiểm tra 0.14.29

- Thay vòng grread/osnap/COM bằng EntityJig + AcquirePoint trong AutoCAD.
- Một transaction cho mỗi giai đoạn kéo; Sampler trả NoChange khi điểm không đổi.
- Không gọi tìm giao điểm, vla-Update hoặc UpdateScreen trong vòng rê chuột.
- Bỏ running intersection tạm thời và khôi phục OSMODE trong finally, kể cả hủy.
- Cache DWG thư viện theo đường dẫn/LastWriteTimeUtc/Length.
- Bước xoay 45 độ đủ 8 hướng theo UCS, bổ sung 153 kiểm tra góc.
- MLINE nhiều đoạn/Top/Bottom: chiếu về tim đoạn và chỉ tách tại đoạn chọn.
- .NET build không lỗi/cảnh báo; 17.295 domain assertions; 7 kiểm tra quyền sở hữu
  preview/cleanup qua wrapper LISP; 27 kiểm tra danh mục STEEL giữ nguyên.
- ZIP kiểm tra CRC, SHA256 và DLL nhúng.

Chưa kiểm thử native EntityJig, Space/OSNAP, dynamic block evaluation hoặc
RemoveLastSegment trên AutoCAD Windows. Chưa có số đo hiệu năng host thực.
