@echo off
powershell.exe -NoProfile -File "%~dp0Install.ps1"
if errorlevel 1 echo Installation failed. Read the message above and HUONG_DAN_CAI_DAT.md.
pause
