"""Refresh the existing single-file/ZIP delivery from recovered source and built DLL."""
import base64, hashlib, json, re, sys, zipfile
from pathlib import Path
root = Path(__file__).resolve().parents[1]
dll = Path(sys.argv[1]).read_bytes()
p = root / 'ToolsCadHL.lsp'
s = p.read_text()
for module in (root / 'source/lisp').glob('*.lsp'):
    marker = ';;; ===== ' + module.stem + ' =====\n'
    if marker not in s:
        s = s.replace(';;; ===== tc-commands =====', marker + '\n;;; ===== tc-commands =====', 1)
    pattern = r'(;;; ===== ' + re.escape(module.stem) + r' =====\n).*?(?=\n;;; =====|\n\(princ "\\nTools Cad HL 0\.|\Z)'
    s, count = re.subn(pattern, lambda m: m[1] + module.read_text().rstrip() + '\n', s, flags=re.S)
    assert count == 1, module
encoded = base64.b64encode(dll).decode()
block = '(setq *tc-palette-bytes* (list\n' + ''.join('  "'+encoded[i:i+2000]+'"\n' for i in range(0,len(encoded),2000)) + '))'
s = re.sub(r'\(setq \*tc-palette-bytes\* \(list.*?\n\)\)', lambda m: block, s, count=1, flags=re.S)
s = re.sub(r'\(setq \*tc-palette-hash\* "[^"]+"\)', '(setq *tc-palette-hash* "'+hashlib.sha256(dll).hexdigest()[:20]+'")', s)
version = re.search(r'\(setq \*tc-version\* "([^"]+)"', (root/'source/lisp/tc-core.lsp').read_text()).group(1)
s = re.sub(r'(Tools Cad HL )0\.\d+(?:\.\d+)?', lambda m: m[1] + version, s)
s = re.sub(r'(;;; Version )0\.\d+(?:\.\d+)?', lambda m: m[1] + version, s)
# Refuse an occupied internal namespace before changing any project globals.
start = ";;; BEGIN HL NAMESPACE GUARD"
end = ";;; END HL NAMESPACE GUARD"
s = re.sub(re.escape(start)+r".*?"+re.escape(end)+r"\n", "", s, flags=re.S)
guard = """;;; BEGIN HL NAMESPACE GUARD
((lambda ( / hl-symbol hl-conflict)
  (if (/= (substr (getvar "ACADVER") 1 4) "25.0")
    (progn (princ "\\nBan nay chi danh cho AutoCAD 2025 Windows.") (exit)))
  (if (not (and (boundp '*toolscadhl-owner-013*) *toolscadhl-owner-013*))
    (progn
      (foreach hl-symbol (atoms-family 1)
        (if (and (wcmatch (strcase hl-symbol) "TC:*,C:TC*,C:HL*,`*TC-*")
                 (boundp (read hl-symbol)))
          (setq hl-conflict T)))
      (if hl-conflict
        (progn (princ "\\nTools Cad HL: namespace TC/HL da duoc su dung. Mo phien AutoCAD moi, khong nap ban Library/HL cu cung luc.") (exit)))))
  (setq *toolscadhl-owner-013* T)))
;;; END HL NAMESPACE GUARD
"""
s = guard + s


p.write_text(s)
archive = root/'TOOLS_CAD_HL_CAI_DAT.zip'
with zipfile.ZipFile(archive) as z:
    entries = {}
entries['ToolsCadHL.lsp'] = p.read_bytes()
entries['ToolsCadPalette.dll'] = dll
entries['HLFLOAT_CHECK.md'] = (root/'HLFLOAT_CHECK.md').read_bytes()
for p in (root/'source').rglob('*'):
    if p.is_file() and 'obj' not in p.parts and 'bin' not in p.parts:
        entries[p.relative_to(root).as_posix()] = p.read_bytes()
entries['SHA256SUMS.json'] = json.dumps({n:hashlib.sha256(b).hexdigest() for n,b in entries.items()},indent=2).encode()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for n,b in entries.items(): z.writestr(n,b)
print('Updated LSP and ZIP; DLL SHA256:', hashlib.sha256(dll).hexdigest())
