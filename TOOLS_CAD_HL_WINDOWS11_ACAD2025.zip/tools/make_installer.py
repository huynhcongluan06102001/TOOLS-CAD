"""Build one Windows distribution without altering the existing checkout layout."""
import hashlib,json,re,zipfile
from pathlib import Path
r=Path(__file__).resolve().parents[1]
with zipfile.ZipFile(r/'TOOLS_CAD_HL_CAI_DAT.zip') as z:
    dll=z.read('ToolsCadPalette.dll')
entries={}
for p in (r/'installer').iterdir():
    if p.is_file() and p.name!='PackageContents.xml':entries[p.name]=p.read_bytes()
bundle={'PackageContents.xml':(r/'installer/PackageContents.xml').read_bytes(),
        'Contents/ToolsCadHL.lsp':(r/'ToolsCadHL.lsp').read_bytes(),
        'Contents/TOOLS-CAD.dcl':(r/'source/TOOLS-CAD.dcl').read_bytes(),
        'Contents/ToolsCadPalette.dll':dll}
bundle['manifest.json']=json.dumps({n:hashlib.sha256(b).hexdigest() for n,b in bundle.items()},indent=2).encode()
entries.update({'ToolsCadHL.bundle/'+n:b for n,b in bundle.items()})
for folder in ['source','tools','tests','installer']:
 for p in (r/folder).rglob('*'):
    if p.is_file() and not set(p.parts)&{'bin','obj','__pycache__'}:entries[p.relative_to(r).as_posix()]=p.read_bytes()
for n in ['HLFLOAT_CHECK.md','BAO_CAO_KIEM_TRA.md','ToolsCadHL.lsp']:entries[n]=(r/n).read_bytes()
s=(r/'source/lisp/tc-commands.lsp').read_text()
commands=re.findall(r'\(list \d+ "([^"]+)" "([^"]+)" "([^"]+)"\)',s)
text='# Danh sách lệnh\n\nHLFLOAT: thả nổi; HLDOCK: ghim phải; HLTOOLS: mở bảng; HLLOAD: chọn DLL; HLSTATUS: chẩn đoán DLL; TCDCL: giao diện dự phòng.\n\n| Lệnh | Chức năng | Ghi chú |\n|---|---|---|\n'
text+=''.join('| '+' | '.join(row)+' |\n' for row in commands)
text+='\nỐng gió mềm: S1/S2/S3/R1/R2/R3 (nếu tên chưa được LISP khác dùng); HLOGM_S1/HLOGM_S2/HLOGM_S3/HLOGM_R1/HLOGM_R2/HLOGM_R3 luôn gọi bản tích hợp. HLOGM: menu; HLOGMINFO: thông tin. Bốn nút S1/S2/R1/R2 chỉ có trong tab DUCT.\n'
text+='\nUPVC+: 12 nút MP1Y+1E1, MP1Y+1E2, MP1Y+2E1, MP1Y+2E2, MP1Y+3E1, MP1Y+3E2, RS1Y+1E1, RS1Y+1E2, RS1Y+2E1, RS1Y+2E2, RS1Y+3E1, RS1Y+3E2. Bốn lệnh 1Y+1E1/1Y+1E2 cũng gọi trực tiếp được nếu tên chưa bị LISP khác sử dụng. Phần mới cần kiểm thử trong AutoCAD.\n'
text+='\nSelect (UPVC+): bật để chọn một ống chính, quét nhiều nhánh MP hoặc trục đứng RS, Enter và hai click chọn hướng Y dùng chung; bỏ tick để nối từng nhánh. F2 xem các nhánh bỏ qua; U hoàn tác cả lượt.\n'
entries['DANH_SACH_LENH.md']=text.encode()
entries['SHA256SUMS.json']=json.dumps({n:hashlib.sha256(b).hexdigest() for n,b in entries.items()},indent=2).encode()
out=r/'TOOLS_CAD_HL_WINDOWS11_ACAD2025.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for n,b in entries.items():z.writestr(n,b)
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 for n,h in json.loads(z.read('SHA256SUMS.json')).items():assert hashlib.sha256(z.read(n)).hexdigest()==h,n
print(out, out.stat().st_size,'bytes;',len(commands),'catalog commands; all ZIP checksums passed')
