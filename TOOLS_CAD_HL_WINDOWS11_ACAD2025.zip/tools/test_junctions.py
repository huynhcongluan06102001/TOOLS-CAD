"""Execute pure production junction planning with VeLisp, without an AutoCAD DB.
Usage: python tools/test_junctions.py /path/to/velisp/src/main.js
VeLisp compatibility adapters only: RTOS integer formatting and EQUAL fuzz.
"""
import pathlib
import subprocess
import sys
import tempfile
root = pathlib.Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as tmp:
    script = (root / 'tests/geometry/edge-junctions.lsp').read_text() + '\n' + (root / 'tests/geometry/manual-sizing.lsp').read_text()
    for module in ('tc-geometry', 'tc-mep', 'tc-junctions'):
        relative = f'source/lisp/{module}.lsp'
        target = pathlib.Path(tmp) / f'{module}.lsp'
        target.write_text((root / relative).read_text().replace('(equal ', '(test:equal '))
        script = script.replace(relative, str(target))
    test = pathlib.Path(tmp) / 'test.lsp'
    test.write_text(script)
    result = subprocess.run(['node', sys.argv[1], '--no-dcl', str(test)], capture_output=True, text=True)
    print(result.stdout, end='')
    print(result.stderr, end='')
    if result.returncode or 'PASS: 67 total geometry and manual size assertions.' not in result.stdout or 'Error:' in result.stderr:
        sys.exit(1)
