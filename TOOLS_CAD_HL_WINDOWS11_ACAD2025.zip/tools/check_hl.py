"""Static structural/regression checks; does not simulate the AutoCAD host."""
import base64, hashlib, json, re, zipfile
from pathlib import Path
r=Path(__file__).resolve().parents[1]
def tokens(s):
    return re.findall(r'"(?:\\.|[^"\\])*"|;[^\n]*|[()]|[^\s()\";]+',s)
def check(s):
    depth=0
    for t in tokens(s):
        if t.startswith(';'): continue
        if t=='(': depth+=1
        if t==')': depth-=1
        assert depth>=0, 'Unexpected closing parenthesis'
    assert depth==0, 'Unbalanced parentheses'
paths=list((r/'source/lisp').glob('*.lsp'))+[r/'ToolsCadHL.lsp']
for p in paths: check(p.read_text())
s=(r/'ToolsCadHL.lsp').read_text()
for p in (r/'source/lisp').glob('*.lsp'): assert p.read_text().strip() in s, p
# Resolve internal calls outside strings/comments, including quoted callbacks.
plain=' '.join(t for t in tokens(s) if not t.startswith(('"',';'))).lower()
defs=set(re.findall(r'\( defun (tc:[^\s()]+)',plain))
refs=set(re.findall(r"(?:\( |')((?:tc:)[^\s()]+)",plain))
assert not refs-defs, refs-defs
assert s.count('(defun tc:ogm-entry ') == 1, 'Duplicated flexible duct module'
assert "(defun c:HLFLOAT () (tc:open-palette 'FLOAT))" in s
assert "(tc:run '(lambda () (tc:palette-command *tc-ui-command*)))" in s
assert '_011' not in s and '_012' not in s
entry=(r/'source/palette/Entry.cs').read_text()
assert entry.index('if (palette.Dock != DockSides.None) palette.Dock = DockSides.None;') < entry.index('palette.DockEnabled = DockSides.None;')
assert 'doc.LispEnded += LispFinished' in entry and 'observed.LispEnded -= LispFinished' in entry
assert 'doc.LispCancelled += LispAborted' in entry and 'observed.LispCancelled -= LispAborted' in entry
assert '[LispFunction("TC_PALETTE_FLOAT_013")]' in entry
with zipfile.ZipFile(r/'TOOLS_CAD_HL_CAI_DAT.zip') as z:
    assert z.testzip() is None
    for n,h in json.loads(z.read('SHA256SUMS.json')).items():
        assert hashlib.sha256(z.read(n)).hexdigest()==h,n
    assert z.read('ToolsCadHL.lsp')==(r/'ToolsCadHL.lsp').read_bytes()
    block=s.split('(setq *tc-palette-bytes* (list',1)[1].split('\n))',1)[0]
    assert base64.b64decode(''.join(re.findall('"([A-Za-z0-9+/=]+)"',block)))==z.read('ToolsCadPalette.dll')
print(f'PASS: {len(paths)} LISP files balanced, {len(defs)} internal functions resolved; float/dispatcher regression checks and ZIP/embedded DLL integrity.')

# Literal DCL callback keys, native dialog delimiters, and namespace safeguards.
dcl=(r/'source/TOOLS-CAD.dcl').read_text()
keys=set(re.findall(r'key\s*=\s*"([^"]+)"',dcl))|{'accept','cancel'}
ui=(r/'source/lisp/tc-ui.lsp').read_text()
used=set(re.findall(r'\((?:action_tile|set_tile|get_tile|start_list|mode_tile|tc:list-tile)\s+"([^"]+)"',ui))
assert not used-keys,used-keys
assert s.index(';;; BEGIN HL NAMESPACE GUARD') < s.index('(setq *tc-dcl-lines*')
assert "(if (not (boundp 'C:TOOLS))" in s
assert "(defun tc:browser ( / *error*" in ui
import xml.etree.ElementTree as ET
xml=ET.parse(r/'installer/PackageContents.xml')
req=xml.find('.//RuntimeRequirements')
assert req.attrib['SeriesMin']==req.attrib['SeriesMax']=='R25.0'
assert xml.find('.//ComponentEntry').attrib['ModuleName']=='./Contents/ToolsCadHL.lsp'
print('PASS: DCL keys, namespace guard, alias preservation, browser cleanup and AutoCAD 2025 manifest.')

# External .NET LispFunction callbacks must execute inside a Lisp lambda;
# do not pass the external function symbol itself to apply/catch-all-apply.
for path in [r/'source/lisp/tc-palette.lsp',r/'source/lisp/tc-mep.lsp']:
    code=path.read_text()
    assert not re.search(r"\(vl-catch-all-apply\s+'TC_PALETTE_",code),path
    assert not re.search(r"'TC_PALETTE_(?:FLOAT|DOCK|SHOW)_013",code),path
bridge=(r/'source/lisp/tc-palette.lsp').read_text()
for name in ['VERSION','STATUS','LIVE','TAKE','DONE']:
    assert re.search(r"\(vl-catch-all-apply\s+'\(lambda \(\) \(TC_PALETTE_"+name+r"_013",bridge),name
for name in ['FLOAT','DOCK','SHOW']:
    assert '(TC_PALETTE_'+name+'_013)' in bridge,name
assert "(vl-catch-all-apply '(lambda () (TC_PALETTE_CURRENT_013)) nil)" in (r/'source/lisp/tc-mep.lsp').read_text()
print('PASS: all nine .NET LispFunction calls are invoked inside protected Lisp lambdas (static regression).')
