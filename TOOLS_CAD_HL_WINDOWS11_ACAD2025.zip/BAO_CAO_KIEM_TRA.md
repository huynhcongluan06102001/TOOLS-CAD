# Báo cáo 0.14.3

Đã bỏ nhãn cá nhân trong bản phát hành. File DWG thư viện chọn tên bất kỳ.
Đọc danh mục và nhập block bằng Database.ReadDwgFile/WblockCloneObjects của
API AutoCAD 2025. Không cần mở thư viện như bản vẽ làm việc. Thư viện chỉ đọc;
không ghi đè block cùng tên ở bản vẽ đích. Giữ các chức năng hiện có.

Build net8.0-windows API 2025: PASS. Kiểm tra tĩnh LISP/DCL/bridge và checksum
ZIP: PASS. Chưa chạy nhập DWG, xử lý dynamic block, Undo hay GUI trong AutoCAD.
Không có DWG thư viện/mẫu nên lỗi chân rẽ/tê/gót giày thực tế chưa được xác nhận
đã khắc phục. TCINIT bổ sung liệt kê tên block ống gió thiếu trong thư viện.

Chạy lại: dotnet build source/palette/ToolsCadPalette.csproj -c Release
-p:RestoreLockedMode=true (cùng một dòng); dotnet run --project tests/domain/Domain.csproj;
python tools/package_hl.py <DLL>; python tools/check_hl.py; python tools/make_installer.py.

## 0.14.4
Thêm LayerChoice đọc LayerTable của MdiActiveDocument mỗi lần xổ; giữ nhập
layer mới, không liệt kê layer phụ thuộc Xref. Bộ tạo đối tượng dùng
Color=256; không sửa layer màu đã có hoặc định nghĩa block/style dùng chung.
Build API 2025 và kiểm tra tĩnh PASS; chưa kiểm thử UI/màu hiển thị AutoCAD.

## 0.14.5
Người dùng báo native crash lúc xổ Layer ở 0.14.4. Loại bỏ cập nhật Items và
đọc Database trong DropDown; bỏ Shell AutoComplete; nút nạp riêng với kiểm tra
CAD nhàn rỗi và document lock. Tương tự cho MLINE style. Chưa tái hiện host
crash, không khẳng định root cause chỉ từ ảnh. Cần kiểm thử AutoCAD/CER.

## 0.14.6
Bỏ LayerChoice/DrawingLayers. Các thao tác menu lấy CLAYER trong LISP khi
áp dụng cấu hình lệnh; DIM tạo từ menu theo cùng layer. Không nhập tên hoặc
đọc LayerTable từ WinForms. Đối tượng mới ByLayer; giữ override nội bộ của
block/style. Build/static PASS, chưa kiểm thử native AutoCAD.

## 0.14.7
- Translate right-hand navigation labels without changing saved preference keys.
- Light brown menu surfaces, cream inputs, darker selected tab.
- Retain native CLAYER drawing from 0.14.6.
- AutoCAD UI runtime validation requires Windows/AutoCAD 2025.
