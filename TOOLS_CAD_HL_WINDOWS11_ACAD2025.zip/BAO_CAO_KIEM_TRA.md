# Báo cáo 0.14.3

Đã bỏ nhãn cá nhân trong bản phát hành. File DWG thư viện chọn tên bất kỳ.
Đọc danh mục và nhập block bằng Database.ReadDwgFile/WblockCloneObjects của
API AutoCAD 2025. Không cần mở thư viện như bản vẽ làm việc. Thư viện chỉ đọc;
không ghi đè block cùng tên ở bản vẽ đích. Giữ các chức năng hiện có.

Build net8.0-windows API 2025: PASS. Kiểm tra tĩnh LISP/DCL/bridge và checksum
ZIP: PASS. Chưa chạy nhập DWG, xử lý dynamic block, Undo hay GUI trong AutoCAD.
Không có DWG thư viện/mẫu nên lỗi chân rẽ/tê/gót giày thực tế chưa được xác nhận
đã khắc phục. TCINIT bổ sung liệt kê tên block ống gió thiếu trong thư viện.

Chạy lại: dotnet build source/palette/ToolsCadPalette.csproj -c Release
-p:RestoreLockedMode=true (cùng một dòng); dotnet run --project tests/domain/Domain.csproj;
python tools/package_hl.py <DLL>; python tools/check_hl.py; python tools/make_installer.py.

## 0.14.4
Thêm LayerChoice đọc LayerTable của MdiActiveDocument mỗi lần xổ; giữ nhập
layer mới, không liệt kê layer phụ thuộc Xref. Bộ tạo đối tượng dùng
Color=256; không sửa layer màu đã có hoặc định nghĩa block/style dùng chung.
Build API 2025 và kiểm tra tĩnh PASS; chưa kiểm thử UI/màu hiển thị AutoCAD.

## 0.14.5
Người dùng báo native crash lúc xổ Layer ở 0.14.4. Loại bỏ cập nhật Items và
đọc Database trong DropDown; bỏ Shell AutoComplete; nút nạp riêng với kiểm tra
CAD nhàn rỗi và document lock. Tương tự cho MLINE style. Chưa tái hiện host
crash, không khẳng định root cause chỉ từ ảnh. Cần kiểm thử AutoCAD/CER.

## 0.14.6
Bỏ LayerChoice/DrawingLayers. Các thao tác menu lấy CLAYER trong LISP khi
áp dụng cấu hình lệnh; DIM tạo từ menu theo cùng layer. Không nhập tên hoặc
đọc LayerTable từ WinForms. Đối tượng mới ByLayer; giữ override nội bộ của
block/style. Build/static PASS, chưa kiểm thử native AutoCAD.

## 0.14.7
- Translate right-hand navigation labels without changing saved preference keys.
- Light brown menu surfaces, cream inputs, darker selected tab.
- Retain native CLAYER drawing from 0.14.6.
- AutoCAD UI runtime validation requires Windows/AutoCAD 2025.

## 0.14.8
- Extend interior branch edge-to-centre reach to all systems, including supported 45-degree junctions (half width / sin(angle)).
- Keep endpoint elbows/reducers restricted to existing gap; unsupported Y combinations still rejected.
- Show explicit UI/command warnings when auto-connect is off or no compatible run/junction was found.
- 42 pure planning assertions passed via tools/test_junctions.py and VeLisp with documented RTOS/EQUAL adapters. This does not test AutoCAD insertion, ports, dynamic properties or trimming.

## 0.14.9
Move long hints to page bottom; reserve preferred input height; full-width MLINE selector and separate refresh button; size dropdown width from existing items only. Reset native palette title after showing restored window. No geometry changes. Runtime DPI/layout validation still requires AutoCAD.

## 0.14.10
Manual fitting resolves size-specific block after reading selected main/branch segments; Enter keeps manual dimensions. Dynamic Width alias and actual Height supported. Validate widths after Height mutation. Replace AutoSize GroupBox/docked-child layout with direct table measurement; compact refresh button. 67 pure/mocked assertions pass, including five-system manual dimension extraction. No AutoCAD block/visibility/port or UI runtime validation.

## 0.14.11
Bound action button height to 33 logical units; disable button AutoSize, dock buttons and nested tables Top instead of Fill. Shorten fitting edit caption. No geometry changes. AutoCAD DPI runtime check pending.

## 0.14.12
Move fitting placement/edit buttons from nested fitting table to root page table alongside flow/statistics buttons. Identical shared sizing/margins; no nested group clipping for these two actions. Build/static/package checks; AutoCAD visual validation pending.

## 0.14.13
Flatten all section tables into page layout, removing nested measurement at final rows. Use width/DPI-aware preferred heights for every checkbox and top docking to allow wrapped labels. No drawing behavior changes. Build/static/package validation; AutoCAD runtime UI verification pending.

## 0.14.14
Integrated user OGM.lsp under tc:ogm-/HLOGM_ namespace with guarded short aliases. Native SPLINE executes outside shared catch/undo transaction; original OGM cleanup retained. Four FLEX actions only in DUCT, source mode follows checkbox, diameter prompted separately. Menu-generated flex routes support common note switches. Reordered tabs with index migration. Added independent persisted prefix/suffix/material flags with legacy defaults enabled.
Validation: build; 321 domain assertions; 226 pure OGM pattern/note assertions (VeLisp RTOS/COM init adapters); 67 existing junction/mocked sizing assertions; structural/package checks. Host UI, native preview, cancellation, Undo and COM not executed.

## 0.14.15
Move note flags to end of MEP pages. Replace nested duct option AutoSize tables/flows with explicit width/DPI-measured rows; 36 logical unit square buttons, 8pt labels, no padding. No LISP behavior changes. Host DPI testing pending.

## 0.14.16
Default palette MLINE style Standard on view initialization. Explicit refresh imports/list styles from selected side DWG database into active document MLStyleDictionary, Ignore duplicate names to preserve existing geometry. Dropdown performs no DB operations. Accept style-only DWGs. Failed refresh retains old UI list. Host cloning verification pending.
