# Báo cáo 0.14.3

Đã bỏ nhãn cá nhân trong bản phát hành. File DWG thư viện chọn tên bất kỳ.
Đọc danh mục và nhập block bằng Database.ReadDwgFile/WblockCloneObjects của
API AutoCAD 2025. Không cần mở thư viện như bản vẽ làm việc. Thư viện chỉ đọc;
không ghi đè block cùng tên ở bản vẽ đích. Giữ các chức năng hiện có.

Build net8.0-windows API 2025: PASS. Kiểm tra tĩnh LISP/DCL/bridge và checksum
ZIP: PASS. Chưa chạy nhập DWG, xử lý dynamic block, Undo hay GUI trong AutoCAD.
Không có DWG thư viện/mẫu nên lỗi chân rẽ/tê/gót giày thực tế chưa được xác nhận
đã khắc phục. TCINIT bổ sung liệt kê tên block ống gió thiếu trong thư viện.

Chạy lại: dotnet build source/palette/ToolsCadPalette.csproj -c Release
-p:RestoreLockedMode=true (cùng một dòng); dotnet run --project tests/domain/Domain.csproj;
python tools/package_hl.py <DLL>; python tools/check_hl.py; python tools/make_installer.py.
