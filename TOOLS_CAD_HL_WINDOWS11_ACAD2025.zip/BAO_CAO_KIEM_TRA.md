# Báo cáo bàn giao TOOLS-CAD HL 0.13

## Phạm vi và trạng thái

Tiếp tục mã hiện có từ commit 06150a9 (deliver/tools-cad-duy-autocad2025),
không tạo dự án thay thế. main chỉ có README. Các module nguồn được khôi phục
nguyên bản từ ZIP phát hành rồi sửa tập trung. Không có lịch sử ngoài cuộc
trò chuyện hiện tại để khẳng định yêu cầu trước đó đã hoàn tất toàn bộ.

Đã có các nhóm lệnh vẽ/chuyển tuyến PPR, UPVC, thép, máng, duct; fitting;
block; điện; DIM/ghi chú; thống kê/CSV và công cụ kiểm tra. Danh sách sinh từ
registry thực tế nằm trong DANH_SACH_LENH.md. Các chức năng được giữ lại,
nhưng trạng thái nghiệm thu trên AutoCAD chưa được xác nhận.

## Các file nguồn đã sửa từ bản gốc

- source/lisp/tc-commands.lsp: giữ alias có sẵn của LISP khác, không ghi đè.
- source/lisp/tc-mep.lsp: cập nhật cầu nối DLL _012.
- source/lisp/tc-core.lsp: phiên bản 0.13.
- source/lisp/tc-palette.lsp: HLFLOAT, cầu nối _012, thông báo phiên bản.
- source/lisp/tc-ui.lsp: DCL dispatcher nội bộ; dọn dialog/file TEMP khi lỗi.
- source/palette/Entry.cs: cầu nối HLFLOAT; DockEnabled=None ở chế độ nổi.
- source/palette/Profiles.cs: từ chối hệ sai và số NaN/Infinity/âm không hợp lệ.
- source/palette/LispWire.cs: từ chối số không hữu hạn trước khi gửi AutoLISP.
- source/palette/AssemblyInfo.cs: phiên bản DLL.
- source/palette/ToolsCadPalette.csproj: phiên bản build.
- source/palette/PaletteView.cs: chặn tràn double->decimal trước khi gán control.

Thêm kiểm tra namespace ở đầu LSP phát hành trước mọi ghi biến dự án; nếu
TC/HL đã có mã khác sử dụng, dừng nạp thay vì ghi đè. Alias chung đã tồn tại
được giữ lại. Không thể bảo vệ trước một LISP khác cố tình ghi đè sau khi nạp.
TOOLS-CAD_DUY.lsp và ZIP DUY cũ trong repository không bị sửa.

Cập nhật LSP tổng hợp, ZIP HL; thêm installer, hướng dẫn, bộ kiểm tra và
script đóng gói. Không có thay đổi thuật toán hình học để che giấu lỗi host.

## Kết quả kiểm tra tại môi trường Linux

- Build Release x64 net8.0-windows với AutoCAD.NET 25.0.1, locked restore: PASS,
  0 cảnh báo, 0 lỗi. Dùng `-p:RestoreLockedMode=true` với dotnet build.
- 312 assertions trên Profiles, catalog phụ kiện, số hợp lệ/không hợp lệ,
  culture vi-VN và escaping LispWire: PASS. Chạy mã domain thật; kiểm tra round-trip JSON với System.Text.Json và
  chuỗi Unicode. Chưa kiểm thử ghi cấu hình trong hồ sơ Windows thực tế.
- 16 file LISP cân bằng ngoặc, 220 hàm nội bộ có định nghĩa: PASS.
  Đây là kiểm tra tĩnh, không phải chạy trình thông dịch AutoLISP.
- Đối chiếu khóa literal của DCL/callback: PASS; XML bundle cho R25.0: PASS.
- HLFLOAT bridge, bảo vệ alias, dọn DCL khi lỗi: kiểm tra tĩnh PASS.
- DLL nhúng khớp DLL phát hành; CRC và SHA-256 các file ZIP: PASS.
- Python compile, git diff --check: PASS.

## Chưa thể kiểm chứng / điều kiện nghiệm thu

Không có AutoCAD, Windows GUI hoặc PowerShell trong môi trường này.
Chưa chạy Install/Uninstall trên Windows; chỉ rà soát script và cấu trúc gói.
Chưa chạy AutoLoader/NETLOAD/Trusted Locations, tạo/mở DCL, WinForms,
kéo bảng nhiều màn hình/DPI, ObjectDBX, COM, hình học MEP, Undo hay TCSELFTEST.
Không có template CAd Duy.dwg hoặc LISP bên thứ ba để kiểm tra phối hợp.
Không khẳng định đã sửa mọi lỗi bad function hay đảm bảo ổn định sản xuất.

Bộ cài có đủ mã và tài nguyên giao diện hiện có để thử cài trên Windows;
nghiệm thu theo HLFLOAT_CHECK.md và HUONG_DAN_CAI_DAT.md là bước còn lại.
Nếu có lỗi, cần F2 đầy đủ, HLSTATUS, dữ liệu tái hiện và thứ tự APPLOAD.

## Chạy lại kiểm tra/build

```
dotnet run --project tests/domain/Domain.csproj
dotnet build source/palette/ToolsCadPalette.csproj -c Release -p:RestoreLockedMode=true
python tools/package_hl.py source/palette/bin/Release/net8.0-windows/ToolsCadPalette.dll
python tools/check_hl.py
python tools/make_installer.py
```

tools/package_hl.py cập nhật bản giao hàng HL hiện có; tools/make_installer.py
sinh một ZIP tổng hợp. Các bản ZIP được lồng trong gói chỉ phục vụ tái build,
không nạp nhiều bản LSP. Dùng duy nhất ToolsCadHL.bundle cho cài đặt.

## Chuyển sang AutoCAD 2025 (0.13)

- net8.0-windows x64, WinForms; AutoCAD.NET 25.0.1 (API 2025),
  AutoCAD.NET.Core 25.0.0. Package 25.0.0 có phụ thuộc prerelease không tồn tại;
  dùng bản 25.0.1 có dependency net8.0 hợp lệ, không bỏ kiểm tra NuGet.
- Thay System.Web JavaScriptSerializer bằng System.Text.Json của .NET 8.
- Cầu nối _013 và phiên bản DLL 0.13.0; cache/cấu hình riêng thư mục 2025.
- Manifest AutoLoader chỉ R25.0; LSP chặn nạp nhầm phiên bản AutoCAD.
- Build locked restore PASS, 0 warning/0 error; domain 312 assertions PASS;
  kiểm tra tĩnh LISP/DCL, DLL nhúng và ZIP PASS.
- DLL này không dùng cho AutoCAD 2024. Bản ZIP 2024 trước đó được giữ riêng.
- Chưa chạy AutoCAD 2025, Windows installer hoặc kéo thả trên GUI thực tế.
