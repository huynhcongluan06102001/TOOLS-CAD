# TOOLS CAD HL 0.14.26

Nền mã và bộ cài: 0.14.25. Không thay đổi thuật toán 12 mẫu MP/RS, ba mẫu VP cũ, nhãn giữa tuyến hay các hệ khác. Không gộp K3 thử nghiệm vào bản tools.

UPVC+ có nút chèn trục đứng toàn chiều rộng; phía dưới là 10 hàng hai cột theo hình yêu cầu. Thứ tự MP/RS được ghép cặp, sau đó VP1T+1E90 / 1Z1YU+1E45, VP1T+1E45 / 2Z1YU+3E45, VP2T / 1E45, VPB-M / 2E45.

## Đã kiểm tra trong môi trường xây dựng

- Đọc đối tượng và hình học các trạng thái đã đánh giá từ `upvc.dwg` người dùng gửi. Nhúng file nguyên bản, không chuyển đổi hoặc ghi lại DWG.
- Bộ kiểm tra domain: **15.473 assertions** gồm các kiểm tra sẵn có và phần mới: tra mẫu, xác định cổng từ hình học mẫu, chuỗi co, hai trục có đầu neo cố định, nhiều góc xoay/đảo hướng/thứ tự đỉnh, sai số ±2°, ±3°, ±5°, loại bỏ 6° và khoảng đặt phụ kiện quá ngắn.
- Biến thể size trong kiểm tra domain là dữ liệu hình học mô phỏng theo tỷ lệ. Đây không phải xác nhận tất cả block size khác nhau trong thư viện của người dùng. Mã chạy thật dùng block đúng tên size ở tỷ lệ gốc, đọc cổng thực sau khi đặt trạng thái.
- 40 kiểm tra luồng chọn/gọi năm nút mới bằng VeLisp với API AutoCAD/.NET giả lập; 16 kiểm tra batch MP/RS.
- Biên dịch .NET AutoCAD 2025 không lỗi/cảnh báo; kiểm tra ngoặc và tham chiếu LISP, version và checksum DLL nhúng/bundle/ZIP.

## Chưa xác nhận trên AutoCAD

Môi trường xây dựng không có AutoCAD Windows. Không khẳng định đây là bộ kiểm thử DWG tích hợp hoặc bảo đảm không lỗi. Cần xác nhận lại trạng thái/flip của thư viện thực, vị trí cổng, Undo, DPI và bảng dock trong AutoCAD 2025.

## Quy trình thử bản sao DWG

1. Đóng/mở AutoCAD sau khi cài, `HLSTATUS`: LSP/DLL 0.14.26. Mở UPVC+; đủ 20 nút và tên đầy đủ ở DPI đang dùng. Thu hẹp bảng để kiểm tra cuộn ngang, không chồng nút.
2. Nạp thư viện đầy đủ. Với mỗi cụm **trước khi nối** trong upvc.dwg, chạy nút tương ứng. Không chọn cụm đã có phụ kiện ở bên dưới.
3. So sánh hướng/visibility với cụm mẫu sau: VPB-M (hai trục), 1Z1YU+1E45 (trục + MLINE), 2Z1YU+3E45 (hai trục), 1E45 (đổi hướng 45°), 2E45 (đổi hướng 90°).
4. Thử size khác có sẵn trong thư viện. Kiểm tra width MLINE bằng size nhánh; block vẫn dùng định nghĩa đúng size, không phóng toàn cụm theo size mẫu.
5. Thử xoay cả cụm, đảo thứ tự đầu MLINE, nhánh lệch 2°/5° và 6°. Hai nút co phải giữ đầu xa và đưa góc 45°/90° đúng theo ống thứ nhất trong ±5°; 6° bị từ chối.
6. Thử hai layer khác nhau; kiểm tra từng block/MLINE theo layer đã mô tả. Bật/tắt cắt ống và thử ngậm khác 0.
7. Thử ống quá ngắn, thiếu block/trạng thái, layer khóa và Esc ở bước chọn thứ hai: không mất hình học nguồn. Gõ U sau thành công để hoàn tác toàn lượt.
8. Thử lại một mẫu MP, RS, VP và một tuyến UPVC/PPR/DUCT để kiểm tra chức năng đang dùng.
