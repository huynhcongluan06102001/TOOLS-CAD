# Kiểm tra 0.14.30

- Build AutoCAD.NET 25 / .NET 8 Windows: không lỗi/cảnh báo.
- 17.585 domain assertions, bao gồm 290 kiểm tra mới: giữ hai đầu tuyến,
  chỉ cắt khoảng van, bảo toàn chiều dài còn lại, bù tâm khi xoay/đổi trạng thái,
  loại bỏ điểm cắt đảo chiều hoặc lệch tim.
- 7 kiểm tra wrapper LISP về commit/cancel/cleanup; 27 kiểm tra danh mục STEEL.
- Không còn EntityJig cập nhật dynamic block liên tục; DrawJig vẽ hình học
  đã sao chép bằng ma trận. Hủy bản sao mỗi lần kết thúc lượt kéo.
- Visibility được commit trước khi đo lại hình học; block thật ẩn bằng một
  transaction đã commit trước khi kéo; khôi phục Visible trong finally.
- Không RemoveLastSegment khi cắt MLINE. Append MLINE mới trước, kiểm tra
  đỉnh/scale/style/extents rồi mới Erase tuyến gốc cùng transaction.
- ZIP: kiểm tra CRC, SHA256, phiên bản và DLL nhúng.

Không có AutoCAD Windows tại môi trường thực hiện. Các kiểm tra không xác nhận
WorldDraw, Visibility evaluation, graphics refresh hay native MLINE regeneration
trên host; cần thử bằng bản sao bản vẽ thực tế. Chưa có số đo FPS.
