# Kiểm tra 0.14.33

Đã xem các khung hình video 35,67 giây. Video không chứa vùng dòng lệnh,
không xác định được thông báo native commit nếu có. Không khẳng định đã tái
hiện đầy đủ lỗi click trên host chỉ từ video.

- Bỏ SamplerStatus.NoChange ở nhánh xoay khi cùng nấc góc hoặc ở điểm neo.
- Ưu tiên Drag OK trước sampler None, áp dụng pose cuối rồi commit một lần.
- ValveEnd lỗi trả về ngay, không quay lại vòng Drag. Transaction lỗi không xóa ống.
- VALVES gọi tc:library-path; Load gọi TCTEMPLATE chung, bỏ chặn bằng ValveLibrary cũ.
- Thư viện chỉ có block definition được nhập bằng tên catalog với scale mẫu gốc.
- STEEL đọc thư viện chung trước; fallback nhúng chỉ cho tên block thiếu.
- Build: 0 warning, 0 error. 7 kiểm tra wrapper và 2 kiểm tra thư viện mô phỏng qua.
- Kiểm tra tĩnh điểm chèn 19 nhóm/176 mẫu và đường xử lý click/thư viện qua.
- Gói ZIP kiểm tra SHA256, CRC và phiên bản DLL/LISP.

Chưa có AutoCAD Windows để thử chuột thật, Dynamic Input, DrawJig, Space hoặc
import block từ thư viện tổng mới của người dùng. Mã đã biên dịch không tương
đương kiểm thử tương tác thành công trên AutoCAD.
