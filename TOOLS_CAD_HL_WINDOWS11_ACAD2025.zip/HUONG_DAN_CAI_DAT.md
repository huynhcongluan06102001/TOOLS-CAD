# 0.14.12 — nút phụ kiện cùng kích thước với nút thống kê

Đóng toàn bộ AutoCAD, thay ToolsCadHL.bundle trong %APPDATA%\Autodesk\ApplicationPlugins bằng bundle mới. Mở lại và kiểm tra HLSTATUS báo LISP/DLL 0.14.12.
ĐẶT PHỤ KIỆN và SỬA THUỘC TÍNH nằm trực tiếp trong bảng chính, cùng chiều rộng/chiều cao với TẠO HƯỚNG CHẢY và THỐNG KÊ. Hai nút không còn nằm trong vùng nhóm phụ kiện gây che hàng cuối.
Không thay đổi chức năng vẽ hoặc đặt phụ kiện. Chưa kiểm thử trực tiếp giao diện trên AutoCAD.

# 0.14.11 — thu gọn nút phụ kiện

Đóng toàn bộ AutoCAD, thay ToolsCadHL.bundle trong %APPDATA%\Autodesk\ApplicationPlugins bằng bundle mới. Mở lại và kiểm tra HLSTATUS báo LISP/DLL 0.14.11.
Các nút hành động dùng cùng chiều cao 33 đơn vị giao diện (Windows tự scale theo DPI), không giãn dọc theo nhóm chứa. Nút SỬA THUỘC TÍNH PHỤ KIỆN rút gọn nhãn thành SỬA THUỘC TÍNH; lệnh vẫn là TCBEDIT.
Chưa kiểm thử hiển thị trực tiếp trong AutoCAD. Chức năng vẽ/phụ kiện giữ nguyên 0.14.10.

# 0.14.10 — kích thước phụ kiện và bố cục

Đóng toàn bộ AutoCAD, thay ToolsCadHL.bundle trong %APPDATA%\Autodesk\ApplicationPlugins; mở lại và kiểm tra HLSTATUS báo LISP/DLL 0.14.10.

ĐẶT PHỤ KIỆN: chọn loại trong bảng rồi bấm đặt. Chọn ống chính để lấy vật liệu, D/DN hoặc W/H thực tế. Với tê/Y/gót giày/côn/cross, chọn thêm nhánh/đầu thứ hai; Enter tại bước này dùng cùng kích thước ống chính. Sau đó chọn điểm đặt và góc. Với côn giảm chọn đầu lớn làm ống chính. Enter ngay bước chọn ống chính giữ cách nhập tay cũ. Các cặp co lên/xuống vẫn có bước chọn MLINE riêng.
Layer phụ kiện vẫn theo layer hiện hành của CAD. Chức năng này lấy kích thước, không tự suy đoán hướng đặt trong chế độ thủ công.
Tự nối tiếp tục đọc kích thước từ các đoạn được nối. Thêm kiểm tra kích thước rộng sau khi đặt Height, hỗ trợ tên thông số Width và ưu tiên Height thực của block hơn metadata cũ.
GHI CHÚ dùng bố cục tự đo trực tiếp để tránh cắt ô Cao chữ. Nút Nạp style thu gọn.

67 kiểm tra hình học/lấy kích thước với các hàm CAD mô phỏng đã qua. Chưa kiểm chứng dynamic block, visibility, cổng nối và DPI thực tế trên AutoCAD. Nếu block vẫn sai hình, gửi DWG mẫu và kết quả TCINSPECT của block đó.

# 0.14.9 — bố cục menu gọn hơn

Đóng toàn bộ AutoCAD rồi thay ToolsCadHL.bundle trong %APPDATA%\Autodesk\ApplicationPlugins bằng bundle mới. Mở lại, dùng HLSTATUS xác nhận LISP/DLL 0.14.9, HLFLOAT mở bảng.
Tiêu đề chỉ còn TOOLS CAD HL; số phiên bản xem bằng HLSTATUS.
Hướng dẫn dài được chuyển xuống cuối tab. Ô MLINE style dùng hết chiều rộng, nút nạp đặt bên dưới. Ô số dành đủ chiều cao và danh sách xổ tự mở rộng theo nội dung.
Giữ màu nâu nhạt, tab tiếng Anh và cơ chế vẽ/phụ kiện của 0.14.8.
Cần kiểm tra trực tiếp giao diện ở mức DPI Windows đang dùng; chưa chạy AutoCAD trong môi trường build.

# 0.14.8 — kết nối nhánh tại mép tuyến chính

Đóng toàn bộ AutoCAD, thay nguyên ToolsCadHL.bundle trong %APPDATA%\Autodesk\ApplicationPlugins, mở lại và dùng HLSTATUS xác nhận LISP/DLL 0.14.8.

1. Chọn/nạp lại thư viện DWG chứa đúng block phụ kiện.
2. Chọn layer hiện hành giống tuyến chính, đúng hệ và vật liệu.
3. Bật “Tự nối vào tuyến cùng layer”. Nếu tắt, tools chỉ tạo co ở các góc của tuyến mới, không tự chèn tê/chạc vào tuyến cũ.
4. Vẽ nhánh kết thúc tại tim hoặc mép ngoài tuyến chính. Nhánh vuông góc dùng tê/gót giày; nhánh 45 độ dùng Y nếu thư viện có tổ hợp được hỗ trợ. Thang máng và ống gió tròn chưa hỗ trợ nhánh Y tự động.
5. Với tuyến đã vẽ: dùng “TỰ ĐỘNG KẾT PHỤ KIỆN”, chọn đoạn chính rồi đoạn nhánh. Không cần vẽ lại.
6. Nếu chưa tạo phụ kiện, xem cảnh báo dưới bảng và nhấn F2 để đọc lỗi. TCINIT kiểm tra thư viện; gửi log cùng DWG mẫu nếu lỗi vẫn còn.

Đã kiểm tra 42 trường hợp lập kế hoạch nút nối bằng trình thông dịch VeLisp (có bộ tương thích RTOS/EQUAL), biên dịch .NET và kiểm tra tĩnh. Chưa kiểm chứng chèn block/dynamic properties/cắt tuyến trong AutoCAD.
Không tự sửa hình học tuyến cũ hoặc bật lại lựa chọn tự nối đã lưu.

# 0.14.7 — menu nền nâu nhạt, tên tab tiếng Anh

Đóng toàn bộ AutoCAD trước khi thay bundle; DLL đã nạp không thể cập nhật trong phiên đang mở.
Thay thư mục ToolsCadHL.bundle trong %APPDATA%\Autodesk\ApplicationPlugins bằng bundle trong ZIP mới, rồi mở lại AutoCAD 2025.
Gõ HLSTATUS để xác nhận LISP và DLL 0.14.7; HLFLOAT để mở bảng.
Tên tab bên phải dùng tiếng Anh; các thông số và khóa lưu cấu hình giữ nguyên.
Chọn layer hiện hành trên thanh Layer của AutoCAD trước khi nhấn vẽ; không nhập tên layer trong tools.
Bản này giữ thay đổi CLAYER của 0.14.6. Chưa kiểm thử giao diện trực tiếp trong AutoCAD.

# 0.14.6 — dùng layer hiện hành của AutoCAD

Đóng AutoCAD, thay nguyên bundle mới và mở lại. HLSTATUS phải báo 0.14.6.
Không còn ô nhập/xổ layer trong tools và không cần nút Nạp layer.

1. Trên thanh Layer mặc định của AutoCAD, chọn layer hiện hành muốn vẽ.
   Nếu đang chọn đối tượng, nhấn Esc trước để tránh chỉ đổi layer đối tượng đó.
2. Bấm VẼ trong tools. Công cụ lấy CLAYER tại thời điểm bắt đầu lệnh.
3. Đổi layer trên thanh CAD trước khi bắt đầu tuyến tiếp theo nếu cần.
Layer đã lấy được giữ cho toàn bộ một lệnh; không đổi giữa các đoạn đang vẽ.
Đối tượng mới dùng ByLayer. Màu cố định bên trong block/MLINE style có thể
vẫn được ưu tiên; không tự thay định nghĩa dùng chung làm đổi đối tượng cũ.
Các lệnh chỉnh sửa/sao chép đối tượng cũ vẫn giữ ngữ nghĩa vốn có của chúng.

Bỏ đường đọc layer từ UI dropdown gây crash được báo ở 0.14.4.
Không cần cập nhật riêng 0.14.5; dùng trực tiếp gói này. Chưa chạy GUI AutoCAD.

---
Các hướng dẫn layer của bản cũ bên dưới không áp dụng cho 0.14.6.

# 0.14.5 — bản sửa sau báo cáo AutoCAD đóng khi xổ Layer

Ngừng dùng 0.14.4. Đóng AutoCAD, thay nguyên bundle mới và mở lại.
HLSTATUS phải báo LSP/DLL 0.14.5. Không chỉ APPLOAD đè vì DLL cũ vẫn trong RAM.

Cách dùng Layer: khi CAD không chạy lệnh, bấm NẠP LAYER, sau đó xổ chọn tên.
Sau khi đổi bản vẽ hoặc thêm layer, bấm NẠP LAYER lại. Vẫn gõ tên trực tiếp được.
MLINE style tương tự: bấm NẠP STYLE rồi xổ chọn.
Bản sửa không truy cập Database/đổi Items trong sự kiện DropDown, không dùng
Shell AutoComplete; việc đọc dùng document lock, chỉ theo nút nạp riêng.

Chưa tái hiện crash trong AutoCAD nên chưa khẳng định loại bỏ mọi nguyên nhân.
Thử trên bản vẽ NEW trước: nạp, xổ nhiều lần, vẽ, đổi bản vẽ, nạp lại.
Nếu vẫn văng, gửi thông báo Fatal Error/CER và DWG tối giản. Không lặp thử
trên bản vẽ chưa lưu. Có thể quay về 0.14.3 dùng ô nhập tên layer.

---
Tài liệu cũ bên dưới để tham khảo; cách nạp layer hiện tại theo phần trên.

# 0.14.4 — xổ chọn layer bản vẽ

Đóng AutoCAD và thay nguyên bundle mới. HLSTATUS phải báo LSP/DLL 0.14.4.
Ở mỗi tab, bấm mũi tên ô Layer để chọn layer của bản vẽ đang mở.
Danh sách cập nhật mỗi lần mở, kể cả sau khi tạo layer/đổi bản vẽ.
Có thể gõ tên mới như trước; layer Xref không nằm trong danh sách chọn.
Layer khóa/tắt/đóng băng vẫn được liệt kê nhưng lệnh vẽ sẽ báo yêu cầu mở layer.

Các đối tượng mới qua bộ tạo hình tools dùng Color=ByLayer (ACI 256).
Màu layer đã tồn tại được giữ nguyên. Với block có màu cố định ở nét bên
trong, hoặc MLINE style có màu từng nét riêng, màu nội bộ có thể ưu tiên
hơn ByLayer của đối tượng ngoài. Muốn toàn bộ nét theo layer: chuẩn hóa
block thư viện về layer 0/ByBlock và màu nét MLINE style về ByLayer.
Tools không tự đổi ruột block/style dùng chung vì có thể đổi đối tượng cũ.

Thử: chọn layer đỏ, vẽ một tuyến; chuyển layer xanh, vẽ tuyến khác;
đổi màu layer đỏ bằng LA, tuyến đầu phải cập nhật màu nếu không có override.
Chưa kiểm thử trực tiếp trên AutoCAD; kiểm tra Properties và gửi DWG nếu
block/style vẫn có màu cố định. Bản này chỉ sửa lựa chọn layer, không đổi
thuật toán phụ kiện.

---
# TOOLS-CAD 0.14.3 — AutoCAD 2025

## Cập nhật
Đóng toàn bộ AutoCAD. Sao lưu bundle cũ ra ngoài ApplicationPlugins rồi
chép nguyên ToolsCadHL.bundle mới vào. HLSTATUS phải báo LSP/DLL 0.14.3.
Nếu DLL vẫn trỏ bản cũ, HLLOAD chọn DLL trong Contents của bundle mới.
PowerShell bị chặn: chỉ chép bundle thủ công, không cần chạy Install.cmd.

## Bản vẽ mới và thư viện tên bất kỳ
1. Mở bản vẽ cần làm việc, không cần mở DWG thư viện.
2. APPLOAD ToolsCadHL.lsp nếu chưa tự nạp; HLFLOAT mở bảng.
3. Bấm CHỌN / NẠP LẠI THƯ VIỆN DWG. Chọn file .dwg có tên bất kỳ.
4. Tools kiểm tra đọc được danh sách block rồi mới lưu đường dẫn.
5. TCINIT in danh sách block ống gió còn thiếu; xem F2.
6. Vẽ tuyến/chèn phụ kiện: block thiếu trong bản vẽ được sao chép trực tiếp
   từ thư viện bằng API AutoCAD .NET, không cần mở bản vẽ thư viện.

Có thể đổi tên FILE DWG nhưng không tùy ý đổi tên block hoặc tham số dynamic
mà tools đang sử dụng. Block cùng tên đã có trong bản vẽ được giữ nguyên;
chọn thư viện khác không tự ghi đè định nghĩa cũ. Thử trong NEW để phân biệt.
Ví dụ tê chữ nhật dùng Chac 3, gót giày dùng Chac chu T cong, có hậu tố
cach nhiet/tieu am theo vật liệu. Chân rẽ trong danh sách phụ kiện thủ công
cần block Chan re hoặc Chan re vuong tron tương ứng. Thiếu block sẽ báo tên.

## Vẽ và giao diện
HLFLOAT: nổi; HLDOCK: ghim; HLTOOLS: hiện; HLSTATUS: phiên bản/đường dẫn DLL.
Chọn MLINE style trong tab pipe. Style cần hai nét ngoài đối xứng offset 0;
muốn có nét tim, dùng style có nét offset 0. TC_MC tạo được trong bản vẽ mới;
style khác cần nhập bằng MLSTYLE. Chọn DWG không tự nhập mọi MLINE style.
Góc FREE/45/90/BOTH tính theo đoạn trước. Khi Pick, hướng hiệu chỉnh sau khi
chọn điểm; đoạn đầu tự do. Center tại điểm tiếp theo cho phép chọn tim MLINE.
TCDCL là hộp thoại dự phòng. Thư viện hiện dùng DLL mới để đọc/nhập block.

## Kiểm thử và lỗi
Dùng bản sao DWG: vẽ lần một/lần hai, Enter/Esc, đổi bản vẽ, dock/float.
Thử TCFIT với co/tê/chạc/gót giày và kiểm tra kích thước main/nhánh.
TCINIT giúp tìm tên block thiếu; TCINSPECT xem tham số của block thực tế.
Chưa chạy AutoCAD trong môi trường phát triển. Chưa thể xác nhận mọi phụ kiện
đúng hình học nếu chưa có DWG mẫu và thư viện. Gửi F2 và hai DWG nếu còn lỗi.
Giữ SECURELOAD bật; chỉ thêm Contents của plugin vào Trusted Locations nếu
AutoCAD yêu cầu và chính sách máy cho phép.

## Gỡ cài
Đóng AutoCAD; Uninstall.cmd từ đúng gói hoặc sao lưu rồi bỏ bundle thủ công.
Bỏ Startup Suite/Trusted Location đã tự thêm. Giữ lại DWG và cấu hình cá nhân.
