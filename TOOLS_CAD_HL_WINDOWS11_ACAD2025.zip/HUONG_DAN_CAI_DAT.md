# TOOLS-CAD 0.14.3 — AutoCAD 2025

## Cập nhật
Đóng toàn bộ AutoCAD. Sao lưu bundle cũ ra ngoài ApplicationPlugins rồi
chép nguyên ToolsCadHL.bundle mới vào. HLSTATUS phải báo LSP/DLL 0.14.3.
Nếu DLL vẫn trỏ bản cũ, HLLOAD chọn DLL trong Contents của bundle mới.
PowerShell bị chặn: chỉ chép bundle thủ công, không cần chạy Install.cmd.

## Bản vẽ mới và thư viện tên bất kỳ
1. Mở bản vẽ cần làm việc, không cần mở DWG thư viện.
2. APPLOAD ToolsCadHL.lsp nếu chưa tự nạp; HLFLOAT mở bảng.
3. Bấm CHỌN / NẠP LẠI THƯ VIỆN DWG. Chọn file .dwg có tên bất kỳ.
4. Tools kiểm tra đọc được danh sách block rồi mới lưu đường dẫn.
5. TCINIT in danh sách block ống gió còn thiếu; xem F2.
6. Vẽ tuyến/chèn phụ kiện: block thiếu trong bản vẽ được sao chép trực tiếp
   từ thư viện bằng API AutoCAD .NET, không cần mở bản vẽ thư viện.

Có thể đổi tên FILE DWG nhưng không tùy ý đổi tên block hoặc tham số dynamic
mà tools đang sử dụng. Block cùng tên đã có trong bản vẽ được giữ nguyên;
chọn thư viện khác không tự ghi đè định nghĩa cũ. Thử trong NEW để phân biệt.
Ví dụ tê chữ nhật dùng Chac 3, gót giày dùng Chac chu T cong, có hậu tố
cach nhiet/tieu am theo vật liệu. Chân rẽ trong danh sách phụ kiện thủ công
cần block Chan re hoặc Chan re vuong tron tương ứng. Thiếu block sẽ báo tên.

## Vẽ và giao diện
HLFLOAT: nổi; HLDOCK: ghim; HLTOOLS: hiện; HLSTATUS: phiên bản/đường dẫn DLL.
Chọn MLINE style trong tab pipe. Style cần hai nét ngoài đối xứng offset 0;
muốn có nét tim, dùng style có nét offset 0. TC_MC tạo được trong bản vẽ mới;
style khác cần nhập bằng MLSTYLE. Chọn DWG không tự nhập mọi MLINE style.
Góc FREE/45/90/BOTH tính theo đoạn trước. Khi Pick, hướng hiệu chỉnh sau khi
chọn điểm; đoạn đầu tự do. Center tại điểm tiếp theo cho phép chọn tim MLINE.
TCDCL là hộp thoại dự phòng. Thư viện hiện dùng DLL mới để đọc/nhập block.

## Kiểm thử và lỗi
Dùng bản sao DWG: vẽ lần một/lần hai, Enter/Esc, đổi bản vẽ, dock/float.
Thử TCFIT với co/tê/chạc/gót giày và kiểm tra kích thước main/nhánh.
TCINIT giúp tìm tên block thiếu; TCINSPECT xem tham số của block thực tế.
Chưa chạy AutoCAD trong môi trường phát triển. Chưa thể xác nhận mọi phụ kiện
đúng hình học nếu chưa có DWG mẫu và thư viện. Gửi F2 và hai DWG nếu còn lỗi.
Giữ SECURELOAD bật; chỉ thêm Contents của plugin vào Trusted Locations nếu
AutoCAD yêu cầu và chính sách máy cho phép.

## Gỡ cài
Đóng AutoCAD; Uninstall.cmd từ đúng gói hoặc sao lưu rồi bỏ bundle thủ công.
Bỏ Startup Suite/Trusted Location đã tự thêm. Giữ lại DWG và cấu hình cá nhân.
