# TOOLS CAD HL 0.14.26 — UPVC+ hai cột, thêm năm mẫu nối

Đọc **DOC_TRUOC_KHI_CAI_0.14.26.txt** và **BAO_CAO_KIEM_TRA_0.14.26.md** trước. Bản này nâng cấp từ 0.14.25, có 20 nút nối trong 10 hàng hai cột theo hình yêu cầu; thêm VPB-M, 1Z1YU+1E45, 2Z1YU+3E45, 1E45 và 2E45 theo upvc.dwg.

1. Đóng toàn bộ AutoCAD. Chuyển bundle cũ ra **ngoài** `%APPDATA%\Autodesk\ApplicationPlugins` để sao lưu. Không đổi tên thành một thư mục `.bundle` khác ngay trong ApplicationPlugins vì AutoCAD vẫn có thể nạp bản cũ đó.
2. Chép `ToolsCadHL.bundle` từ ZIP mới vào ApplicationPlugins, hoặc chạy `Install.cmd` sau khi đã dời bản cũ.
3. Mở AutoCAD 2025, gõ `HLSTATUS`: cả LSP và DLL phải là **0.14.26**; gõ `HLTOOLS` để mở bảng.
4. Nạp thư viện phụ kiện UPVC đầy đủ. Thử trên bản sao DWG trước. Nếu dùng gỡ tự động, phải chạy `Uninstall.cmd` thuộc **đúng bộ cài cũ**; bản mới sẽ từ chối xóa file cũ có checksum khác.

Đã biên dịch và kiểm tra bộ giải/luồng gọi lệnh; chưa kiểm thử trực tiếp AutoCAD, dynamic block và DPI trên Windows. Năm nút mới chọn từng cặp; Select vẫn dùng cho các mẫu MP/RS/VP cũ. Tài liệu bên dưới là lịch sử phiên bản, không dùng số phiên bản cũ để kiểm tra bản mới.

---

# TOOLS CAD HL 0.14.25

- Sửa VP1T+1E45: tê chính bắt buộc trạng thái TOPx45 trước khi tính cổng và chèn đoạn nối. Nếu block thư viện không có TOPx45, báo lỗi và giữ ống gốc. Hai mẫu VP khác giữ trạng thái cũ.
- Ghi chú tuyến mới đặt giữa tim đoạn, căn Middle Center, giữ góc chữ dễ đọc. Dùng chung UPVC, PPR, STEEL, DUCT, CABLE TRAYS và ghi chú OGM. Giữ dấu phân cách ngang và các tùy chọn tiền tố/hậu tố/vật liệu.
- Chữ và phụ kiện đã chèn trước đây không tự đổi khi cập nhật. Với tê cũ, chọn block và đổi Visibility sang TOPx45 như ảnh; kiểm tra lại đoạn nối. Với chữ cũ, chỉnh Justify thành Middle Center rồi đưa Text alignment position về giữa tuyến.

Đóng toàn bộ AutoCAD, thay bundle, mở lại và dùng HLSTATUS kiểm tra LISP/DLL 0.14.25. Trên bản sao DWG, thử VP1T+1E45 size 90x49 như ảnh, hai hướng nhánh; kiểm tra Visibility TOPx45 và đoạn nối. Vẽ mới từng hệ, kiểm tra chữ nằm giữa tuyến ngang/dọc/xiên. Chưa có AutoCAD trong môi trường build nên chưa kiểm chứng hình học và vị trí chữ thực tế trên máy.

# TOOLS CAD HL 0.14.24 — ba mẫu VP

Thêm VP1T+1E90, VP1T+1E45, VP2T sau RS1Y+3E2, trước TÙY CHỌN trên UPVC+. VP.dwg gốc được nhúng trong DLL để lấy trạng thái block; vẫn cần thư viện đầy đủ size TEE-D<size>x<size>, ELB90-D<size>, ELB45-D<size>.

Đóng toàn bộ AutoCAD, sao lưu bundle cũ ra ngoài ApplicationPlugins và thay bundle mới. Mở lại HLSTATUS kiểm tra LISP/DLL 0.14.24.

Chọn mẫu VP, chọn một MLINE chính và MLINE nhánh. Bật Select để quét nhiều nhánh. Click hai điểm định hướng trên ống chính. VP cho phép khác layer; tê chính theo layer chính, phụ kiện nhánh và MLINE nối theo layer nhánh. Size lấy từ từng ống, không scale toàn cụm. MLINE phải thẳng hai đỉnh, Zero, XY Z=0, góc gần vuông trong ±5°. VP2T cần nhánh chạy qua hai phía ống chính. Với VP2T lệch góc, hai đoạn nhánh được căn vuông theo trục qua đầu xa hơn.

Bật Ngắt/cắt để cắt chính tại tê, chỉnh đầu nhánh hoặc tách hai đoạn nhánh VP2T. Nếu tắt, giữ nguyên các ống nguồn và chèn cụm/đoạn nối. Nhánh thiếu block, layer khóa, không đủ chiều dài hoặc không tìm được cổng sẽ bị bỏ qua; F2 xem lỗi. U hoàn tác lượt nối. 12 mẫu cũ vẫn giữ điều kiện layer cũ.

Cần kiểm tra trên bản sao DWG: cả ba mẫu 90x60 như VP.dwg; các cặp size khác thư viện hỗ trợ; quay ống chính và đổi phía nhánh; Select nhiều nhánh; Trim bật/tắt; U và hủy; kiểm tra màu ByLayer và không mất đoạn nhánh. Preview và ghi chú dấu ngang giữ nguyên.

Đã biên dịch và kiểm tra cấu trúc/mô phỏng của các chức năng cũ. Chưa có AutoCAD trong môi trường này: chưa xác nhận trực tiếp ba cụm VP với dynamic block thực tế, không thể cam kết hoàn toàn không lỗi. Thử bản sao DWG trước khi áp dụng bản vẽ chính.

# TOOLS CAD HL 0.14.23 — Preview dùng chung

Ô tick **Preview** nằm ngay dưới **HELP** ở cột bên phải, không nằm trong tab UPVC+. Trạng thái được lưu chung và giữ nguyên khi chuyển tab. Mặc định tắt khi nâng cấp.

## Cài và sử dụng

1. Đóng toàn bộ AutoCAD, sao lưu bundle cũ ra ngoài ApplicationPlugins, thay bằng ToolsCadHL.bundle trong ZIP. Mở AutoCAD 2025; HLSTATUS phải báo LISP/DLL 0.14.23.
2. Nạp thư viện DWG và chọn MLINE style như trước. Bật **Preview** dưới HELP.
3. Chọn UPVC, PPR, STEEL, DUCT hoặc CABLE TRAYS, đặt size rồi nhấn VẼ. Sau điểm đầu, rê chuột: đoạn kế tiếp xuất hiện mờ theo vị trí và kích thước đang chọn.
4. MLINE dùng đúng style và đường kính ngoài (thép quy đổi DN như tuyến thật). Duct/tray dùng bản sao block tuyến động của thư viện, chỉnh Width/Length như đường vẽ thật.
5. Click để chốt điểm; Enter kết thúc; Esc hủy. Size/Back/Center vẫn dùng được. Preview theo cùng quy tắc bắt góc ±5° của tuyến hiện có. Center giữ quy tắc bắt tim riêng như cũ.
6. Đổi size trên bảng trong lúc đang rê: size mới áp dụng từ đoạn kế tiếp; đoạn vừa xem trước giữ size đã hiển thị. Nhập Size không bị ghi đè bởi giá trị cũ không đổi trên bảng.
7. Bỏ tick Preview để dùng cách chọn điểm cũ. Select và 12 mẫu nối UPVC+ giữ nguyên.

Preview hiển thị **đoạn tuyến thẳng kế tiếp**. Phụ kiện/co/tê/gót giày vẫn được dựng và kiểm tra khi hoàn thành tuyến; chưa có xem trước cả cụm phụ kiện UPVC+ hoặc các lệnh bố trí đèn/tủ. Chế độ Polyline có sẵn không cần rê điểm nên không dùng Preview. OGM giữ phần xem trước spline vốn có.

Hình xem trước nằm trong database tạm riêng và bị hủy sau lần chọn điểm; không thêm entity/layer xem trước vào DWG đang vẽ. Lỗi tạo preview sẽ báo và quay về getpoint thường. Nếu lỗi hiển thị lúc rê, điểm đã chọn vẫn được giữ và báo tại dòng lệnh. Độ mờ thực tế phụ thuộc chế độ hiển thị của AutoCAD.

## Kiểm thử trên bản sao DWG

- Mở bảng hẹp, đổi tab: Preview vẫn nằm dưới HELP, tên không bị xén; đóng/mở CAD giữ trạng thái đã lưu.
- Thử UPVC/PPR/STEEL với Standard và style khác, DUCT/tray với các block thư viện; so bề rộng/kích thước hình mờ với đoạn vừa tạo.
- Thử các góc 42/48/87/93 độ, hai hướng UCS quay trong mặt XY, OSNAP, nhập khoảng cách; kiểm tra đoạn cuối đúng vị trí đã chọn.
- Thử Size, Back, Center, Enter và Esc; sau đó REGEN và kiểm tra không có hình mờ/entity/layer thừa, lệnh vẽ tiếp vẫn hoạt động.
- Chạy với Preview tắt, kiểm tra Select UPVC+ và ghi chú dấu ngang vẫn như 0.14.22.

Build .NET 8 đạt; đã kiểm tra logic snap, hợp đồng LISP/native và luồng nhập với mocks. **Chưa chạy AutoCAD 2025** trong môi trường build: chưa xác nhận hình ảnh thực tế, hiệu năng dynamic block và thao tác chuột/OSNAP trên máy của bạn.

# TOOLS CAD HL 0.14.22 — dấu phân cách ghi chú

Nhãn thống kê, tiêu đề thư viện và thông báo hiển thị cũng dùng dấu ngang. Ghi chú tuyến mới dùng dấu ngang ` - ` thay cho dấu đứng ` | ` giữa kích thước, hệ thống và hậu tố. Áp dụng chung UPVC, PPR, STEEL, DUCT, thang máng cáp và ống gió mềm. Ví dụ `UPVC D114 - SP`, hoặc `UPVC D114 - SP - BOT = 3000 FFL` khi bật hậu tố.

Các ghi chú đã có trong DWG là TEXT độc lập, không tự đổi khi cập nhật bộ tools. Có thể dùng FIND của AutoCAD, tìm ` | ` và thay bằng ` - ` trong các ghi chú cần sửa.

Đóng toàn bộ AutoCAD, thay bundle bằng bản này rồi mở lại; HLSTATUS phải báo LISP/DLL 0.14.22. Giữ tính năng Select và 12 mẫu UPVC+ của 0.14.21. Đã kiểm tra tạo chuỗi và biên dịch; chưa chạy trực tiếp AutoCAD.

# TOOLS CAD HL 0.14.21 — Select trên UPVC+

- Ô tick **Select** nằm dưới Size trục đứng, ngay trên nút CHÈN BLOCK TRỤC ĐỨNG; dùng cùng lề với 12 nút mẫu.
- Bỏ tick: tiếp tục chọn từng nhánh như 0.14.20. Bật tick: một mẫu được áp dụng cho nhiều đối tượng trong một lượt.
- Select không thay đổi cách dùng nút CHÈN BLOCK TRỤC ĐỨNG.

## Cách dùng

1. Đóng tất cả AutoCAD. Sao lưu bundle cũ ra ngoài ApplicationPlugins, thay bằng ToolsCadHL.bundle trong ZIP này.
2. Mở AutoCAD 2025; HLSTATUS phải báo LISP và DLL **0.14.21**. HLFLOAT mở bảng, chọn thư viện đầy đủ size.
3. Trong UPVC+, bật **Select**, chọn một trong 12 mẫu MP/RS.
4. Chọn **một MLINE ống chính**. Quét chọn nhiều MLINE nhánh (MP) hoặc Circle/block D<size> trục đứng (RS), rồi Enter.
5. Click điểm tham chiếu trên ống chính, click phía Y cần hướng tới. Hướng dọc ống chính này dùng chung cho cả nhóm; phía trái/phải được xác định theo từng nhánh.
6. Công cụ lấy size riêng của từng đối tượng. Khi cắt ống chính, các nhánh tiếp theo chỉ dùng các đoạn còn lại của đúng ống chính đã chọn.
7. Xem số nối thành công / bỏ qua ở dòng lệnh; F2 xem lý do. Nhánh lỗi không làm mất các nhánh đã nối thành công. U hoàn tác cả lượt.

## Kiểm thử tại AutoCAD trước khi dùng bản vẽ chính

Dùng bản sao DWG: chọn 3 nhánh khác size ở các vị trí đủ xa trên cùng ống chính; quét chọn lẫn ống chính. Thử Trim bật/tắt, một nhánh sai góc hoặc thiếu block nằm giữa nhóm, MP và RS, hai hướng Y, hủy lúc chọn và U sau khi nối. Bỏ tick Select và kiểm tra chọn từng nhánh vẫn như cũ. Nối tại vị trí thiếu chiều dài cho cụm hoặc trùng vùng đã cắt sẽ bị bỏ qua.

Giữ các điều kiện của 0.14.20: MLINE thẳng hai đỉnh, căn tim Zero, WCS XY/Z=0, cùng layer; MP cùng vật liệu, size nhánh không lớn hơn ống chính. MP1Y+1E2 dùng nhánh 45°/135°, các mẫu MP còn lại dùng nhánh 90°, dung sai ±5°. Chọn các nhóm hướng khác nhau thành từng lượt nếu cần.

Đã biên dịch DLL .NET 8 cho AutoCAD 2025 và chạy kiểm tra logic/mô phỏng. Môi trường build **không có AutoCAD**: chưa xác nhận trực tiếp giao diện, dynamic block, native transaction hoặc UNDO trên DWG thực tế.

# TOOLS CAD HL 0.14.20 — đủ 12 nút UPVC+

Bản này bổ sung đủ MP1Y+1E1, MP1Y+1E2, RS1Y+1E1, RS1Y+1E2 theo UPVCPRO.dwg
mới gửi. Không dùng bốn tên mới để gọi lại mẫu cũ: mỗi mẫu có vị trí/trạng thái
tham chiếu riêng, cổng nhánh và phép căn MLINE tương ứng.

## Cài bản gộp
1. Giải nén ZIP. Đóng toàn bộ AutoCAD.
2. Chuyển ToolsCadHL.bundle cũ ra ngoài %APPDATA%\Autodesk\ApplicationPlugins để sao lưu.
3. Chép bundle mới vào ApplicationPlugins. Không cần chạy PowerShell.
4. Mở AutoCAD 2025, HLSTATUS xác nhận LISP và DLL 0.14.20; HLFLOAT mở bảng.
5. Chọn/nạp lại DWG thư viện phụ kiện đầy đủ của bạn. Không cần mở bản vẽ thư viện.

ZIP cũng có ToolsCadHL.lsp ở thư mục gốc. File LISP này nhúng DLL và mẫu DWG,
không phải chỉ một bản vá. Nếu dùng APPLOAD file LISP riêng, cần ngừng AutoLoader/
Startup Suite nạp bản cũ trước khi mở lại AutoCAD. Không nạp hai phiên bản cùng lúc.

## Bốn mẫu mới
- MP1Y+1E1: Y + co theo mẫu, nối MLINE nhánh ngang vuông góc với ống chính.
- MP1Y+1E2: hướng nhánh xiên 45°/135° theo mẫu; dùng trạng thái Y tương ứng trong DWG.
- RS1Y+1E1: cụm nối từ trục đứng tới chính với nhánh ngang.
- RS1Y+1E2: cụm nối từ trục đứng tới chính với nhánh xiên.

Thứ tự menu: sáu nút MP (1E1, 1E2, 2E1, 2E2, 3E1, 3E2), sau đó sáu nút RS cùng thứ tự.
Có thể gõ trực tiếp bốn tên mới nếu tên đó chưa được LISP khác sử dụng; menu luôn
chạy hàm của TOOLS CAD. Không ghi đè lệnh có sẵn của LISP khác.

MP: chọn chính và nhánh MLINE thẳng hai đỉnh. RS: chọn chính và Circle/block D<size>.
Hai click tiếp theo: lấy điểm tham chiếu hướng trên chính, rồi click phía Y hướng tới.
MP1E2 yêu cầu hướng nhánh khớp phía Y đã chọn; nếu không khớp, đổi click hướng.
Các nhánh MP nhận sai số góc ±5° quanh hướng tương ứng; giữ đầu xa, chỉnh đầu nối
về tim cổng. Không dùng đồng thời hai đầu nhánh nằm xa hai phía như một nút cross.

Dùng block đúng size Y-D<chính>x<nhánh> và ELB45-D<nhánh> từ thư viện; MP1E2
không yêu cầu ELB45 nếu mẫu chỉ dùng Y. MLINE nối dùng style và size như 0.14.19.
Thư viện thiếu size hoặc không khớp trạng thái/cổng nối sẽ báo lỗi và hủy giao dịch.
Giữ các sửa lỗi nhánh chạm mép, góc theo chính, chỉnh đầu MLINE tại chỗ, chèn block
trục đứng theo size, cùng các tab và lệnh cũ.

## Kiểm tra trước khi dùng thật
Đã biên dịch và kiểm tra tự động ngoài AutoCAD. Chưa chạy trực tiếp AutoCAD 2025.
Cần thử trên bản sao DWG: cả 12 nút, D140x114 như mẫu, các size khác có trong thư viện,
xoay/mirror hướng chính, hai click Y, Undo/Esc, nhánh đủ dài và trường hợp thiếu block.
Không coi kết quả kiểm tra logic thuần là xác nhận dynamic block/MLINE/GUI đã đúng
trong AutoCAD. Gửi F2 và DWG nhỏ tái hiện nếu một mẫu lỗi.

---
Lịch sử dưới đây áp dụng cho từng phiên bản cũ; các ghi chú “chưa có 4 mẫu” đã hết hiệu lực ở 0.14.20.

# 0.14.19 — góc nối theo ống chính và giữ MLINE nhánh

Đóng toàn bộ AutoCAD, sao lưu bundle cũ ra ngoài ApplicationPlugins, thay bundle
trong ZIP này. Mở lại, HLSTATUS phải báo LISP và DLL 0.14.19.

## Những sửa đổi của bản này
- TỰ ĐỘNG KẾT PHỤ KIỆN: chọn ống chính trước, nhánh sau. Với hệ ống MLINE
  UPVC/PPR/STEEL, nhánh trong ±5° quanh 45°, 90°, 135° (và các hướng đối xứng)
  được chỉnh đúng hướng theo ống chính. Giữ đầu xa của nhánh, tìm lại giao điểm
  trên tim ống chính. Chỉ xử lý đầu nhánh chạm/lấn mép trong bề rộng ống + sai số nối.
- Nhánh lấn qua tim nhưng đầu còn trong bề rộng ống chính không bị coi là cross.
  Giao xuyên thật có hai đầu nhánh cách xa nút vẫn bị từ chối; không tự xóa một phía.
- Khi Trim bật, đoạn MLINE thay thế dùng tọa độ đã chỉnh và cắt theo phụ kiện.
  Khi Trim tắt, nhánh vẫn chỉnh góc nhưng không cắt tại phụ kiện.
- Khi vẽ Pick, bắt góc thêm các hướng 135°/180° và đối xứng. Đây là bắt hướng;
  một góc ngoặt tuyến vẫn cần loại co có trong thư viện (co 45/90), không tự tạo co 135.
- UPVC+: thay vì xóa MLINE nhánh rồi tạo lại, sửa đầu nối trên chính đối tượng đó,
  giữ đầu xa, style và các thuộc tính. Cổng nối phải cùng tim với nhánh đã chuẩn hóa;
  nếu không khớp, hủy giao dịch và giữ bản vẽ trước lệnh.
- 8 mẫu MP/RS hiện có của UPVC+ vẫn là các cụm có cổng ra vuông góc chính.
  MP nhận nhánh 90° ±5°. Nhánh 45°/135° đơn dùng TỰ ĐỘNG KẾT PHỤ KIỆN ở UPVC.
- Hai click chọn hướng Y sau khi chọn ống: click 1 lấy điểm tham chiếu trên chính;
  click 2 chỉ phía Y hướng tới từ điểm đó. Hai điểm chỉ quyết định hướng, cụm vẫn
  căn theo nhánh; không đặt Y tại một điểm tùy ý làm lệch kết nối.

## Kiểm chứng
209 kiểm tra hình học/lấy size mô phỏng đạt, gồm 40/44/46/50°, 85/89/91/95°,
130/134/136/140°, rẽ trái, ngoài dung sai và giao xuyên thật. Các kiểm tra bắt góc,
ghi chú/OGM, domain và kiểm tra đóng gói được chạy lại.
Chưa chạy AutoCAD trong môi trường build. Thử trên bản sao DWG và kiểm tra Undo,
size, visibility, cổng block. Nếu UPVC+ vẫn sai hình, cần DWG tái hiện để xác minh
hình học thư viện. Không khẳng định đã hết mọi lỗi thực tế.

4 mẫu 1Y+1E mới vẫn chưa có trong bản này; giữ 8 mẫu đã phát hành.

---

# 0.14.18 — bắt góc ±5°, UPVC+ và block trục đứng

Đóng toàn bộ AutoCAD, sao lưu bundle cũ ra ngoài ApplicationPlugins rồi thay bằng
ToolsCadHL.bundle trong ZIP. HLSTATUS phải báo LISP/DLL 0.14.18.

- Tab UPVC2 đổi tên thành UPVC+, giữ thông số đã lưu và 8 mẫu nối cũ.
- Size trục đứng + CHÈN BLOCK TRỤC ĐỨNG: chọn D21–D280, lấy block đúng size từ
  thư viện đã chọn. Size 168 nhận D168 hoặc tên cũ 168. Chèn scale 1, layer hiện hành.
- Chọn phía Y: click trên ống chính về phía muốn Y hướng tới, tính từ vị trí nhánh,
  không còn tính theo trung điểm toàn đoạn chính.
- Khi vẽ bằng Pick, từ đoạn thứ hai: 40–50° bắt về 45°, 85–95° bắt về 90°,
  áp dụng hai phía rẽ theo đoạn trước, giữ chiều dài đoạn vừa chọn.
  FREE/BOTH xét cả 45° và 90°; chế độ 45/90 chỉ xét góc tương ứng.
  Hướng đi thẳng trong ±5° cũng được bắt thẳng. Ngoài dung sai không ép góc;
  lệnh vẫn có thể báo góc không hỗ trợ nếu không có phụ kiện phù hợp.
- Lựa chọn Center giữ điểm tim đã chọn; không di chuyển điểm này bằng bắt góc.
- Phụ kiện dùng tọa độ MLINE đã chỉnh nên được chọn theo góc chuẩn.
  Không tự sửa MLINE cũ đã vẽ lệch góc. Tự động kết phụ kiện cho ống cũ vẫn
  yêu cầu góc chuẩn; nhánh chạm mép ống chính đã được xét bằng bề rộng ống và sai số nối.

Chưa tích hợp 4 mẫu MP1Y+1E1, MP1Y+1E2, RS1Y+1E1, RS1Y+1E2.
Chưa kiểm thử trực tiếp trên AutoCAD. Thử trên bản sao DWG, đặc biệt UPVC+.
604 kiểm tra bắt góc đạt; các kiểm tra ngoài AutoCAD không thay thế kiểm chứng
block động, chèn/cắt tuyến, Undo và giao diện thực tế.

---

# TOOLS CAD HL 0.14.17 — bản gộp cho AutoCAD 2025

Đã gộp các chức năng của 0.14.16 với tab UPVC2 gồm 8 nút MP1Y+2E1, MP1Y+2E2,
MP1Y+3E1, MP1Y+3E2, RS1Y+2E1, RS1Y+2E2, RS1Y+3E1, RS1Y+3E2.
UPVC cũ giữ nguyên chức năng; UPVC2 lưu thông số riêng và dùng chung thư viện.

**UPVC2 là phần mới cần kiểm thử trên bản sao DWG.** Đã biên dịch và kiểm tra logic
ngoài AutoCAD; chưa chạy thực tế 8 mẫu trong AutoCAD. Không coi các kiểm tra tự động
là xác nhận hình học dynamic block, visibility, cổng nối, Undo hoặc giao diện đã đúng.

## Cập nhật dễ nhất

1. Giải nén ZIP ra thư mục riêng, không chạy trực tiếp trong ZIP.
2. Đóng toàn bộ AutoCAD. DLL cũ không thể thay khi CAD còn mở.
3. Mở `%APPDATA%\Autodesk\ApplicationPlugins` trong File Explorer.
4. Chuyển thư mục `ToolsCadHL.bundle` cũ ra một thư mục sao lưu **ngoài ApplicationPlugins**.
   Giữ nguyên DWG thư viện riêng của bạn. Không để hai bản bundle cùng được AutoLoader nạp.
5. Chép nguyên thư mục `ToolsCadHL.bundle` trong ZIP mới vào ApplicationPlugins.
   Cách chép thư mục này không cần chạy PowerShell.
6. Mở AutoCAD 2025, mở bản sao DWG để thử. Gõ `HLSTATUS`: LISP và DLL phải cùng 0.14.17.
7. Gõ `HLFLOAT` mở bảng nổi hoặc `HLDOCK` ghim bảng. Nếu Startup Suite còn tự nạp
   ToolsCadHL cũ ở đường dẫn khác, bỏ mục cũ rồi đóng/mở lại AutoCAD.

Cài mới cũng có thể dùng Install.cmd khi chính sách máy cho phép PowerShell.
Nếu báo scripts disabled, dùng cách chép bundle trên; không cần đổi chính sách máy.

## Dùng UPVC2

1. Chọn tab UPVC2, chọn vật liệu đúng với ống. Bấm CHỌN / NẠP LẠI THƯ VIỆN DWG,
   chọn thư viện UPVC đầy đủ đang dùng cho tab UPVC.
   File UPVCPRO được nhúng vào DLL để lấy mẫu bố trí/trạng thái, **không thay thế thư viện đủ size**.
2. Chọn một trong 8 nút. MP: chọn MLINE chính và MLINE nhánh vuông góc.
   RS: chọn MLINE chính, rồi Circle đường kính đúng size hoặc block D<size> scale 1
   của trục đứng (size 168 cũng nhận tên block 168).
3. Chỉ phía hướng chảy trên ống chính, ở phía tương ứng so với trung điểm đoạn chính.
   Hai đối tượng phải cùng layer, trong Model Space. MLINE phải thẳng hai đỉnh,
   canh tim Zero, style có biên ngoài đối xứng; hình học WCS XY, Z=0.
4. Size lấy từ bề rộng thực của MLINE / ký hiệu trục đứng. Nhánh không lớn hơn ống chính.
   Tools dùng block `Y-D<chính>x<nhánh>` và `ELB45-D<nhánh>` từ thư viện,
   không phóng toàn cụm mẫu D114 thành size khác.
5. MLINE nối giữa phụ kiện dùng style của MLINE nhánh; RS dùng style ống chính với
   bề rộng theo size trục đứng. Đối tượng mới dùng ByLayer; màu cố định bên trong
   block/style vẫn tuân theo định nghĩa thư viện.
6. Bật Ngắt / cắt ống để thay đoạn chính/nhánh tại cổng phụ kiện. Nếu tắt, giữ ống gốc,
   nên có thể thấy ống gốc đi xuyên cụm. U hoàn tác cả thao tác.
7. Thiếu block, không khớp trạng thái hoặc không xác định được cổng nối: lệnh báo lỗi
   và không hoàn tất cụm. Xem F2 và giữ log để kiểm tra thư viện.

## Kiểm tra trước khi dùng bản vẽ thật

- Trong DWG mới: nạp thư viện, thử UPVC cũ hai lần liên tiếp, thử hủy bằng Esc.
- Thử từng nút UPVC2 với chính D140, nhánh D114 như mẫu, rồi thử các size khác mà
  thư viện thực sự có. Kiểm tra hướng Y/co, đầu MLINE, khoảng ngậm và đường kính.
- Thử nhánh hai phía, ống chính nằm ngang/dọc/xoay 45°, cả MP và RS; kiểm tra U/Redo.
- Thử thiếu block, ống quá ngắn, chọn sai đối tượng, layer khóa: ống gốc phải được giữ.
- Kiểm tra lại UPVC/PPR/STEEL/DUCT, OGM S1/S2/R1/R2, ghi chú và các tab cũ.
- Nếu báo không xác định được cổng nối: chưa thể khẳng định thư viện đó tương thích
  với thuật toán UPVC2. Gửi ảnh, F2 và DWG nhỏ có ống và block liên quan.

## Quay lại / gỡ

Đóng AutoCAD, chuyển bundle 0.14.17 ra ngoài ApplicationPlugins; chép bundle sao lưu
về vị trí cũ. Không xóa DWG thư viện. Để gỡ hoàn toàn, bỏ bundle và mục Startup Suite
trỏ tới TOOLS CAD. Thông số cá nhân trong `%APPDATA%\ToolsCadHL\2025` được giữ lại.

---
Lịch sử các bản trước (số phiên bản/đếm kiểm tra bên dưới chỉ áp dụng cho bản tương ứng):

# 0.14.16 — Standard mặc định, nạp MLINE style từ thư viện

Đóng AutoCAD, thay ToolsCadHL.bundle trong %APPDATA%\Autodesk\ApplicationPlugins; mở lại và kiểm tra HLSTATUS báo LISP/DLL 0.14.16.
Khi tạo bảng menu trong phiên mới, các tab pipe bắt đầu bằng Standard. Sau đó:
1. CHỌN / NẠP LẠI THƯ VIỆN DWG: chọn file chứa MLINE styles (file có style nhưng không có block cũng được).
2. Nạp style: đọc danh sách từ DWG và nhập các style chưa có vào bản vẽ hiện hành.
3. Chọn style trong danh sách rồi vẽ. Standard luôn có trong danh sách. Chỉ mở dropdown không đọc cơ sở dữ liệu.
Style trùng tên giữ nguyên định nghĩa trong bản vẽ, không ghi đè để tránh thay đổi ống đã vẽ. Nếu đã sửa style trong thư viện, đặt tên mới hoặc thử bản vẽ trống.
Sang bản vẽ khác cần Nạp style vào bản vẽ đó trước khi dùng style thư viện. Sau khi khởi động lại AutoCAD, chọn lại thư viện trước khi Nạp style. Style dùng để vẽ phải có hai biên ngoài đối xứng qua tim; công cụ báo lỗi nếu không phù hợp.
Đã biên dịch và kiểm tra tĩnh; chưa kiểm chứng import MLINE style trực tiếp trong AutoCAD 2025.

# 0.14.15 — thu gọn DUCT và chuyển ô tích ghi chú

Đóng toàn bộ AutoCAD, thay ToolsCadHL.bundle trong %APPDATA%\Autodesk\ApplicationPlugins. Mở lại, HLSTATUS xác nhận LISP/DLL 0.14.15.
Ba ô Thêm tiền tố/Thêm hậu tố/Thêm vật liệu chuyển xuống cuối mỗi tab MEP có ghi chú tuyến. Giá trị và chức năng giữ nguyên.
DUCT dùng hai hàng tự tính chiều cao, bỏ bảng/flow lồng gây vùng trống. Các nút vuông S1/S2/R1/R2 dùng chữ nhỏ và không có padding để hiện cả số. Chỉ DUCT có các nút này.
Kiểm tra kéo hẹp/rộng bảng và các mức DPI Windows. Chưa chạy trực tiếp AutoCAD trong môi trường build.

# 0.14.14 — tích hợp OGM và tùy chọn ghi chú

## Cập nhật
Đóng toàn bộ AutoCAD, thay ToolsCadHL.bundle trong %APPDATA%\Autodesk\ApplicationPlugins bằng bundle mới. Mở AutoCAD 2025, HLSTATUS phải báo LISP/DLL 0.14.14; HLFLOAT mở bảng.

## Thay đổi
- Thứ tự: UPVC, PPR, STEEL, DUCT, LIGHTING, ELECTRICAL PANELS, CABLE TRAYS, các tab còn lại. Thông số riêng từng hệ vẫn giữ; ánh xạ lại tab đã chọn từ phiên bản cũ.
- Chỉ DUCT có 4 nút vuông: S1/S2 hàng trên, R1/R2 hàng dưới, cạnh lựa chọn nguồn và ghi chú.
- Bấm nút, nhập đường kính ống mềm (Enter dùng giá trị OGM gần nhất). Bỏ tích Polyline có sẵn để vẽ SPLINE với xem trước. Tích ô này để chọn đường dẫn mở có sẵn; đường nguồn bị xóa sau khi thành công, theo hành vi OGM gốc. UNDO để hoàn tác.
- Lệnh S3/R3 dùng dòng lệnh. Khi trùng tên LISP khác, dùng HLOGM_S1/S2/S3 hoặc HLOGM_R1/R2/R3. Không ghi đè S1..R3 đã tồn tại. HLOGM mở menu sáu kiểu; HLOGMINFO kiểm tra module.
- Ghi chú tuyến điều khiển có/không tạo ghi chú. Ba ô Thêm tiền tố, Thêm hậu tố, Thêm vật liệu điều khiển độc lập; vật liệu nằm ngay dưới trường hậu tố. Bỏ tích không xóa giá trị nhập. Tắt hậu tố cũng tắt nội dung BOP/BOT dự phòng. Kích thước và hệ thống vẫn hiện.
- OGM dùng layer hiện hành, màu ByLayer, ghi chú vật liệu ONG GIO MEM; không tự nối/chèn phụ kiện vào tuyến cứng.

## Kiểm tra trên AutoCAD trước khi dùng bản vẽ thật
1. Dùng bản vẽ thử, đổi từng tab và kéo rộng/hẹp bảng; kiểm tra nút vuông chỉ ở DUCT, ô lựa chọn không bị che.
2. Thử S1/S2/R1/R2: nhập đường kính, vẽ đường cong thoải. Enter hoàn tất SPLINE và chấp nhận tiếp tuyến. Kiểm tra đường kính, layer, hình đầu ống; UNDO.
3. Thử Select trên LINE/ARC/SPLINE mở; thử đường gấp quá nhỏ và Esc giữa chừng. Kiểm tra đường nguồn được giữ khi lỗi/hủy, snap và DRAGMODE phục hồi; nút menu dùng lại được.
4. Gọi S3/R3 hoặc HLOGM_S3/HLOGM_R3; kiểm tra không xung đột bản OGM độc lập.
5. Thử bật/tắt từng mục tiền tố/hậu tố/vật liệu với ống cứng và mềm, lưu thông số rồi mở lại.
6. Thử lại vẽ và đặt phụ kiện các hệ; các quy tắc hình học cũ không được sửa trong bản này.

Đã biên dịch .NET; 321 kiểm tra dữ liệu, 226 kiểm tra hình học OGM/nội dung ghi chú và 67 kiểm tra hình học nút nối/lấy kích thước mô phỏng đã qua. Kiểm tra tĩnh LISP và ZIP đã qua. Chưa có AutoCAD trong môi trường này, chưa xác nhận chạy native SPLINE/COM, DPI, Undo/Esc và các dynamic block thực tế.

# 0.14.13 — hiện đủ ô đảo hướng và các lựa chọn dài

Đóng toàn bộ AutoCAD, thay ToolsCadHL.bundle trong %APPDATA%\Autodesk\ApplicationPlugins bằng bundle mới. Mở lại và kiểm tra HLSTATUS báo LISP/DLL 0.14.13.
Các nhóm GHI CHÚ và ĐẶT PHỤ KIỆN dùng chung bảng bố cục chính, bỏ bảng lồng gây cắt hàng cuối. Các checkbox tự đo chiều cao theo chiều rộng và DPI để xuống dòng đầy đủ, gồm đảo hướng/mirror, tự nối, ngắt tuyến và xóa polyline.
Kiểm tra bằng cách kéo hẹp/rộng bảng và cuộn qua các nhóm trên các tab. Chưa kiểm thử trực tiếp trên AutoCAD; chức năng vẽ không thay đổi.

# 0.14.12 — nút phụ kiện cùng kích thước với nút thống kê

Đóng toàn bộ AutoCAD, thay ToolsCadHL.bundle trong %APPDATA%\Autodesk\ApplicationPlugins bằng bundle mới. Mở lại và kiểm tra HLSTATUS báo LISP/DLL 0.14.12.
ĐẶT PHỤ KIỆN và SỬA THUỘC TÍNH nằm trực tiếp trong bảng chính, cùng chiều rộng/chiều cao với TẠO HƯỚNG CHẢY và THỐNG KÊ. Hai nút không còn nằm trong vùng nhóm phụ kiện gây che hàng cuối.
Không thay đổi chức năng vẽ hoặc đặt phụ kiện. Chưa kiểm thử trực tiếp giao diện trên AutoCAD.

# 0.14.11 — thu gọn nút phụ kiện

Đóng toàn bộ AutoCAD, thay ToolsCadHL.bundle trong %APPDATA%\Autodesk\ApplicationPlugins bằng bundle mới. Mở lại và kiểm tra HLSTATUS báo LISP/DLL 0.14.11.
Các nút hành động dùng cùng chiều cao 33 đơn vị giao diện (Windows tự scale theo DPI), không giãn dọc theo nhóm chứa. Nút SỬA THUỘC TÍNH PHỤ KIỆN rút gọn nhãn thành SỬA THUỘC TÍNH; lệnh vẫn là TCBEDIT.
Chưa kiểm thử hiển thị trực tiếp trong AutoCAD. Chức năng vẽ/phụ kiện giữ nguyên 0.14.10.

# 0.14.10 — kích thước phụ kiện và bố cục

Đóng toàn bộ AutoCAD, thay ToolsCadHL.bundle trong %APPDATA%\Autodesk\ApplicationPlugins; mở lại và kiểm tra HLSTATUS báo LISP/DLL 0.14.10.

ĐẶT PHỤ KIỆN: chọn loại trong bảng rồi bấm đặt. Chọn ống chính để lấy vật liệu, D/DN hoặc W/H thực tế. Với tê/Y/gót giày/côn/cross, chọn thêm nhánh/đầu thứ hai; Enter tại bước này dùng cùng kích thước ống chính. Sau đó chọn điểm đặt và góc. Với côn giảm chọn đầu lớn làm ống chính. Enter ngay bước chọn ống chính giữ cách nhập tay cũ. Các cặp co lên/xuống vẫn có bước chọn MLINE riêng.
Layer phụ kiện vẫn theo layer hiện hành của CAD. Chức năng này lấy kích thước, không tự suy đoán hướng đặt trong chế độ thủ công.
Tự nối tiếp tục đọc kích thước từ các đoạn được nối. Thêm kiểm tra kích thước rộng sau khi đặt Height, hỗ trợ tên thông số Width và ưu tiên Height thực của block hơn metadata cũ.
GHI CHÚ dùng bố cục tự đo trực tiếp để tránh cắt ô Cao chữ. Nút Nạp style thu gọn.

67 kiểm tra hình học/lấy kích thước với các hàm CAD mô phỏng đã qua. Chưa kiểm chứng dynamic block, visibility, cổng nối và DPI thực tế trên AutoCAD. Nếu block vẫn sai hình, gửi DWG mẫu và kết quả TCINSPECT của block đó.

# 0.14.9 — bố cục menu gọn hơn

Đóng toàn bộ AutoCAD rồi thay ToolsCadHL.bundle trong %APPDATA%\Autodesk\ApplicationPlugins bằng bundle mới. Mở lại, dùng HLSTATUS xác nhận LISP/DLL 0.14.9, HLFLOAT mở bảng.
Tiêu đề chỉ còn TOOLS CAD HL; số phiên bản xem bằng HLSTATUS.
Hướng dẫn dài được chuyển xuống cuối tab. Ô MLINE style dùng hết chiều rộng, nút nạp đặt bên dưới. Ô số dành đủ chiều cao và danh sách xổ tự mở rộng theo nội dung.
Giữ màu nâu nhạt, tab tiếng Anh và cơ chế vẽ/phụ kiện của 0.14.8.
Cần kiểm tra trực tiếp giao diện ở mức DPI Windows đang dùng; chưa chạy AutoCAD trong môi trường build.

# 0.14.8 — kết nối nhánh tại mép tuyến chính

Đóng toàn bộ AutoCAD, thay nguyên ToolsCadHL.bundle trong %APPDATA%\Autodesk\ApplicationPlugins, mở lại và dùng HLSTATUS xác nhận LISP/DLL 0.14.8.

1. Chọn/nạp lại thư viện DWG chứa đúng block phụ kiện.
2. Chọn layer hiện hành giống tuyến chính, đúng hệ và vật liệu.
3. Bật “Tự nối vào tuyến cùng layer”. Nếu tắt, tools chỉ tạo co ở các góc của tuyến mới, không tự chèn tê/chạc vào tuyến cũ.
4. Vẽ nhánh kết thúc tại tim hoặc mép ngoài tuyến chính. Nhánh vuông góc dùng tê/gót giày; nhánh 45 độ dùng Y nếu thư viện có tổ hợp được hỗ trợ. Thang máng và ống gió tròn chưa hỗ trợ nhánh Y tự động.
5. Với tuyến đã vẽ: dùng “TỰ ĐỘNG KẾT PHỤ KIỆN”, chọn đoạn chính rồi đoạn nhánh. Không cần vẽ lại.
6. Nếu chưa tạo phụ kiện, xem cảnh báo dưới bảng và nhấn F2 để đọc lỗi. TCINIT kiểm tra thư viện; gửi log cùng DWG mẫu nếu lỗi vẫn còn.

Đã kiểm tra 42 trường hợp lập kế hoạch nút nối bằng trình thông dịch VeLisp (có bộ tương thích RTOS/EQUAL), biên dịch .NET và kiểm tra tĩnh. Chưa kiểm chứng chèn block/dynamic properties/cắt tuyến trong AutoCAD.
Không tự sửa hình học tuyến cũ hoặc bật lại lựa chọn tự nối đã lưu.

# 0.14.7 — menu nền nâu nhạt, tên tab tiếng Anh

Đóng toàn bộ AutoCAD trước khi thay bundle; DLL đã nạp không thể cập nhật trong phiên đang mở.
Thay thư mục ToolsCadHL.bundle trong %APPDATA%\Autodesk\ApplicationPlugins bằng bundle trong ZIP mới, rồi mở lại AutoCAD 2025.
Gõ HLSTATUS để xác nhận LISP và DLL 0.14.7; HLFLOAT để mở bảng.
Tên tab bên phải dùng tiếng Anh; các thông số và khóa lưu cấu hình giữ nguyên.
Chọn layer hiện hành trên thanh Layer của AutoCAD trước khi nhấn vẽ; không nhập tên layer trong tools.
Bản này giữ thay đổi CLAYER của 0.14.6. Chưa kiểm thử giao diện trực tiếp trong AutoCAD.

# 0.14.6 — dùng layer hiện hành của AutoCAD

Đóng AutoCAD, thay nguyên bundle mới và mở lại. HLSTATUS phải báo 0.14.6.
Không còn ô nhập/xổ layer trong tools và không cần nút Nạp layer.

1. Trên thanh Layer mặc định của AutoCAD, chọn layer hiện hành muốn vẽ.
   Nếu đang chọn đối tượng, nhấn Esc trước để tránh chỉ đổi layer đối tượng đó.
2. Bấm VẼ trong tools. Công cụ lấy CLAYER tại thời điểm bắt đầu lệnh.
3. Đổi layer trên thanh CAD trước khi bắt đầu tuyến tiếp theo nếu cần.
Layer đã lấy được giữ cho toàn bộ một lệnh; không đổi giữa các đoạn đang vẽ.
Đối tượng mới dùng ByLayer. Màu cố định bên trong block/MLINE style có thể
vẫn được ưu tiên; không tự thay định nghĩa dùng chung làm đổi đối tượng cũ.
Các lệnh chỉnh sửa/sao chép đối tượng cũ vẫn giữ ngữ nghĩa vốn có của chúng.

Bỏ đường đọc layer từ UI dropdown gây crash được báo ở 0.14.4.
Không cần cập nhật riêng 0.14.5; dùng trực tiếp gói này. Chưa chạy GUI AutoCAD.

---
Các hướng dẫn layer của bản cũ bên dưới không áp dụng cho 0.14.6.

# 0.14.5 — bản sửa sau báo cáo AutoCAD đóng khi xổ Layer

Ngừng dùng 0.14.4. Đóng AutoCAD, thay nguyên bundle mới và mở lại.
HLSTATUS phải báo LSP/DLL 0.14.5. Không chỉ APPLOAD đè vì DLL cũ vẫn trong RAM.

Cách dùng Layer: khi CAD không chạy lệnh, bấm NẠP LAYER, sau đó xổ chọn tên.
Sau khi đổi bản vẽ hoặc thêm layer, bấm NẠP LAYER lại. Vẫn gõ tên trực tiếp được.
MLINE style tương tự: bấm NẠP STYLE rồi xổ chọn.
Bản sửa không truy cập Database/đổi Items trong sự kiện DropDown, không dùng
Shell AutoComplete; việc đọc dùng document lock, chỉ theo nút nạp riêng.

Chưa tái hiện crash trong AutoCAD nên chưa khẳng định loại bỏ mọi nguyên nhân.
Thử trên bản vẽ NEW trước: nạp, xổ nhiều lần, vẽ, đổi bản vẽ, nạp lại.
Nếu vẫn văng, gửi thông báo Fatal Error/CER và DWG tối giản. Không lặp thử
trên bản vẽ chưa lưu. Có thể quay về 0.14.3 dùng ô nhập tên layer.

---
Tài liệu cũ bên dưới để tham khảo; cách nạp layer hiện tại theo phần trên.

# 0.14.4 — xổ chọn layer bản vẽ

Đóng AutoCAD và thay nguyên bundle mới. HLSTATUS phải báo LSP/DLL 0.14.4.
Ở mỗi tab, bấm mũi tên ô Layer để chọn layer của bản vẽ đang mở.
Danh sách cập nhật mỗi lần mở, kể cả sau khi tạo layer/đổi bản vẽ.
Có thể gõ tên mới như trước; layer Xref không nằm trong danh sách chọn.
Layer khóa/tắt/đóng băng vẫn được liệt kê nhưng lệnh vẽ sẽ báo yêu cầu mở layer.

Các đối tượng mới qua bộ tạo hình tools dùng Color=ByLayer (ACI 256).
Màu layer đã tồn tại được giữ nguyên. Với block có màu cố định ở nét bên
trong, hoặc MLINE style có màu từng nét riêng, màu nội bộ có thể ưu tiên
hơn ByLayer của đối tượng ngoài. Muốn toàn bộ nét theo layer: chuẩn hóa
block thư viện về layer 0/ByBlock và màu nét MLINE style về ByLayer.
Tools không tự đổi ruột block/style dùng chung vì có thể đổi đối tượng cũ.

Thử: chọn layer đỏ, vẽ một tuyến; chuyển layer xanh, vẽ tuyến khác;
đổi màu layer đỏ bằng LA, tuyến đầu phải cập nhật màu nếu không có override.
Chưa kiểm thử trực tiếp trên AutoCAD; kiểm tra Properties và gửi DWG nếu
block/style vẫn có màu cố định. Bản này chỉ sửa lựa chọn layer, không đổi
thuật toán phụ kiện.

---
# TOOLS-CAD 0.14.3 — AutoCAD 2025

## Cập nhật
Đóng toàn bộ AutoCAD. Sao lưu bundle cũ ra ngoài ApplicationPlugins rồi
chép nguyên ToolsCadHL.bundle mới vào. HLSTATUS phải báo LSP/DLL 0.14.3.
Nếu DLL vẫn trỏ bản cũ, HLLOAD chọn DLL trong Contents của bundle mới.
PowerShell bị chặn: chỉ chép bundle thủ công, không cần chạy Install.cmd.

## Bản vẽ mới và thư viện tên bất kỳ
1. Mở bản vẽ cần làm việc, không cần mở DWG thư viện.
2. APPLOAD ToolsCadHL.lsp nếu chưa tự nạp; HLFLOAT mở bảng.
3. Bấm CHỌN / NẠP LẠI THƯ VIỆN DWG. Chọn file .dwg có tên bất kỳ.
4. Tools kiểm tra đọc được danh sách block rồi mới lưu đường dẫn.
5. TCINIT in danh sách block ống gió còn thiếu; xem F2.
6. Vẽ tuyến/chèn phụ kiện: block thiếu trong bản vẽ được sao chép trực tiếp
   từ thư viện bằng API AutoCAD .NET, không cần mở bản vẽ thư viện.

Có thể đổi tên FILE DWG nhưng không tùy ý đổi tên block hoặc tham số dynamic
mà tools đang sử dụng. Block cùng tên đã có trong bản vẽ được giữ nguyên;
chọn thư viện khác không tự ghi đè định nghĩa cũ. Thử trong NEW để phân biệt.
Ví dụ tê chữ nhật dùng Chac 3, gót giày dùng Chac chu T cong, có hậu tố
cach nhiet/tieu am theo vật liệu. Chân rẽ trong danh sách phụ kiện thủ công
cần block Chan re hoặc Chan re vuong tron tương ứng. Thiếu block sẽ báo tên.

## Vẽ và giao diện
HLFLOAT: nổi; HLDOCK: ghim; HLTOOLS: hiện; HLSTATUS: phiên bản/đường dẫn DLL.
Chọn MLINE style trong tab pipe. Style cần hai nét ngoài đối xứng offset 0;
muốn có nét tim, dùng style có nét offset 0. TC_MC tạo được trong bản vẽ mới;
style khác cần nhập bằng MLSTYLE. Chọn DWG không tự nhập mọi MLINE style.
Góc FREE/45/90/BOTH tính theo đoạn trước. Khi Pick, hướng hiệu chỉnh sau khi
chọn điểm; đoạn đầu tự do. Center tại điểm tiếp theo cho phép chọn tim MLINE.
TCDCL là hộp thoại dự phòng. Thư viện hiện dùng DLL mới để đọc/nhập block.

## Kiểm thử và lỗi
Dùng bản sao DWG: vẽ lần một/lần hai, Enter/Esc, đổi bản vẽ, dock/float.
Thử TCFIT với co/tê/chạc/gót giày và kiểm tra kích thước main/nhánh.
TCINIT giúp tìm tên block thiếu; TCINSPECT xem tham số của block thực tế.
Chưa chạy AutoCAD trong môi trường phát triển. Chưa thể xác nhận mọi phụ kiện
đúng hình học nếu chưa có DWG mẫu và thư viện. Gửi F2 và hai DWG nếu còn lỗi.
Giữ SECURELOAD bật; chỉ thêm Contents của plugin vào Trusted Locations nếu
AutoCAD yêu cầu và chính sách máy cho phép.

## Gỡ cài
Đóng AutoCAD; Uninstall.cmd từ đúng gói hoặc sao lưu rồi bỏ bundle thủ công.
Bỏ Startup Suite/Trusted Location đã tự thêm. Giữ lại DWG và cấu hình cá nhân.
