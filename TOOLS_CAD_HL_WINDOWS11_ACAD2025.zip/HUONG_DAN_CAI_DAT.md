# Bản 0.14 — tab đầy đủ, nối mép ống, góc vẽ và tim MLINE

Đóng AutoCAD, sao lưu và chuyển bundle cũ ra ngoài ApplicationPlugins,
chép nguyên ToolsCadHL.bundle mới vào. Không nạp chồng DLL cũ trong phiên CAD.
HLSTATUS phải báo LSP và DLL 0.14.0. Nếu đường dẫn DLL trỏ bản cũ, HLLOAD
chọn DLL mới trong Contents. Dùng cài thủ công nếu PowerShell bị chặn.

- Tên tab hiển thị ngang, chiều rộng theo tên đầy đủ; bảng tối thiểu rộng hơn.
- Góc theo đoạn trước: FREE tự do, 45, 90, BOTH cho cả hai; vẫn đi thẳng.
  Đoạn đầu xác định hướng. Góc được hiệu chỉnh sau khi chọn điểm, không phải
  đường tracking native và không đổi OSMODE. Chế độ này áp dụng khi Pick,
  không tự sửa các polyline có sẵn.
- Khi chọn điểm tiếp theo lúc vẽ pipe: gõ Center, Enter, chọn MLINE gần điểm
  muốn nối. Lấy hình chiếu điểm chọn lên tim MLINE; ưu tiên tim chính xác,
  không ép góc ở điểm Center. Chỉ hỗ trợ MLINE 2 đỉnh, Justification Zero,
  cùng hệ pipe. Điểm đầu vẫn chọn như trước.
- Nhánh ống gió chữ nhật bắt mép: thêm nửa bề rộng main vào khoảng tiếp cận
  cho nút vuông góc nằm giữa main. Giữ kiểm tra sai số, vật liệu và nút có
  phụ kiện; không thay phụ kiện có sẵn tự động. Kết thúc tuyến bằng Enter.
- Không tự nối được gần tuyến: hiển thị cảnh báo thay vì chỉ báo hoàn tất.

Chưa kiểm thử hình học DWG, GUI và thao tác bắt tim trong AutoCAD thực tế.
Nếu vẫn không ra phụ kiện, gửi F2 và DWG mẫu kèm thư viện block để tái hiện.

---
Tài liệu phiên bản trước bên dưới dùng để tham khảo; phiên bản hiện tại là 0.14.

# Bản vá LISP 0.13.1 — lỗi bad function TC_PALETTE_VERSION_013

Nếu đã cài bản 0.13.0:
1. Đóng tất cả AutoCAD và giải nén ZIP mới vào thư mục mới.
2. Win+R -> %APPDATA%\Autodesk\ApplicationPlugins
3. Chuyển thư mục ToolsCadHL.bundle cũ ra ngoài ApplicationPlugins để sao lưu.
4. Chép nguyên ToolsCadHL.bundle của ZIP mới vào ApplicationPlugins.
   Không chạy script trong thư mục installer; không cần PowerShell.
5. Mở AutoCAD 2025 và bản vẽ, gõ HLSTATUS: LSP phải là 0.13.1.
   Trước khi mở bảng, DLL CHUA NAP là trạng thái bình thường.
6. Gõ HLFLOAT. Nếu DLL không tự nạp, dùng NETLOAD của AutoCAD chọn
   ToolsCadHL.bundle\Contents\ToolsCadPalette.dll, rồi thử HLFLOAT.
   DLL vẫn là 0.13.0 vì bản vá chỉ sửa LISP.
7. Nếu còn lỗi, gửi F2 từ NETLOAD đến HLFLOAT; kiểm tra Startup Suite không
   trỏ đến LSP cũ ở thư mục tải xuống khác. Không tắt SECURELOAD.

Bản vá sửa cách gọi 9 hàm .NET trong catch-all: dùng lambda chứa lời gọi
trực tiếp để hàm chưa đăng ký không bị resolve bên ngoài vùng bắt lỗi.
Chưa kiểm thử bản vá trong AutoCAD thực tế.

---

# TOOLS-CAD / Tools Cad HL 0.13 — Windows 11, AutoCAD 2025

## Đọc trước khi cài

Bản tiếp tục từ nhánh deliver/tools-cad-duy-autocad2025, commit 06150a9.
Đã biên dịch DLL x64 cho .NET 8 và API AutoCAD 2025 (R25.0, NuGet 25.0.1).
Chưa được nghiệm thu trực tiếp trên AutoCAD: xem BAO_CAO_KIEM_TRA.md.
Yêu cầu AutoCAD 2025 Windows **bản đầy đủ**; không dùng bản LT hoặc Mac.

Các chức năng MEP/block phụ thuộc **template CAd Duy.dwg** của bạn. Kho mã
không có DWG này; ZIP không thể cung cấp thay. Chọn đúng thư viện bằng
TCTEMPLATE. Thiếu thư viện/block thì chức năng liên quan sẽ báo lỗi;
không tự tạo block giả hoặc thay thư viện. Công cụ làm việc Model/WCS XY/Z=0,
mặc định đơn vị mm. Luôn thử trên bản sao DWG trước khi dùng cho công việc.

## Nâng từ bản AutoCAD 2024

DLL 2024 (.NET Framework 4.8) không dùng thay DLL 2025 (.NET 8).
Nếu đã cài bản 2024, đóng AutoCAD, gỡ bằng Uninstall.cmd trong gói 2024 trước,
sau đó cài gói này. Không dùng bộ gỡ 2025 để xóa bản 2024 vì checksum khác.
Giữ lại DWG thư viện; cấu hình bản 2025 nằm trong thư mục riêng 2025.

## Cài đặt tự động cho tài khoản Windows hiện tại

1. Đóng tất cả cửa sổ AutoCAD. Lưu bản vẽ trước khi đóng.
2. Giải nén toàn bộ ZIP vào một thư mục riêng, ví dụ D:\TOOLS-CAD-0.13.
   Không chạy trực tiếp trong cửa sổ ZIP. Không đổi vị trí từng file riêng lẻ.
3. Nhấp đúp Install.cmd. Không cần quyền Administrator. Installer kiểm tra
   SHA-256 và chép ToolsCadHL.bundle vào:
   `%APPDATA%\Autodesk\ApplicationPlugins\ToolsCadHL.bundle`.
   Thư mục đã tồn tại: installer dừng, không ghi đè. Gỡ bản cũ bằng bộ gỡ
   tương ứng rồi cài mới; sao lưu mọi sửa đổi cá nhân trước.
4. Nếu PowerShell bị chính sách máy chặn, không tắt chính sách toàn hệ thống.
   Nếu tổ chức cho phép, kiểm tra nội dung script, dùng Unblock-File cho
   Install.ps1/Uninstall.ps1, rồi chạy lại. Hoặc cài thủ công theo mục dưới.
5. Mở AutoCAD 2025. AutoLoader nạp LISP theo bản vẽ qua PackageContents.xml.
   Gõ HLFLOAT để mở bảng nổi; HLDOCK để ghim phải; HLTOOLS để mở lại bảng.
6. Nếu AutoCAD báo file không tin cậy, chỉ thêm thư mục Contents của plugin
   này vào OPTIONS > Files > Trusted Locations theo chính sách của máy.
   Giữ SECURELOAD bật. DLL chưa có chữ ký số; xác minh nguồn ZIP trước khi
   chấp nhận thông báo bảo mật. Không thêm ổ đĩa/thư mục tải xuống chung.
7. HLSTATUS phải báo DLL 0.13.0. Nếu biến TOOLS_CAD_HL_DLL còn trỏ bản cũ,
   dùng HLLOAD chọn DLL trong thư mục Contents vừa cài. Nếu đã nạp DLL cũ
   vào tiến trình thì đóng/mở AutoCAD trước khi chọn DLL mới.
8. TCTEMPLATE chọn DWG thư viện. TCINIT kiểm tra thư viện, TCCHECK chẩn đoán.

## Cài thủ công / máy không cho chạy PowerShell

Chép nguyên thư mục ToolsCadHL.bundle vào thư mục ApplicationPlugins ở trên.
Nếu AutoLoader bị tắt hoặc chính sách không cho nạp tự động, APPLOAD file
`ToolsCadHL.bundle\Contents\ToolsCadHL.lsp`; HLLOAD chọn DLL bên cạnh.
Chỉ khi cần nạp thủ công thường xuyên, thêm đúng file LSP vào Startup Suite.
Không sửa acad.lsp/acaddoc.lsp. Thêm thư mục Contents vào Support File Search
Path nếu cần tìm DLL/DCL thủ công; bộ bundle đã khai báo SupportPath.
Nếu chọn cách Startup Suite, khi gỡ cần bỏ mục này trong APPLOAD.

## Sử dụng

- HLFLOAT: bảng modeless, kéo thanh tiêu đề để di chuyển tự do, không tự dock.
- HLDOCK: ghim phải và cho phép dock trái/phải; HLTOOLS: hiện bảng.
- Chọn tab PPR/UPVC/THÉP/THANG MÁNG/ỐNG GIÓ, đặt vật liệu và kích thước.
- Chọn thao tác vẽ hoặc phụ kiện, làm theo dòng lệnh. Enter kết thúc, Esc hủy.
- TCDCL là giao diện dự phòng **modal**, phải đóng hộp thoại để thao tác vẽ.
- Xem DANH_SACH_LENH.md cho toàn bộ lệnh; HLFLOAT_CHECK.md cho nghiệm thu.
- Thử Undo sau một lệnh; chỉ chạy TCSELFTEST trong bản vẽ Model mới rỗng.

## Tương thích LISP khác và xử lý lỗi

Không nạp TOOLS-CAD_DUY.lsp, bản HL cũ và bản HL mới trong cùng phiên làm việc.
Loader kiểm tra namespace TC/HL trước khi ghi dữ liệu nội bộ; nếu đã có mã
khác sử dụng thì dừng và yêu cầu phiên mới. Alias chung như TOOLS/SHOWFORM
chỉ được đăng ký khi chưa có, nên dùng HLTOOLS khi TOOLS thuộc LISP khác.
Cơ chế này không thể ngăn một LISP được nạp SAU đó ghi đè hàm TOOLS-CAD.
Không có các LISP bên thứ ba trong workspace nên chưa kiểm tra phối hợp thực tế.

Nếu có "bad function": nhấn F2, lưu toàn bộ thông báo, tên lệnh, phiên bản
HLSTATUS và thứ tự APPLOAD; thử lại trong phiên sạch chỉ nạp plugin này.
Lỗi một thao tác được bộ chạy bắt và khôi phục biến hệ thống/Undo khi phù hợp;
không thể bảo đảm phục hồi mọi lỗi COM/AutoCAD native mà chưa kiểm thử host.
Nếu bảng không hiện: HLSTATUS -> HLLOAD -> HLFLOAT. Nếu DCL không mở, kiểm tra
quyền ghi TEMP và F2. Nếu thiếu block, kiểm tra đúng template, không đổi tên
block để bỏ qua lỗi. Đường dẫn DWG có thể đổi bằng TCTEMPLATE bất cứ lúc nào.

## Gỡ cài đặt

1. Đóng AutoCAD; chạy Uninstall.cmd từ đúng ZIP đã dùng để cài.
2. Bộ gỡ chỉ xóa file plugin khớp checksum. Nếu file bị sửa, dừng và giữ lại:
   sao lưu rồi xóa thủ công thư mục plugin khi đã xác định dữ liệu cần giữ.
3. Bỏ Startup Suite, Support Path, Trusted Location đã tự thêm (nếu có).
4. DWG, cấu hình trong registry và `%APPDATA%\ToolsCadHL\2025` được giữ lại.
   Nếu muốn xóa cache/cấu hình, sao lưu thư mục đó rồi tự xóa sau khi đóng CAD.
   Không xóa DWG thư viện. Khởi động lại CAD để giải phóng DLL đã nạp.

## Nội dung ZIP

Install/Uninstall (.cmd và .ps1); ToolsCadHL.bundle (LSP, DCL, DLL và manifest);
nguồn source/, tools/, tests/ để đối chiếu/build; báo cáo, danh sách lệnh và
hướng dẫn nghiệm thu. DLL Autodesk, SDK và DWG của người dùng không đóng gói.
