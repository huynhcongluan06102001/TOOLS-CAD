# TOOLS CAD HL 0.14.17 — bản gộp cho AutoCAD 2025

Đã gộp các chức năng của 0.14.16 với tab UPVC2 gồm 8 nút MP1Y+2E1, MP1Y+2E2,
MP1Y+3E1, MP1Y+3E2, RS1Y+2E1, RS1Y+2E2, RS1Y+3E1, RS1Y+3E2.
UPVC cũ giữ nguyên chức năng; UPVC2 lưu thông số riêng và dùng chung thư viện.

**UPVC2 là phần mới cần kiểm thử trên bản sao DWG.** Đã biên dịch và kiểm tra logic
ngoài AutoCAD; chưa chạy thực tế 8 mẫu trong AutoCAD. Không coi các kiểm tra tự động
là xác nhận hình học dynamic block, visibility, cổng nối, Undo hoặc giao diện đã đúng.

## Cập nhật dễ nhất

1. Giải nén ZIP ra thư mục riêng, không chạy trực tiếp trong ZIP.
2. Đóng toàn bộ AutoCAD. DLL cũ không thể thay khi CAD còn mở.
3. Mở `%APPDATA%\Autodesk\ApplicationPlugins` trong File Explorer.
4. Chuyển thư mục `ToolsCadHL.bundle` cũ ra một thư mục sao lưu **ngoài ApplicationPlugins**.
   Giữ nguyên DWG thư viện riêng của bạn. Không để hai bản bundle cùng được AutoLoader nạp.
5. Chép nguyên thư mục `ToolsCadHL.bundle` trong ZIP mới vào ApplicationPlugins.
   Cách chép thư mục này không cần chạy PowerShell.
6. Mở AutoCAD 2025, mở bản sao DWG để thử. Gõ `HLSTATUS`: LISP và DLL phải cùng 0.14.17.
7. Gõ `HLFLOAT` mở bảng nổi hoặc `HLDOCK` ghim bảng. Nếu Startup Suite còn tự nạp
   ToolsCadHL cũ ở đường dẫn khác, bỏ mục cũ rồi đóng/mở lại AutoCAD.

Cài mới cũng có thể dùng Install.cmd khi chính sách máy cho phép PowerShell.
Nếu báo scripts disabled, dùng cách chép bundle trên; không cần đổi chính sách máy.

## Dùng UPVC2

1. Chọn tab UPVC2, chọn vật liệu đúng với ống. Bấm CHỌN / NẠP LẠI THƯ VIỆN DWG,
   chọn thư viện UPVC đầy đủ đang dùng cho tab UPVC.
   File UPVCPRO được nhúng vào DLL để lấy mẫu bố trí/trạng thái, **không thay thế thư viện đủ size**.
2. Chọn một trong 8 nút. MP: chọn MLINE chính và MLINE nhánh vuông góc.
   RS: chọn MLINE chính, rồi Circle đường kính đúng size hoặc block D<size> scale 1
   của trục đứng (size 168 cũng nhận tên block 168).
3. Chỉ phía hướng chảy trên ống chính, ở phía tương ứng so với trung điểm đoạn chính.
   Hai đối tượng phải cùng layer, trong Model Space. MLINE phải thẳng hai đỉnh,
   canh tim Zero, style có biên ngoài đối xứng; hình học WCS XY, Z=0.
4. Size lấy từ bề rộng thực của MLINE / ký hiệu trục đứng. Nhánh không lớn hơn ống chính.
   Tools dùng block `Y-D<chính>x<nhánh>` và `ELB45-D<nhánh>` từ thư viện,
   không phóng toàn cụm mẫu D114 thành size khác.
5. MLINE nối giữa phụ kiện dùng style của MLINE nhánh; RS dùng style ống chính với
   bề rộng theo size trục đứng. Đối tượng mới dùng ByLayer; màu cố định bên trong
   block/style vẫn tuân theo định nghĩa thư viện.
6. Bật Ngắt / cắt ống để thay đoạn chính/nhánh tại cổng phụ kiện. Nếu tắt, giữ ống gốc,
   nên có thể thấy ống gốc đi xuyên cụm. U hoàn tác cả thao tác.
7. Thiếu block, không khớp trạng thái hoặc không xác định được cổng nối: lệnh báo lỗi
   và không hoàn tất cụm. Xem F2 và giữ log để kiểm tra thư viện.

## Kiểm tra trước khi dùng bản vẽ thật

- Trong DWG mới: nạp thư viện, thử UPVC cũ hai lần liên tiếp, thử hủy bằng Esc.
- Thử từng nút UPVC2 với chính D140, nhánh D114 như mẫu, rồi thử các size khác mà
  thư viện thực sự có. Kiểm tra hướng Y/co, đầu MLINE, khoảng ngậm và đường kính.
- Thử nhánh hai phía, ống chính nằm ngang/dọc/xoay 45°, cả MP và RS; kiểm tra U/Redo.
- Thử thiếu block, ống quá ngắn, chọn sai đối tượng, layer khóa: ống gốc phải được giữ.
- Kiểm tra lại UPVC/PPR/STEEL/DUCT, OGM S1/S2/R1/R2, ghi chú và các tab cũ.
- Nếu báo không xác định được cổng nối: chưa thể khẳng định thư viện đó tương thích
  với thuật toán UPVC2. Gửi ảnh, F2 và DWG nhỏ có ống và block liên quan.

## Quay lại / gỡ

Đóng AutoCAD, chuyển bundle 0.14.17 ra ngoài ApplicationPlugins; chép bundle sao lưu
về vị trí cũ. Không xóa DWG thư viện. Để gỡ hoàn toàn, bỏ bundle và mục Startup Suite
trỏ tới TOOLS CAD. Thông số cá nhân trong `%APPDATA%\ToolsCadHL\2025` được giữ lại.

---
Lịch sử các bản trước (số phiên bản/đếm kiểm tra bên dưới chỉ áp dụng cho bản tương ứng):

# 0.14.16 — Standard mặc định, nạp MLINE style từ thư viện

Đóng AutoCAD, thay ToolsCadHL.bundle trong %APPDATA%\Autodesk\ApplicationPlugins; mở lại và kiểm tra HLSTATUS báo LISP/DLL 0.14.16.
Khi tạo bảng menu trong phiên mới, các tab pipe bắt đầu bằng Standard. Sau đó:
1. CHỌN / NẠP LẠI THƯ VIỆN DWG: chọn file chứa MLINE styles (file có style nhưng không có block cũng được).
2. Nạp style: đọc danh sách từ DWG và nhập các style chưa có vào bản vẽ hiện hành.
3. Chọn style trong danh sách rồi vẽ. Standard luôn có trong danh sách. Chỉ mở dropdown không đọc cơ sở dữ liệu.
Style trùng tên giữ nguyên định nghĩa trong bản vẽ, không ghi đè để tránh thay đổi ống đã vẽ. Nếu đã sửa style trong thư viện, đặt tên mới hoặc thử bản vẽ trống.
Sang bản vẽ khác cần Nạp style vào bản vẽ đó trước khi dùng style thư viện. Sau khi khởi động lại AutoCAD, chọn lại thư viện trước khi Nạp style. Style dùng để vẽ phải có hai biên ngoài đối xứng qua tim; công cụ báo lỗi nếu không phù hợp.
Đã biên dịch và kiểm tra tĩnh; chưa kiểm chứng import MLINE style trực tiếp trong AutoCAD 2025.

# 0.14.15 — thu gọn DUCT và chuyển ô tích ghi chú

Đóng toàn bộ AutoCAD, thay ToolsCadHL.bundle trong %APPDATA%\Autodesk\ApplicationPlugins. Mở lại, HLSTATUS xác nhận LISP/DLL 0.14.15.
Ba ô Thêm tiền tố/Thêm hậu tố/Thêm vật liệu chuyển xuống cuối mỗi tab MEP có ghi chú tuyến. Giá trị và chức năng giữ nguyên.
DUCT dùng hai hàng tự tính chiều cao, bỏ bảng/flow lồng gây vùng trống. Các nút vuông S1/S2/R1/R2 dùng chữ nhỏ và không có padding để hiện cả số. Chỉ DUCT có các nút này.
Kiểm tra kéo hẹp/rộng bảng và các mức DPI Windows. Chưa chạy trực tiếp AutoCAD trong môi trường build.

# 0.14.14 — tích hợp OGM và tùy chọn ghi chú

## Cập nhật
Đóng toàn bộ AutoCAD, thay ToolsCadHL.bundle trong %APPDATA%\Autodesk\ApplicationPlugins bằng bundle mới. Mở AutoCAD 2025, HLSTATUS phải báo LISP/DLL 0.14.14; HLFLOAT mở bảng.

## Thay đổi
- Thứ tự: UPVC, PPR, STEEL, DUCT, LIGHTING, ELECTRICAL PANELS, CABLE TRAYS, các tab còn lại. Thông số riêng từng hệ vẫn giữ; ánh xạ lại tab đã chọn từ phiên bản cũ.
- Chỉ DUCT có 4 nút vuông: S1/S2 hàng trên, R1/R2 hàng dưới, cạnh lựa chọn nguồn và ghi chú.
- Bấm nút, nhập đường kính ống mềm (Enter dùng giá trị OGM gần nhất). Bỏ tích Polyline có sẵn để vẽ SPLINE với xem trước. Tích ô này để chọn đường dẫn mở có sẵn; đường nguồn bị xóa sau khi thành công, theo hành vi OGM gốc. UNDO để hoàn tác.
- Lệnh S3/R3 dùng dòng lệnh. Khi trùng tên LISP khác, dùng HLOGM_S1/S2/S3 hoặc HLOGM_R1/R2/R3. Không ghi đè S1..R3 đã tồn tại. HLOGM mở menu sáu kiểu; HLOGMINFO kiểm tra module.
- Ghi chú tuyến điều khiển có/không tạo ghi chú. Ba ô Thêm tiền tố, Thêm hậu tố, Thêm vật liệu điều khiển độc lập; vật liệu nằm ngay dưới trường hậu tố. Bỏ tích không xóa giá trị nhập. Tắt hậu tố cũng tắt nội dung BOP/BOT dự phòng. Kích thước và hệ thống vẫn hiện.
- OGM dùng layer hiện hành, màu ByLayer, ghi chú vật liệu ONG GIO MEM; không tự nối/chèn phụ kiện vào tuyến cứng.

## Kiểm tra trên AutoCAD trước khi dùng bản vẽ thật
1. Dùng bản vẽ thử, đổi từng tab và kéo rộng/hẹp bảng; kiểm tra nút vuông chỉ ở DUCT, ô lựa chọn không bị che.
2. Thử S1/S2/R1/R2: nhập đường kính, vẽ đường cong thoải. Enter hoàn tất SPLINE và chấp nhận tiếp tuyến. Kiểm tra đường kính, layer, hình đầu ống; UNDO.
3. Thử Select trên LINE/ARC/SPLINE mở; thử đường gấp quá nhỏ và Esc giữa chừng. Kiểm tra đường nguồn được giữ khi lỗi/hủy, snap và DRAGMODE phục hồi; nút menu dùng lại được.
4. Gọi S3/R3 hoặc HLOGM_S3/HLOGM_R3; kiểm tra không xung đột bản OGM độc lập.
5. Thử bật/tắt từng mục tiền tố/hậu tố/vật liệu với ống cứng và mềm, lưu thông số rồi mở lại.
6. Thử lại vẽ và đặt phụ kiện các hệ; các quy tắc hình học cũ không được sửa trong bản này.

Đã biên dịch .NET; 321 kiểm tra dữ liệu, 226 kiểm tra hình học OGM/nội dung ghi chú và 67 kiểm tra hình học nút nối/lấy kích thước mô phỏng đã qua. Kiểm tra tĩnh LISP và ZIP đã qua. Chưa có AutoCAD trong môi trường này, chưa xác nhận chạy native SPLINE/COM, DPI, Undo/Esc và các dynamic block thực tế.

# 0.14.13 — hiện đủ ô đảo hướng và các lựa chọn dài

Đóng toàn bộ AutoCAD, thay ToolsCadHL.bundle trong %APPDATA%\Autodesk\ApplicationPlugins bằng bundle mới. Mở lại và kiểm tra HLSTATUS báo LISP/DLL 0.14.13.
Các nhóm GHI CHÚ và ĐẶT PHỤ KIỆN dùng chung bảng bố cục chính, bỏ bảng lồng gây cắt hàng cuối. Các checkbox tự đo chiều cao theo chiều rộng và DPI để xuống dòng đầy đủ, gồm đảo hướng/mirror, tự nối, ngắt tuyến và xóa polyline.
Kiểm tra bằng cách kéo hẹp/rộng bảng và cuộn qua các nhóm trên các tab. Chưa kiểm thử trực tiếp trên AutoCAD; chức năng vẽ không thay đổi.

# 0.14.12 — nút phụ kiện cùng kích thước với nút thống kê

Đóng toàn bộ AutoCAD, thay ToolsCadHL.bundle trong %APPDATA%\Autodesk\ApplicationPlugins bằng bundle mới. Mở lại và kiểm tra HLSTATUS báo LISP/DLL 0.14.12.
ĐẶT PHỤ KIỆN và SỬA THUỘC TÍNH nằm trực tiếp trong bảng chính, cùng chiều rộng/chiều cao với TẠO HƯỚNG CHẢY và THỐNG KÊ. Hai nút không còn nằm trong vùng nhóm phụ kiện gây che hàng cuối.
Không thay đổi chức năng vẽ hoặc đặt phụ kiện. Chưa kiểm thử trực tiếp giao diện trên AutoCAD.

# 0.14.11 — thu gọn nút phụ kiện

Đóng toàn bộ AutoCAD, thay ToolsCadHL.bundle trong %APPDATA%\Autodesk\ApplicationPlugins bằng bundle mới. Mở lại và kiểm tra HLSTATUS báo LISP/DLL 0.14.11.
Các nút hành động dùng cùng chiều cao 33 đơn vị giao diện (Windows tự scale theo DPI), không giãn dọc theo nhóm chứa. Nút SỬA THUỘC TÍNH PHỤ KIỆN rút gọn nhãn thành SỬA THUỘC TÍNH; lệnh vẫn là TCBEDIT.
Chưa kiểm thử hiển thị trực tiếp trong AutoCAD. Chức năng vẽ/phụ kiện giữ nguyên 0.14.10.

# 0.14.10 — kích thước phụ kiện và bố cục

Đóng toàn bộ AutoCAD, thay ToolsCadHL.bundle trong %APPDATA%\Autodesk\ApplicationPlugins; mở lại và kiểm tra HLSTATUS báo LISP/DLL 0.14.10.

ĐẶT PHỤ KIỆN: chọn loại trong bảng rồi bấm đặt. Chọn ống chính để lấy vật liệu, D/DN hoặc W/H thực tế. Với tê/Y/gót giày/côn/cross, chọn thêm nhánh/đầu thứ hai; Enter tại bước này dùng cùng kích thước ống chính. Sau đó chọn điểm đặt và góc. Với côn giảm chọn đầu lớn làm ống chính. Enter ngay bước chọn ống chính giữ cách nhập tay cũ. Các cặp co lên/xuống vẫn có bước chọn MLINE riêng.
Layer phụ kiện vẫn theo layer hiện hành của CAD. Chức năng này lấy kích thước, không tự suy đoán hướng đặt trong chế độ thủ công.
Tự nối tiếp tục đọc kích thước từ các đoạn được nối. Thêm kiểm tra kích thước rộng sau khi đặt Height, hỗ trợ tên thông số Width và ưu tiên Height thực của block hơn metadata cũ.
GHI CHÚ dùng bố cục tự đo trực tiếp để tránh cắt ô Cao chữ. Nút Nạp style thu gọn.

67 kiểm tra hình học/lấy kích thước với các hàm CAD mô phỏng đã qua. Chưa kiểm chứng dynamic block, visibility, cổng nối và DPI thực tế trên AutoCAD. Nếu block vẫn sai hình, gửi DWG mẫu và kết quả TCINSPECT của block đó.

# 0.14.9 — bố cục menu gọn hơn

Đóng toàn bộ AutoCAD rồi thay ToolsCadHL.bundle trong %APPDATA%\Autodesk\ApplicationPlugins bằng bundle mới. Mở lại, dùng HLSTATUS xác nhận LISP/DLL 0.14.9, HLFLOAT mở bảng.
Tiêu đề chỉ còn TOOLS CAD HL; số phiên bản xem bằng HLSTATUS.
Hướng dẫn dài được chuyển xuống cuối tab. Ô MLINE style dùng hết chiều rộng, nút nạp đặt bên dưới. Ô số dành đủ chiều cao và danh sách xổ tự mở rộng theo nội dung.
Giữ màu nâu nhạt, tab tiếng Anh và cơ chế vẽ/phụ kiện của 0.14.8.
Cần kiểm tra trực tiếp giao diện ở mức DPI Windows đang dùng; chưa chạy AutoCAD trong môi trường build.

# 0.14.8 — kết nối nhánh tại mép tuyến chính

Đóng toàn bộ AutoCAD, thay nguyên ToolsCadHL.bundle trong %APPDATA%\Autodesk\ApplicationPlugins, mở lại và dùng HLSTATUS xác nhận LISP/DLL 0.14.8.

1. Chọn/nạp lại thư viện DWG chứa đúng block phụ kiện.
2. Chọn layer hiện hành giống tuyến chính, đúng hệ và vật liệu.
3. Bật “Tự nối vào tuyến cùng layer”. Nếu tắt, tools chỉ tạo co ở các góc của tuyến mới, không tự chèn tê/chạc vào tuyến cũ.
4. Vẽ nhánh kết thúc tại tim hoặc mép ngoài tuyến chính. Nhánh vuông góc dùng tê/gót giày; nhánh 45 độ dùng Y nếu thư viện có tổ hợp được hỗ trợ. Thang máng và ống gió tròn chưa hỗ trợ nhánh Y tự động.
5. Với tuyến đã vẽ: dùng “TỰ ĐỘNG KẾT PHỤ KIỆN”, chọn đoạn chính rồi đoạn nhánh. Không cần vẽ lại.
6. Nếu chưa tạo phụ kiện, xem cảnh báo dưới bảng và nhấn F2 để đọc lỗi. TCINIT kiểm tra thư viện; gửi log cùng DWG mẫu nếu lỗi vẫn còn.

Đã kiểm tra 42 trường hợp lập kế hoạch nút nối bằng trình thông dịch VeLisp (có bộ tương thích RTOS/EQUAL), biên dịch .NET và kiểm tra tĩnh. Chưa kiểm chứng chèn block/dynamic properties/cắt tuyến trong AutoCAD.
Không tự sửa hình học tuyến cũ hoặc bật lại lựa chọn tự nối đã lưu.

# 0.14.7 — menu nền nâu nhạt, tên tab tiếng Anh

Đóng toàn bộ AutoCAD trước khi thay bundle; DLL đã nạp không thể cập nhật trong phiên đang mở.
Thay thư mục ToolsCadHL.bundle trong %APPDATA%\Autodesk\ApplicationPlugins bằng bundle trong ZIP mới, rồi mở lại AutoCAD 2025.
Gõ HLSTATUS để xác nhận LISP và DLL 0.14.7; HLFLOAT để mở bảng.
Tên tab bên phải dùng tiếng Anh; các thông số và khóa lưu cấu hình giữ nguyên.
Chọn layer hiện hành trên thanh Layer của AutoCAD trước khi nhấn vẽ; không nhập tên layer trong tools.
Bản này giữ thay đổi CLAYER của 0.14.6. Chưa kiểm thử giao diện trực tiếp trong AutoCAD.

# 0.14.6 — dùng layer hiện hành của AutoCAD

Đóng AutoCAD, thay nguyên bundle mới và mở lại. HLSTATUS phải báo 0.14.6.
Không còn ô nhập/xổ layer trong tools và không cần nút Nạp layer.

1. Trên thanh Layer mặc định của AutoCAD, chọn layer hiện hành muốn vẽ.
   Nếu đang chọn đối tượng, nhấn Esc trước để tránh chỉ đổi layer đối tượng đó.
2. Bấm VẼ trong tools. Công cụ lấy CLAYER tại thời điểm bắt đầu lệnh.
3. Đổi layer trên thanh CAD trước khi bắt đầu tuyến tiếp theo nếu cần.
Layer đã lấy được giữ cho toàn bộ một lệnh; không đổi giữa các đoạn đang vẽ.
Đối tượng mới dùng ByLayer. Màu cố định bên trong block/MLINE style có thể
vẫn được ưu tiên; không tự thay định nghĩa dùng chung làm đổi đối tượng cũ.
Các lệnh chỉnh sửa/sao chép đối tượng cũ vẫn giữ ngữ nghĩa vốn có của chúng.

Bỏ đường đọc layer từ UI dropdown gây crash được báo ở 0.14.4.
Không cần cập nhật riêng 0.14.5; dùng trực tiếp gói này. Chưa chạy GUI AutoCAD.

---
Các hướng dẫn layer của bản cũ bên dưới không áp dụng cho 0.14.6.

# 0.14.5 — bản sửa sau báo cáo AutoCAD đóng khi xổ Layer

Ngừng dùng 0.14.4. Đóng AutoCAD, thay nguyên bundle mới và mở lại.
HLSTATUS phải báo LSP/DLL 0.14.5. Không chỉ APPLOAD đè vì DLL cũ vẫn trong RAM.

Cách dùng Layer: khi CAD không chạy lệnh, bấm NẠP LAYER, sau đó xổ chọn tên.
Sau khi đổi bản vẽ hoặc thêm layer, bấm NẠP LAYER lại. Vẫn gõ tên trực tiếp được.
MLINE style tương tự: bấm NẠP STYLE rồi xổ chọn.
Bản sửa không truy cập Database/đổi Items trong sự kiện DropDown, không dùng
Shell AutoComplete; việc đọc dùng document lock, chỉ theo nút nạp riêng.

Chưa tái hiện crash trong AutoCAD nên chưa khẳng định loại bỏ mọi nguyên nhân.
Thử trên bản vẽ NEW trước: nạp, xổ nhiều lần, vẽ, đổi bản vẽ, nạp lại.
Nếu vẫn văng, gửi thông báo Fatal Error/CER và DWG tối giản. Không lặp thử
trên bản vẽ chưa lưu. Có thể quay về 0.14.3 dùng ô nhập tên layer.

---
Tài liệu cũ bên dưới để tham khảo; cách nạp layer hiện tại theo phần trên.

# 0.14.4 — xổ chọn layer bản vẽ

Đóng AutoCAD và thay nguyên bundle mới. HLSTATUS phải báo LSP/DLL 0.14.4.
Ở mỗi tab, bấm mũi tên ô Layer để chọn layer của bản vẽ đang mở.
Danh sách cập nhật mỗi lần mở, kể cả sau khi tạo layer/đổi bản vẽ.
Có thể gõ tên mới như trước; layer Xref không nằm trong danh sách chọn.
Layer khóa/tắt/đóng băng vẫn được liệt kê nhưng lệnh vẽ sẽ báo yêu cầu mở layer.

Các đối tượng mới qua bộ tạo hình tools dùng Color=ByLayer (ACI 256).
Màu layer đã tồn tại được giữ nguyên. Với block có màu cố định ở nét bên
trong, hoặc MLINE style có màu từng nét riêng, màu nội bộ có thể ưu tiên
hơn ByLayer của đối tượng ngoài. Muốn toàn bộ nét theo layer: chuẩn hóa
block thư viện về layer 0/ByBlock và màu nét MLINE style về ByLayer.
Tools không tự đổi ruột block/style dùng chung vì có thể đổi đối tượng cũ.

Thử: chọn layer đỏ, vẽ một tuyến; chuyển layer xanh, vẽ tuyến khác;
đổi màu layer đỏ bằng LA, tuyến đầu phải cập nhật màu nếu không có override.
Chưa kiểm thử trực tiếp trên AutoCAD; kiểm tra Properties và gửi DWG nếu
block/style vẫn có màu cố định. Bản này chỉ sửa lựa chọn layer, không đổi
thuật toán phụ kiện.

---
# TOOLS-CAD 0.14.3 — AutoCAD 2025

## Cập nhật
Đóng toàn bộ AutoCAD. Sao lưu bundle cũ ra ngoài ApplicationPlugins rồi
chép nguyên ToolsCadHL.bundle mới vào. HLSTATUS phải báo LSP/DLL 0.14.3.
Nếu DLL vẫn trỏ bản cũ, HLLOAD chọn DLL trong Contents của bundle mới.
PowerShell bị chặn: chỉ chép bundle thủ công, không cần chạy Install.cmd.

## Bản vẽ mới và thư viện tên bất kỳ
1. Mở bản vẽ cần làm việc, không cần mở DWG thư viện.
2. APPLOAD ToolsCadHL.lsp nếu chưa tự nạp; HLFLOAT mở bảng.
3. Bấm CHỌN / NẠP LẠI THƯ VIỆN DWG. Chọn file .dwg có tên bất kỳ.
4. Tools kiểm tra đọc được danh sách block rồi mới lưu đường dẫn.
5. TCINIT in danh sách block ống gió còn thiếu; xem F2.
6. Vẽ tuyến/chèn phụ kiện: block thiếu trong bản vẽ được sao chép trực tiếp
   từ thư viện bằng API AutoCAD .NET, không cần mở bản vẽ thư viện.

Có thể đổi tên FILE DWG nhưng không tùy ý đổi tên block hoặc tham số dynamic
mà tools đang sử dụng. Block cùng tên đã có trong bản vẽ được giữ nguyên;
chọn thư viện khác không tự ghi đè định nghĩa cũ. Thử trong NEW để phân biệt.
Ví dụ tê chữ nhật dùng Chac 3, gót giày dùng Chac chu T cong, có hậu tố
cach nhiet/tieu am theo vật liệu. Chân rẽ trong danh sách phụ kiện thủ công
cần block Chan re hoặc Chan re vuong tron tương ứng. Thiếu block sẽ báo tên.

## Vẽ và giao diện
HLFLOAT: nổi; HLDOCK: ghim; HLTOOLS: hiện; HLSTATUS: phiên bản/đường dẫn DLL.
Chọn MLINE style trong tab pipe. Style cần hai nét ngoài đối xứng offset 0;
muốn có nét tim, dùng style có nét offset 0. TC_MC tạo được trong bản vẽ mới;
style khác cần nhập bằng MLSTYLE. Chọn DWG không tự nhập mọi MLINE style.
Góc FREE/45/90/BOTH tính theo đoạn trước. Khi Pick, hướng hiệu chỉnh sau khi
chọn điểm; đoạn đầu tự do. Center tại điểm tiếp theo cho phép chọn tim MLINE.
TCDCL là hộp thoại dự phòng. Thư viện hiện dùng DLL mới để đọc/nhập block.

## Kiểm thử và lỗi
Dùng bản sao DWG: vẽ lần một/lần hai, Enter/Esc, đổi bản vẽ, dock/float.
Thử TCFIT với co/tê/chạc/gót giày và kiểm tra kích thước main/nhánh.
TCINIT giúp tìm tên block thiếu; TCINSPECT xem tham số của block thực tế.
Chưa chạy AutoCAD trong môi trường phát triển. Chưa thể xác nhận mọi phụ kiện
đúng hình học nếu chưa có DWG mẫu và thư viện. Gửi F2 và hai DWG nếu còn lỗi.
Giữ SECURELOAD bật; chỉ thêm Contents của plugin vào Trusted Locations nếu
AutoCAD yêu cầu và chính sách máy cho phép.

## Gỡ cài
Đóng AutoCAD; Uninstall.cmd từ đúng gói hoặc sao lưu rồi bỏ bundle thủ công.
Bỏ Startup Suite/Trusted Location đã tự thêm. Giữ lại DWG và cấu hình cá nhân.
