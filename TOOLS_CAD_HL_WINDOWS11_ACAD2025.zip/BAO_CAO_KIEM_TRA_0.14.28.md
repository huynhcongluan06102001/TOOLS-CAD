# Kiểm tra 0.14.28

- Đọc steel.dwg gốc: 35 block mẫu, scale X/Y=1; bảng DN200/250/300 tương ứng OD219.1/273/323.8.
- Giữ file DWG gốc nguyên byte, nhúng trong DLL; whitelist 35 tên để nhập đúng thư viện bổ sung.
- Build net8.0-windows AutoCAD.NET 25.0.1: 0 warning, 0 error.
- 17.142 domain assertions: danh mục, các phép nối/cắt, xoay Ortho theo UCS; không gọi AutoCAD.
- 15 kiểm tra luồng VALVES với API giả lập: Space, click, Esc, OSNAP, R, cleanup.
- 27 kiểm tra STEEL: quy đổi kích thước, nhận diện MLINE, định tuyến thư viện, giữ size cũ.
- Kiểm tra ngoặc/namespace LISP, DLL nhúng, manifest và SHA256 của gói cài.

Giới hạn: không có AutoCAD Windows trong môi trường thực hiện. Chưa xác nhận tương tác OSNAP,
F8/GetAngle, đánh giá dynamic block và cắt MLINE trên host thực. Không khẳng định hết mọi lỗi.
