# HLFLOAT 0.13 — kiểm tra AutoCAD 2025 Windows

Tiếp tục từ commit 06150a9 của deliver/tools-cad-Library-autocad2025.
Nguồn source/ được khôi phục từ ZIP 0.11; không viết lại chức năng CAD.
Bản này bổ sung HLFLOAT dùng PaletteSet hiện có, tắt tự dock khi thả nổi;
HLDOCK bật lại dock trái/phải. DCL gọi dispatcher nội bộ thay vì tên C: có thể
bị LISP khác ghi đè. Cầu nối _013 tránh dùng nhầm DLL _011.

1. Đóng và mở lại AutoCAD để gỡ DLL cũ khỏi tiến trình. Giải nén ZIP mới
   vào thư mục riêng, dùng Trusted Locations theo chính sách của máy.
   Không tắt SECURELOAD. APPLOAD ToolsCadHL.lsp.
2. Gõ HLLOAD, chọn ToolsCadPalette.dll của bản mới nếu máy vẫn trỏ đến DLL cũ.
   HLSTATUS phải báo DLL 0.13.0; xem F2 nếu có lỗi nạp.
3. HLFLOAT: kéo thanh tiêu đề qua các vị trí và màn hình; sát cạnh AutoCAD
   vẫn phải nổi. Thử resize, đóng/mở lại, gọi HLFLOAT nhiều lần (chỉ một bảng).
4. HLDOCK phải ghim phải. HLFLOAT phải tách bảng ra lại; bảng không chặn chọn
   đối tượng hoặc nhập lệnh. Đổi bản vẽ khi đang chạy lệnh, thử Esc rồi chạy lại.
5. TCDCL: chọn lệnh, Enter/Esc, lưu thông số và mở bảng dock. DCL vẫn là
   hộp thoại modal, không phải bảng nổi modeless.
6. Dùng bản sao DWG, chọn thư viện bằng TCTEMPLATE; thử các chức năng đang dùng
   tốt (vẽ tuyến, phụ kiện, DIM, thống kê) và Undo. TCSELFTEST chỉ chạy trong
   bản vẽ Model mới rỗng. Thư viện DWG không có trong repository.
7. Thử cùng các LISP đang dùng, cả hai thứ tự APPLOAD. Hai bản TOOLS-CAD_Library
   và ToolsCadHL dùng chung namespace tc: và alias, nên không nạp đồng thời.
   Nếu vẫn có bad function, gửi toàn bộ dòng F2, tên lệnh và thứ tự nạp LISP.

Chưa chạy AutoCAD/WinForms trong môi trường Linux. Build API thành công và
kiểm tra tĩnh không chứng minh hình học, kéo thả hay tương tác LISP thực tế.

Build: dotnet build source/palette/ToolsCadPalette.csproj -c Release -p:RestoreLockedMode=true
Sau đó: python tools/package_hl.py <đường-dẫn-ToolsCadPalette.dll>
Công cụ đóng gói cập nhật LSP, DLL nhúng, nguồn và checksum trong ZIP hiện có.
