$ErrorActionPreference = 'Stop'
if (Get-Process acad -ErrorAction SilentlyContinue) { throw 'Close AutoCAD before uninstalling.' }
$target = Join-Path $env:APPDATA 'Autodesk\ApplicationPlugins\ToolsCadHL.bundle'
if (!(Test-Path $target)) { Write-Host 'ToolsCadHL is not installed.'; exit 0 }
# Use the distributed manifest, not arbitrary deletion instructions from the installed directory.
$manifest = Join-Path $PSScriptRoot 'ToolsCadHL.bundle\manifest.json'
$hashes = Get-Content $manifest -Raw | ConvertFrom-Json
foreach ($entry in $hashes.PSObject.Properties) {
    if ($entry.Name -match '(^[/\\]|\.\.|:)') { throw 'Invalid manifest path.' }
    $file = Join-Path $target $entry.Name
    if ((Test-Path $file) -and (Get-FileHash $file -Algorithm SHA256).Hash -ne $entry.Value) {
        throw "Modified file preserved: $file. Back it up and remove the plugin folder manually."
    }
}
foreach ($entry in $hashes.PSObject.Properties) {
    $file = Join-Path $target $entry.Name
    if (Test-Path $file) { Remove-Item -LiteralPath $file }
}
$installedManifest = Join-Path $target 'manifest.json'
if ((Test-Path $installedManifest) -and (Get-FileHash $installedManifest).Hash -eq (Get-FileHash $manifest).Hash) { Remove-Item -LiteralPath $installedManifest }
Get-ChildItem $target -Directory -Recurse | Sort-Object FullName -Descending | ForEach-Object {
    if (!(Get-ChildItem $_.FullName -Force)) { Remove-Item -LiteralPath $_.FullName }
}
if (!(Get-ChildItem $target -Force)) { Remove-Item -LiteralPath $target }
Write-Host 'Plugin files removed. User preferences, DLL cache and DWG libraries were preserved.'
