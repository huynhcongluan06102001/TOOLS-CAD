import json,math,re
from pathlib import Path
root=Path(__file__).resolve().parents[2]
m=json.loads((root/'source/palette/Resources/HiddenCatalog.json').read_text())
s=json.loads((root/'source/hidden/SourceSamples.json').read_text())
by={}
for row in s:by.setdefault(row['name'],[]).append(row)
assert len({k.upper() for k in m})==len(m)
for old,new in m.items():
 assert new in by,(old,new)
 sizes={(round(r['sx'],8),round(r['sy'],8)) for r in by[new]}
 assert len(sizes)==1,(old,sizes)
 assert all(math.isfinite(x) and x>0 for pair in sizes for x in pair)
 if old.endswith(' PPR'):
  olddims=re.search(r'-D(\d+)(?:x(\d+))?',old).groups()
  newdims=re.search(r'[øØ]\s*(\d+)(?:[xX](\d+))?',new).groups()
  assert tuple(int(x) if x else None for x in olddims)==tuple(int(x) if x else None for x in newdims) or (olddims[0]==olddims[1] and newdims[0]==olddims[0] and newdims[1] is None),(old,new)
assert 'Ø110' in m['ELB90-D110 PPR']
assert 'Ø125' in m['ELB90-D125 PPR']
assert '324' in m['WELD-ELB90-DN300'] and '355' not in m['WELD-ELB90-DN300']
assert not any(k.startswith('SCREW-') for k in m),'Do not mislabel weld fittings as threaded fittings'
print(f'PASS: {len(m)} aliases, source references/scales, PPR OD selection and DN300 ambiguity; no threaded/weld substitution.')
