using System;
using System.Linq;
using ToolsCad;
static class Upvc2Tests
{
 public static void Run(Action<bool,string> check)
 {
  check(Upvc2Geometry.Codes.Distinct().Count()==8,"eight distinct UPVC2 actions");
  foreach(var code in Upvc2Geometry.Codes)check(Upvc2Geometry.Pattern(code)>=0,"resolve "+code);
  bool failed=false;try{Upvc2Geometry.Pattern("arbitrary");}catch(ArgumentException){failed=true;}check(failed,"reject unknown UPVC2 action");
  var caps=Upvc2Geometry.JoinCaps(new[]{new U2Face(new U2Point(0,-57),new U2Point(0,0)),new U2Face(new U2Point(0,57),new U2Point(0,0))});
  check(caps.Count==1 && Math.Abs(caps[0].Width-114)<1e-8,"join split socket cap");
  caps=Upvc2Geometry.JoinCaps(new[]{new U2Face(new U2Point(0,-57),new U2Point(0,-1)),new U2Face(new U2Point(0,57),new U2Point(0,1))});
  check(caps.Count==2,"never fill a gap between cap segments");
  var a=new U2Face(new U2Point(0,-57),new U2Point(0,57));
  var b=new U2Face(new U2Point(200,-57),new U2Point(200,57));
  var wrong=new U2Face(new U2Point(0,500),new U2Point(114,500));
  var link=Upvc2Geometry.Link(new[]{a,wrong},new[]{b},114);
  check(ReferenceEquals(link.A,a)&&ReferenceEquals(link.B,b),"collinear socket pairing");
  failed=false;try{Upvc2Geometry.Link(new[]{wrong},new[]{b},114);}catch(InvalidOperationException){failed=true;}check(failed,"reject unconnected faces");
  foreach(var dn in Profile.Diameters("UPVC"))
  {
   double ratio=dn/114.0;
   var face=new U2Face(new U2Point(200*ratio,-dn/2),new U2Point(200*ratio,dn/2));
   check(ReferenceEquals(Upvc2Geometry.Match(b,new[]{face},ratio),face),"socket matching D"+dn);
   check(Math.Abs(Upvc2Geometry.Width(dn/2,-1,1)-dn)<1e-8,"MLINE style span D"+dn);
   foreach(var angle in new[]{0.0,Math.PI/4,Math.PI/2,Math.PI,Math.PI*1.5})
   foreach(var mirror in new[]{-1,1})
   {
    var y=new U2Point(Math.Cos(angle),Math.Sin(angle));var x=new U2Point(y.Y,-y.X)*mirror;
    var origin=new U2Point(1500,-700);
    var p=Upvc2Geometry.Map(new U2Point(0,0),origin,x,y);
    var q=Upvc2Geometry.Map(new U2Point(dn,0),origin,x,y);
    check(Math.Abs((q-p).Length-dn)<1e-8,"rotation/mirror preserves actual diameter");
   }
  }
  failed=false;try{Upvc2Geometry.Width(100,0,1);}catch(InvalidOperationException){failed=true;}check(failed,"reject non-centred MLINE");
  failed=false;try{Upvc2Geometry.Match(a,new[]{a},0);}catch(ArgumentException){failed=true;}check(failed,"reject zero socket size");
 }
}
