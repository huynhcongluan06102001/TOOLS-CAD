using System;
using System.Linq;
using ToolsCad;
static class Upvc2Tests
{
 public static void Run(Action<bool,string> check)
 {
  check(Upvc2Geometry.Codes.Distinct().Count()==12,"twelve distinct UPVC2 actions");
  var fixture=System.Text.Json.JsonDocument.Parse(System.IO.File.ReadAllText(System.IO.Path.Combine(AppContext.BaseDirectory,"upvcpro-refs.json")));
  var references=fixture.RootElement.GetProperty("references").EnumerateArray().ToArray();
  check(Upvc2Geometry.Codes.SequenceEqual(new[]{"MP1Y+1E1","MP1Y+1E2","MP1Y+2E1","MP1Y+2E2","MP1Y+3E1","MP1Y+3E2","RS1Y+1E1","RS1Y+1E2","RS1Y+2E1","RS1Y+2E2","RS1Y+3E1","RS1Y+3E2"}),"button order follows sample columns");
  foreach(var recipe in Upvc2Recipe.All)
  {
   for(int i=0;i<recipe.Parts.Length;i++)
   {
    var expected=i==0?"Y-D140x114":"ELB45-D114";var pt=recipe.Parts[i];
    check(references.Any(r=>r.GetProperty("name").GetString()==expected && (new U2Point(r.GetProperty("x").GetDouble(),r.GetProperty("y").GetDouble())-pt).Length<1),"recipe points to correct source fitting "+recipe.Code);
   }
   if(recipe.Riser)foreach(var pt in new[]{recipe.RiserNear,recipe.RiserEnd})
    check(references.Any(r=>r.GetProperty("name").GetString()=="ELB45-D114" && (new U2Point(r.GetProperty("x").GetDouble(),r.GetProperty("y").GetDouble())-pt).Length<1),"riser reference is elbow, not coincident circle "+recipe.Code);
   foreach(var dn in Profile.Diameters("UPVC"))
   {
    var port=new U2Point(-3*dn,2*dn);var anchor=new U2Point(-15*dn,10*dn);
    var origin=new U2Point(0,Upvc2Recipe.OriginY(port,anchor,recipe.Outlet));
    check(Math.Abs((anchor-origin-port).Dot(recipe.Outlet.Perp))<1e-8,"branch/riser socket alignment "+recipe.Code);
    check((anchor-origin-port).Dot(recipe.Outlet)>0,"anchor on outward side "+recipe.Code);
   }
  }
  foreach(var code in Upvc2Geometry.Codes)check(Upvc2Geometry.Pattern(code)>=0,"resolve "+code);
  bool failed=false;try{Upvc2Geometry.Pattern("arbitrary");}catch(ArgumentException){failed=true;}check(failed,"reject unknown UPVC2 action");
  var caps=Upvc2Geometry.JoinCaps(new[]{new U2Face(new U2Point(0,-57),new U2Point(0,0)),new U2Face(new U2Point(0,57),new U2Point(0,0))});
  check(caps.Count==1 && Math.Abs(caps[0].Width-114)<1e-8,"join split socket cap");
  caps=Upvc2Geometry.JoinCaps(new[]{new U2Face(new U2Point(0,-57),new U2Point(0,-1)),new U2Face(new U2Point(0,57),new U2Point(0,1))});
  check(caps.Count==2,"never fill a gap between cap segments");
  var a=new U2Face(new U2Point(0,-57),new U2Point(0,57));
  var b=new U2Face(new U2Point(200,-57),new U2Point(200,57));
  var wrong=new U2Face(new U2Point(0,500),new U2Point(114,500));
  var link=Upvc2Geometry.Link(new[]{a,wrong},new[]{b},114);
  check(ReferenceEquals(link.A,a)&&ReferenceEquals(link.B,b),"collinear socket pairing");
  failed=false;try{Upvc2Geometry.Link(new[]{wrong},new[]{b},114);}catch(InvalidOperationException){failed=true;}check(failed,"reject unconnected faces");
  foreach(var dn in Profile.Diameters("UPVC"))
  {
   double ratio=dn/114.0;
   var face=new U2Face(new U2Point(200*ratio,-dn/2),new U2Point(200*ratio,dn/2));
   check(ReferenceEquals(Upvc2Geometry.Match(b,new[]{face},ratio),face),"socket matching D"+dn);
   check(Math.Abs(Upvc2Geometry.Width(dn/2,-1,1)-dn)<1e-8,"MLINE style span D"+dn);
   foreach(var angle in new[]{0.0,Math.PI/4,Math.PI/2,Math.PI,Math.PI*1.5})
   foreach(var mirror in new[]{-1,1})
   {
    var y=new U2Point(Math.Cos(angle),Math.Sin(angle));var x=new U2Point(y.Y,-y.X)*mirror;
    var origin=new U2Point(1500,-700);
    var p=Upvc2Geometry.Map(new U2Point(0,0),origin,x,y);
    var q=Upvc2Geometry.Map(new U2Point(dn,0),origin,x,y);
    check(Math.Abs((q-p).Length-dn)<1e-8,"rotation/mirror preserves actual diameter");
   }
  }
  failed=false;try{Upvc2Geometry.Width(100,0,1);}catch(InvalidOperationException){failed=true;}check(failed,"reject non-centred MLINE");
  failed=false;try{Upvc2Geometry.Match(a,new[]{a},0);}catch(ArgumentException){failed=true;}check(failed,"reject zero socket size");
 }
}
