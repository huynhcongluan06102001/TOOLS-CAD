using System;
using System.Linq;
using System.Text.Json;
using System.IO;
using ToolsCad;
static class ValveTests
{
    public static void Run(Action<bool,string> check)
    {
        void Reject(Action a,string why){bool failed=false;try{a();}catch(InvalidOperationException){failed=true;}check(failed,why);}
        check(ValveCatalog.Groups.Length==19,"19 groups from English table headers");
        check(ValveCatalog.Groups.Sum(g=>g.items.Length)==176,"all 176 table references mapped");
        foreach(var group in ValveCatalog.Groups) {
            check(group.items.Select(s=>s.dn).Distinct().Count()==group.items.Length,"no ambiguous size mapping "+group.key);
            foreach(var item in group.items) {
                check(item.sx>0&&item.sy>0,"sample scale retained "+item.name);
                check(ValveCatalog.Size(group.key,item.dn)==item,"exact size lookup");
            }
        }
        check(ValveCatalog.Group("V07").items.All(s=>s.dn!=125),"missing stainless DN125 not fabricated");
        check(ValveCatalog.Group("V05").items.All(s=>s.dn!=300),"missing silent DN300 not fabricated");
        check(ValveCatalog.Groups.Skip(16).All(g=>g.items.Single().dn==0),"sensors/gauge unsized Standard");
        check(ValveGeometry.MatchesWidth(219.1,200),"DN200 steel valve match");
        check(ValveGeometry.MatchesWidth(273.0,250),"DN250 steel valve match");
        check(ValveGeometry.MatchesWidth(323.8,300),"DN300 steel valve match");
        check(!ValveGeometry.MatchesWidth(323.8,250),"DN300 pipe cannot receive DN250 valve");
        check(Profile.Diameters("STEEL").SequenceEqual(new double[]{15,20,25,32,40,50,65,80,100,125,150,200,250,300}),"steel sizes include three supplied DN sizes");
        foreach(double ucs in new[]{0.0,.3,1.0})foreach(int quadrant in new[]{-2,-1,0,1,2}) {
            double target=ucs+quadrant*Math.PI/2;
            foreach(double error in new[]{-.2,0,.2}) {
                var d=new U2Point(Math.Cos(target+error),Math.Sin(target+error));
                double angle=ValveGeometry.Rotation(d,true,ucs);
                check(Math.Abs(Math.Sin(angle-target))<1e-10&&Math.Cos(angle-target)>.999,"ortho rotation relative to UCS");
                check(Math.Abs(Math.Sin(ValveGeometry.Rotation(d,false,ucs)-target-error))<1e-10,"free rotation retains angle");
            }
        }
        foreach(double basis in new[]{0.0,.3,1.1})foreach(int step in Enumerable.Range(-8,17)) {
            double target=basis+step*Math.PI/4;
            foreach(double error in new[]{-.2,0,.2})
                check(Math.Abs(ValveGeometry.Snap45(target+error,basis)-target)<1e-9,"45 degree snapping all octants relative UCS");
        }
        var prefs=new Preferences();check(prefs.For("VALVES").System=="STEEL","valve profile uses compatible bridge settings");
        check(!ReferenceEquals(prefs.For("VALVES"),prefs.For("STEEL")),"valve overlap isolated from steel");
        foreach(var dn in ValveCatalog.Group("V01").items.Select(s=>s.dn)) {
            check(ValveGeometry.MatchesWidth(ValveCatalog.Outside(dn),dn),"DN outside diameter match");
            check(!ValveGeometry.MatchesWidth(ValveCatalog.Outside(dn)*4,dn),"wrong size rejected");
            double d=ValveCatalog.Outside(dn);
            var caps=new[]{new U2Face(new U2Point(-d,-d/2),new U2Point(-d,d/2)),new U2Face(new U2Point(d,-d/2),new U2Point(d,d/2)),new U2Face(new U2Point(-d,5*d),new U2Point(d,5*d))};
            var ports=ValveGeometry.Ports(caps,d);check(Math.Abs(ports.A.X+d)<1e-8&&Math.Abs(ports.B.X-d)<1e-8,"ignore actuator at side of flow");
            foreach(var angle in new[]{0.0,.6,Math.PI/2,Math.PI,5.0})foreach(var overlap in new[]{0.0,d*.05,d*.2}) {
                U2Point W(U2Point p)=>new U2Point(100,-500)+PlusGeometry.Rotate(p,angle);
                var a=W(new U2Point(-d*10,0));var b=W(new U2Point(d*10,0));
                foreach(bool reverse in new[]{false,true}) {
                    var cut=ValveGeometry.Cut(reverse?b:a,reverse?a:b,W(ports.A),W(ports.B),overlap);
                    var u=((reverse?a:b)-(reverse?b:a)).Unit;
                    check(Math.Abs((cut.Left-(reverse?b:a)).Dot(u.Perp))<1e-6,"left remaining pipe stays on axis");
                    check(Math.Abs((cut.Right-cut.Left).Length-(2*d-2*overlap))<1e-6,"overlap applied exactly on both ends");
                }
            }
        }
        var fixtures=JsonDocument.Parse(File.ReadAllText(Path.Combine(AppContext.BaseDirectory,"valve-caps.json"))).RootElement;
        foreach(var fixture in fixtures.EnumerateArray()) {
            U2Point Q(JsonElement p)=>new U2Point(p[0].GetDouble(),p[1].GetDouble());
            double od=ValveCatalog.Outside(fixture.GetProperty("dn").GetInt32());
            var segments=fixture.GetProperty("segments").EnumerateArray().Select(p=>new U2Face(Q(p[0]),Q(p[1]))).ToArray();
            var faces=Upvc2Geometry.JoinCaps(segments).Where(f=>f.Width>=od*.65&&f.Width<=od*6);
            var ports=ValveGeometry.Ports(faces,od);check(ports.B.X>ports.A.X,"source DWG axial ports "+fixture.GetProperty("key")+" DN"+fixture.GetProperty("dn"));
            var middle=(ports.A+ports.B)/2;double theta=Math.Atan2(ports.B.Y-ports.A.Y,ports.B.X-ports.A.X);
            var pa=PlusGeometry.Rotate(ports.A-middle,-theta);var pb=PlusGeometry.Rotate(ports.B-middle,-theta);
            var cut=ValveGeometry.Cut(new U2Point(-od*50,0),new U2Point(od*50,0),pa,pb,0);
            check(cut.Left.X<cut.Right.X,"real source cap spacing can be cut after axis correction");
        }
        Reject(()=>ValveGeometry.Ports(Array.Empty<U2Face>(),60),"end-on or missing ports rejected");
        Reject(()=>ValveGeometry.Cut(new U2Point(-100,0),new U2Point(100,0),new U2Point(-20,0),new U2Point(20,0),20),"overlap cannot consume full gap");
        Reject(()=>ValveGeometry.Cut(new U2Point(-100,0),new U2Point(100,0),new U2Point(-20,2),new U2Point(20,2),0),"misaligned valve never cuts pipe");
        Reject(()=>ValveGeometry.Cut(new U2Point(-100,0),new U2Point(100,0),new U2Point(-110,0),new U2Point(20,0),0),"valve outside pipe extent rejected");
    }
}
