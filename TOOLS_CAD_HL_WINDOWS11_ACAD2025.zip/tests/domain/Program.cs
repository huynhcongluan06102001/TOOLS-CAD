using System;
using System.Collections.Generic;
using System.Globalization;
using ToolsCad;
class Program {
 static int count;
 static void Check(bool ok, string label) { if (!ok) throw new Exception(label); count++; }
 static void Main() {
  foreach(var system in new[]{"PPR","UPVC","STEEL","TRAY","DUCT"}) {
   var p=Profile.Create(system); Check(p.Validate()==null,system);
   foreach(var material in Profile.Materials(system)) {
    p.Material=material; Check(p.Validate()==null,system+material);
    foreach(var fit in Profile.FittingsFor(system,material)) Check(!string.IsNullOrEmpty(Profile.Label(fit)),fit);
   }
   Check(p.Settings().ContainsKey("fit-kind"),"settings");
  }
  foreach(var n in new[]{double.NaN,double.PositiveInfinity,-1.0}) {
   var p=Profile.Create("PPR"); p.Overlap=n; Check(p.Validate()!=null,"overlap");
   p=Profile.Create("PPR"); p.Fillet=n; Check(p.Validate()!=null,"fillet");
   p=Profile.Create("PPR"); p.Allowance=n; Check(p.Validate()!=null,"allowance");
   p=Profile.Create("PPR"); p.Width=n; Check(p.Validate()!=null,"width");
  }
  Check(Profile.Create("UNKNOWN").Validate()!=null,"unknown system");
  var zero=Profile.Create("PPR");zero.Overlap=zero.Fillet=zero.Allowance=0; Check(zero.Validate()==null,"zero allowed");
  CultureInfo.CurrentCulture=new CultureInfo("vi-VN");
  var encoded=LispWire.Encode(new Dictionary<string,object>{{"number",1.25},{"path","C:\\A\"B\n"}});
  Check(encoded.Contains("1.25")&&!encoded.Contains("1,25"),"invariant numbers");
  Check(encoded.Contains("C:\\\\A\\\"B\\n"),"escaping");
  bool threw=false;try {LispWire.Encode(new Dictionary<string,object>{{"bad",double.NaN}});}catch(ArgumentException){threw=true;}
  Check(threw,"reject NaN wire");
  var legacy=System.Text.Json.JsonSerializer.Deserialize<Profile>("{}");
  Check(legacy.IncludePrefix && legacy.IncludeSuffix && legacy.IncludeMaterial,"legacy note defaults");
  foreach(bool enabled in new[]{true,false}) {
   var p=Profile.Create("DUCT"); p.IncludePrefix=p.IncludeSuffix=p.IncludeMaterial=enabled;
   var round=System.Text.Json.JsonSerializer.Deserialize<Profile>(System.Text.Json.JsonSerializer.Serialize(p));
   Check(round.IncludePrefix==enabled && round.IncludeSuffix==enabled && round.IncludeMaterial==enabled,"note flags persist");
   Check((string)p.Settings()["note-material-enabled"]==(enabled?"1":"0"),"material bridge");
   Check((string)p.Settings()["note-prefix-enabled"]==(enabled?"1":"0"),"prefix bridge");
   Check((string)p.Settings()["note-suffix-enabled"]==(enabled?"1":"0"),"suffix bridge");
  }
  var prefs=new Preferences(); prefs.For("PPR").Layer="ỐNG_NƯỚC";
  var restored=System.Text.Json.JsonSerializer.Deserialize<Preferences>(System.Text.Json.JsonSerializer.Serialize(prefs));
  Check(restored.For("PPR").Layer=="ỐNG_NƯỚC", "JSON Unicode round trip");
  Check(restored.For("PPR").Dn==25, "JSON numeric round trip");Console.WriteLine("PASS: "+count+" domain assertions; JSON round trip included; AutoCAD/WinForms not executed.");
 }
}
