using System;
using System.Collections.Generic;
using System.Globalization;
using ToolsCad;
class Program {
 static int count;
 static void Check(bool ok, string label) { if (!ok) throw new Exception(label); count++; }
 static void Main() {
  HiddenTests.Run(Check);
  ValveTests.Run(Check);
  UpvcPlusTests.Run(Check);
  Upvc2Tests.Run(Check);
  Upvc2BatchTests.Run(Check);
  PreviewTests.Run(Check);
  foreach(var system in new[]{"PPR","UPVC","STEEL","TRAY","DUCT"}) {
   var p=Profile.Create(system); Check(p.Validate()==null,system); Check(p.MlineStyle=="Standard", "default MLINE style");
   foreach(var material in Profile.Materials(system)) {
    p.Material=material; Check(p.Validate()==null,system+material);
    foreach(var fit in Profile.FittingsFor(system,material)) Check(!string.IsNullOrEmpty(Profile.Label(fit)),fit);
   }
   Check(p.Settings().ContainsKey("fit-kind"),"settings");
  }
  foreach(var n in new[]{double.NaN,double.PositiveInfinity,-1.0}) {
   var p=Profile.Create("PPR"); p.Overlap=n; Check(p.Validate()!=null,"overlap");
   p=Profile.Create("PPR"); p.Fillet=n; Check(p.Validate()!=null,"fillet");
   p=Profile.Create("PPR"); p.Allowance=n; Check(p.Validate()!=null,"allowance");
   p=Profile.Create("PPR"); p.Width=n; Check(p.Validate()!=null,"width");
  }
  Check(Profile.Create("UNKNOWN").Validate()!=null,"unknown system");
  var zero=Profile.Create("PPR");zero.Overlap=zero.Fillet=zero.Allowance=0; Check(zero.Validate()==null,"zero allowed");
  CultureInfo.CurrentCulture=new CultureInfo("vi-VN");
  var encoded=LispWire.Encode(new Dictionary<string,object>{{"number",1.25},{"path","C:\\A\"B\n"}});
  Check(encoded.Contains("1.25")&&!encoded.Contains("1,25"),"invariant numbers");
  Check(encoded.Contains("C:\\\\A\\\"B\\n"),"escaping");
  bool threw=false;try {LispWire.Encode(new Dictionary<string,object>{{"bad",double.NaN}});}catch(ArgumentException){threw=true;}
  Check(threw,"reject NaN wire");
  var legacy=System.Text.Json.JsonSerializer.Deserialize<Profile>("{}");
  Check(legacy.IncludePrefix && legacy.IncludeSuffix && legacy.IncludeMaterial,"legacy note defaults");
  foreach(bool enabled in new[]{true,false}) {
   var p=Profile.Create("DUCT"); p.IncludePrefix=p.IncludeSuffix=p.IncludeMaterial=enabled;
   var round=System.Text.Json.JsonSerializer.Deserialize<Profile>(System.Text.Json.JsonSerializer.Serialize(p));
   Check(round.IncludePrefix==enabled && round.IncludeSuffix==enabled && round.IncludeMaterial==enabled,"note flags persist");
   Check((string)p.Settings()["note-material-enabled"]==(enabled?"1":"0"),"material bridge");
   Check((string)p.Settings()["note-prefix-enabled"]==(enabled?"1":"0"),"prefix bridge");
   Check((string)p.Settings()["note-suffix-enabled"]==(enabled?"1":"0"),"suffix bridge");
  }
  var isolated = new Preferences();
  var upvc = isolated.For("UPVC"); var upvc2 = isolated.For("UPVC2");
  Check(!ReferenceEquals(upvc,upvc2), "UPVC and UPVC2 profiles independent");
  Check(upvc2.System=="UPVC" && upvc2.Validate()==null,"UPVC2 retains UPVC sizing and material rules");
  upvc2.Material="UPVC_m"; upvc2.Dn=114;
  Check(upvc.Material=="UPVC" && upvc.Dn==60,"UPVC2 changes do not overwrite UPVC");
  foreach(var diameter in Profile.Diameters("UPVC")) {
   var p=Profile.Create("UPVC");p.Dn=p.FitDn=diameter;
   Check(p.Validate()==null,"UPVC supported size "+diameter);
   Check((double)p.Settings()["dn"]==diameter && (double)p.Settings()["fit-dn"]==diameter,"UPVC size passed to LISP "+diameter);
  }
  var prefs=new Preferences(); prefs.For("PPR").Layer="ỐNG_NƯỚC";
  var restored=System.Text.Json.JsonSerializer.Deserialize<Preferences>(System.Text.Json.JsonSerializer.Serialize(prefs));
  Check(restored.For("PPR").Layer=="ỐNG_NƯỚC", "JSON Unicode round trip");
  Check(restored.For("PPR").Dn==25, "JSON numeric round trip");Console.WriteLine("PASS: "+count+" domain assertions; JSON round trip included; AutoCAD/WinForms not executed.");
 }
}
