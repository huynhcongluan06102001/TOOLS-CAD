using System;
using System.Linq;
using ToolsCad;
static class HiddenTests {
 public static void Run(Action<bool,string> check) {
  double Area(HPoint[] p){double a=0;for(int i=0;i<p.Length;i++)a+=HPoint.Cross(p[i],p[(i+1)%p.Length]);return Math.Abs(a)/2;}
  for(int deg=0;deg<360;deg+=15)for(int width=1;width<=200;width+=7) {
   double a=deg*Math.PI/180;var end=new HPoint(1000*Math.Cos(a),1000*Math.Sin(a));
   foreach(var offsets in new[]{new[]{-width/2.0,width/2.0},new[]{-(double)width,0.0},new[]{0.0,(double)width}}) {
    var ring=HiddenBoundary.Build(new[]{new HPoint(0,0),end},offsets[0],offsets[1]);
    check(ring.Length==4,"one closed rectangular boundary");check(Math.Abs(Area(ring)-1000*width)<1e-6,"rotated area and justification");
   }
  }
  foreach(int sign in new[]{-1,1}) {
   var ring=HiddenBoundary.Build(new[]{new HPoint(0,0),new HPoint(1000,0),new HPoint(1000,sign*1000)},-10,10);
   check(ring.Length==6&&Math.Abs(Area(ring)-40000)<1e-6,"90 degree miter");
  }
  void Reject(HPoint[] pts,double lo,double hi){bool rejected=false;try{HiddenBoundary.Build(pts,lo,hi);}catch(ArgumentException){rejected=true;}check(rejected,"invalid boundary rejected");}
  Reject(new[]{new HPoint(0,0),new HPoint(0,0)},-1,1);
  Reject(new[]{new HPoint(0,0),new HPoint(100,0),new HPoint(0,0)},-1,1);
  Reject(new[]{new HPoint(0,0),new HPoint(100,0)},0,0);
  Reject(new[]{new HPoint(0,0),new HPoint(double.NaN,0)},-1,1);
  Reject(new[]{new HPoint(0,0),new HPoint(100,100),new HPoint(0,100),new HPoint(100,0)},-1,1);
  check(!new Preferences().HiddenLine,"Hidden line opt-in default");
 }
}
