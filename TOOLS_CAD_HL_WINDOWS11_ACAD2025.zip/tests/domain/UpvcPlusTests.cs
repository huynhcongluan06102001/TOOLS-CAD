using System;
using System.Linq;
using System.Text.Json;
using System.IO;
using ToolsCad;
static class UpvcPlusTests
{
    static U2Point Point(JsonElement p)=>new U2Point(p[0].GetDouble(),p[1].GetDouble());
    public static void Run(Action<bool,string> check)
    {
        void Reject(Action action,string label){bool failed=false;try{action();}catch(InvalidOperationException){failed=true;}check(failed,label);}
        var fixture=JsonDocument.Parse(File.ReadAllText(Path.Combine(AppContext.BaseDirectory,"upvc-plus-refs.json"))).RootElement.EnumerateArray().ToArray();
        check(PlusGeometry.ButtonRows.Length==10&&PlusGeometry.ButtonRows.SelectMany(r=>r).Distinct().Count()==20,"20 commands in 10 paired rows");
        check(PlusGeometry.ButtonRows.Take(6).All(r=>r[0].StartsWith("MP")&&r[1]=="RS"+r[0].Substring(2)),"MP/RS pairs aligned");
        foreach(var code in Upvc2Geometry.Codes.Concat(PlusRecipe.All.Select(r=>r.Code)).Concat(new[]{"VP1T+1E90","VP1T+1E45","VP2T"}))
            check(PlusGeometry.ButtonRows.SelectMany(r=>r).Count(s=>s==code)==1,"each command exactly once: "+code);
        foreach(var recipe in PlusRecipe.All)
        {
            foreach(var dn in Profile.Diameters("UPVC"))
            {
                var inputs=new U2Point[recipe.Parts.Length];var outputs=new U2Point[recipe.Parts.Length];
                for(int i=0;i<recipe.Parts.Length;i++) {
                    var spec=recipe.Parts[i];var reference=fixture.Single(r=>r.GetProperty("name").GetString()==spec.Name && (new U2Point(r.GetProperty("x").GetDouble(),r.GetProperty("y").GetDouble())-spec.At).Length<.1);
                    // Independent evaluated DWG geometry. Mock size variants only; no AutoCAD dynamic evaluation here.
                    var segments=reference.GetProperty("segments").EnumerateArray().Where(seg=>(Point(seg[0])-Point(seg[1])).Length>1e-6).Select(seg=>new U2Face(recipe.Local(Point(seg[0]))*(dn/recipe.SampleSize),recipe.Local(Point(seg[1]))*(dn/recipe.SampleSize))).ToArray();
                    var faces=Upvc2Geometry.JoinCaps(segments).Where(f=>f.Width>=dn*.95&&f.Width<=dn*1.65).ToArray();
                    inputs[i]=PlusGeometry.Socket(faces,recipe.Local(spec.In),dn,recipe.SampleSize);
                    outputs[i]=PlusGeometry.Socket(faces,recipe.Local(spec.Out),dn,recipe.SampleSize);
                    if(spec.In.Length>.01)check(inputs[i].Length>0,"input socket found "+recipe.Code);
                    if(spec.Out.Length>.01)check(outputs[i].Length>0,"output socket found "+recipe.Code);
                }
                var positions=PlusGeometry.Chain(recipe,inputs,outputs,dn/recipe.SampleSize,recipe.TwoRisers?(double?)(dn*12):null);
                for(int i=1;i<positions.Length;i++) {
                    var link=positions[i]+inputs[i]-positions[i-1]-outputs[i-1];var axis=recipe.Corner?new U2Point(1,-1).Unit:new U2Point(1,0);
                    check(Math.Abs(link.Dot(axis.Perp))<.01&&link.Dot(axis)>0,"socket link aligned and forward "+recipe.Code);
                }
                if(recipe.TwoRisers) {
                    check((positions.Last()-new U2Point(dn*12,0)).Length<1e-6,"terminal elbow stays on selected riser "+recipe.Code);
                    Reject(()=>PlusGeometry.Chain(recipe,inputs,outputs,dn/recipe.SampleSize,dn*.5),"short riser span rejected "+recipe.Code);
                }
                if(recipe.Corner) {
                    var input=inputs[0];var output=positions.Last()+outputs.Last();bool single=recipe.Code=="1E45";
                    foreach(double theta in new[]{0.0,.3,Math.PI/4,Math.PI/2,Math.PI,Math.PI*1.7})
                    foreach(int mirror in new[]{-1,1})
                    foreach(double error in new[]{-5.0,-3,-2,0,2,3,5})
                    foreach(bool reverse in new[]{false,true}) {
                        var x=new U2Point(Math.Cos(theta),Math.Sin(theta));var y=x.Perp*mirror;
                        U2Point World(U2Point p)=>new U2Point(1000,-700)+x*p.X+y*p.Y;
                        var outAxis=single?new U2Point(1,-1).Unit:new U2Point(0,-1);
                        var farA=World(input+new U2Point(-dn*10,0));var nearA=World(input);
                        var farB=World(output+outAxis*(dn*10));var nearB=farB-PlusGeometry.Rotate(x*outAxis.X+y*outAxis.Y,error*Math.PI/180)*(dn*8);
                        var plan=PlusGeometry.Corner(reverse?nearA:farA,reverse?farA:nearA,nearB,farB,single,input,output,dn);
                        U2Point Map(U2Point p)=>plan.Origin+plan.X*p.X+plan.Y*p.Y;
                        check(Math.Abs((farA-Map(input)).Dot(plan.Y))<1e-6,"first far end aligned after join");
                        check(Math.Abs((farB-Map(output)).Dot((plan.X*outAxis.X+plan.Y*outAxis.Y).Perp))<1e-6,"second far end aligned after angular snap");
                        check(plan.NearA==(reverse?0:1)&&plan.NearB==0,"correct near endpoint independent of vertex order");
                    }
                    var target=single?new U2Point(1,-1).Unit:new U2Point(0,-1);
                    var fixedEnd=output+target*(dn*10);var badNear=fixedEnd-PlusGeometry.Rotate(target,6*Math.PI/180)*(dn*8);
                    Reject(()=>PlusGeometry.Corner(input+new U2Point(-dn*10,0),input,badNear,fixedEnd,single,input,output,dn),"outside five degrees rejected");
                }
            }
        }
        Reject(()=>PlusGeometry.Socket(Array.Empty<U2Face>(),new U2Point(10,0),60,114),"missing socket rejected");
    }
}
