using System;
using System.Collections.Generic;
using System.Text.Json;
using ToolsCad;

static class Upvc2BatchTests
{
    public static void Run(Action<bool,string> check)
    {
        var preferences=new Preferences();var p=preferences.For("UPVC2");
        check(!p.UpvcBatchSelect,"old/default profile keeps single selection");
        check(!JsonSerializer.Deserialize<Profile>("{}").UpvcBatchSelect,"legacy JSON defaults to single");
        p.UpvcBatchSelect=true;
        var restored=JsonSerializer.Deserialize<Preferences>(JsonSerializer.Serialize(preferences));
        check(restored.For("UPVC2").UpvcBatchSelect,"Select preference persists");
        check(!restored.For("UPVC").UpvcBatchSelect,"Select isolated from UPVC");
        check((string)p.Settings()["upvc-batch-select"]=="1","Select passed to LISP");
        p.UpvcBatchSelect=false;check((string)p.Settings()["upvc-batch-select"]=="0","single mode passed to LISP");

        var attempts=new List<string>();
        var first=Upvc2Batch.Join("A","B",h=>{attempts.Add(h);return "OK|A1,A2";});
        check(first=="OK|A1,A2" && attempts.Count==1,"first join replaces main with two survivors");
        attempts.Clear();
        var second=Upvc2Batch.Join(first.Substring(3),"C",h=>{
            attempts.Add(h);return h=="A1"?"ERROR: outside this segment":"OK|A21,A22";});
        check(second=="OK|A1,A21,A22","next join retains untouched survivor and splits matching survivor");
        check(string.Join(",",attempts)=="A1,A2","never reuse erased original main");
        attempts.Clear();
        var failed=Upvc2Batch.Join(second.Substring(3),"D",h=>{attempts.Add(h);return "ERROR: missing fitting";});
        check(!failed.StartsWith("OK|"),"failure cannot update caller pool");
        check(attempts.Count==3,"all selected main descendants considered");
        var third=Upvc2Batch.Join(second.Substring(3),"E",h=>h=="A1"?"OK|A11,A12":"ERROR");
        check(third=="OK|A21,A22,A11,A12","valid later branch can follow failed branch");
        check(Upvc2Batch.Join("A","B",h=>"OK|A")=="OK|A","trim off retains original main");
        attempts.Clear();
        check(Upvc2Batch.Join("A,A,a,B","A",h=>{attempts.Add(h);return "OK|B1,B2";})=="OK|A,B1,B2","duplicate handles removed and self ignored");
        check(attempts.Count==1 && attempts[0]=="B","main never joined to itself");
        check(Upvc2Batch.Join("","B",h=>throw new Exception()).StartsWith("ERROR:"),"empty pool rejected without callback");
    }
}
