using System;
using System.Text.Json;
using ToolsCad;

static class PreviewTests
{
    public static void Run(Action<bool,string> check)
    {
        var p=JsonSerializer.Deserialize<Preferences>("{}");
        check(!p.RoutePreview,"legacy settings preserve preview off");p.RoutePreview=true;
        p.For("UPVC");p.For("UPVC2");p.For("DUCT");
        var round=JsonSerializer.Deserialize<Preferences>(JsonSerializer.Serialize(p));
        check(round.RoutePreview && round.Pages.Count==3,"global preview survives save and tab changes");
        var start=new U2Point(50,100);
        foreach(double heading in new[]{0,23,90,173,225,310})
        foreach(string mode in new[]{"45","90","BOTH","FREE"})
        foreach(int turn in mode=="90"?new[]{0,90,-90,180}:mode=="45"?new[]{0,45,-45,135,-135,180}:new[]{0,45,-45,90,-90,135,-135,180})
        foreach(double offset in new[]{-5,-3,-2,0,2,3,5})
        {
            double h=heading*Math.PI/180, target=(heading+turn)*Math.PI/180;
            var previous=start-new U2Point(Math.Cos(h),Math.Sin(h))*100;
            var point=start+new U2Point(Math.Cos(target+offset*Math.PI/180),Math.Sin(target+offset*Math.PI/180))*500;
            var expected=start+new U2Point(Math.Cos(target),Math.Sin(target))*500;
            var actual=PreviewGeometry.Snap(previous,start,point,mode);
            check((actual-expected).Length<1e-6,"preview snaps exactly within five degrees");
        }
        foreach(double angle in new[]{39.9,50.1,84.9,95.1})
        {
            var point=start+new U2Point(Math.Cos(angle*Math.PI/180),Math.Sin(angle*Math.PI/180))*200;
            check((PreviewGeometry.Snap(start-new U2Point(100,0),start,point,"BOTH")-point).Length<1e-6,"outside tolerance unchanged");
            check((PreviewGeometry.Snap(null,start,point,"BOTH")-point).Length<1e-6,"first segment free");
        }
    }
}
