from pathlib import Path
import json
root=Path(__file__).resolve().parents[2]
bridge=(root/'source/palette/ValveBridge.cs').read_text()
jig=(root/'source/palette/ValveJig.cs').read_text()
audit=(root/'source/palette/ValveAudit.cs').read_text()
assert 'public U2Point InsertionOffset => new U2Point();' in bridge
assert 's.Center=' not in bridge and 's.InsertionOffset=' not in bridge
measure=bridge.split('private static void ValveMeasure',1)[1].split('[LispFunction',1)[0]
assert 'ValveBody' not in measure and 'GeometricExtents' not in measure
assert 'session.InsertionOffset' in jig and 'ValvePose' not in jig.split('protected override bool WorldDraw',1)[1].split('public void Apply',1)[0]
assert 'property.GetAllowedValues()' in audit and 'foreach(var state in states)' in audit
assert 'source.Save' not in audit and 'source.Wblock' not in audit
catalog=json.loads((root/'source/palette/Resources/ValveCatalog.json').read_text())
assert len(catalog)==19 and sum(len(g['items']) for g in catalog)==176
assert all(item['sx']>0 and item['sy']>0 for g in catalog for item in g['items'])
print('PASS: native insertion rule applies to all 19 groups / 176 catalog entries; no bbox/port-center placement fallback; host audit enumerates states without saving DWG.')
