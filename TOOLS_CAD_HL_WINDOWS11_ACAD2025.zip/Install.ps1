$ErrorActionPreference = 'Stop'
if (Get-Process acad -ErrorAction SilentlyContinue) { throw 'Close AutoCAD before installing.' }
$source = Join-Path $PSScriptRoot 'ToolsCadHL.bundle'
$target = Join-Path $env:APPDATA 'Autodesk\ApplicationPlugins\ToolsCadHL.bundle'
if (Test-Path $target) { throw 'ToolsCadHL.bundle already exists. Uninstall the previous package first; no files were overwritten.' }
$hashes = Get-Content (Join-Path $source 'manifest.json') -Raw | ConvertFrom-Json
foreach ($entry in $hashes.PSObject.Properties) {
    if ($entry.Name -match '(^[/\\]|\.\.|:)') { throw 'Invalid manifest path.' }
    $file = Join-Path $source $entry.Name
    if ((Get-FileHash $file -Algorithm SHA256).Hash -ne $entry.Value) { throw "Checksum mismatch: $($entry.Name)" }
}
New-Item (Split-Path $target) -ItemType Directory -Force | Out-Null
Copy-Item $source $target -Recurse
Write-Host "Installed: $target"
Write-Host 'Start AutoCAD 2025, then HLFLOAT. If loading is blocked, consult HUONG_DAN_CAI_DAT.md; keep SECURELOAD enabled.'
