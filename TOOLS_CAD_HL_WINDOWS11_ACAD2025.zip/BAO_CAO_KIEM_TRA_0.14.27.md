# Kiểm tra TOOLS CAD HL 0.14.27

Bản nền: 0.14.26. Bổ sung VALVES ngay dưới STEEL, thư viện riêng, danh mục theo 19 cột tiếng Anh trong TEMPLATE VALVE HL1.dwg. Thư viện gốc được giữ nguyên byte trong bundle. Có 176 block mẫu; một số size không có trong một số cột nên không tạo lựa chọn giả. Ba mục không ghi DN dùng Standard.

## Phần đã kiểm tra

- Biên dịch .NET dành cho AutoCAD 2025: không lỗi/cảnh báo.
- 17.047 assertions domain gồm các kiểm tra sẵn có và VALVES: ánh xạ 176 mẫu, size thiếu, hồ sơ lưu riêng, đối chiếu DN/OD, ngậm, hai đầu ống còn lại, đảo đầu tuyến và xoay hình học.
- Trích hình học nhìn thấy từ các block đã đánh giá trong DWG, gồm block lồng nhau, và kiểm tra nhận cổng cho **155 mẫu van hai cổng** ở trạng thái mẫu đang hiển thị. Kiểm tra cắt theo hai cổng sau khi căn trục. Đây là dữ liệu hình học đọc bằng Aspose, không phải thực thi block động bằng AutoCAD.
- 10 assertions VeLisp với API CAD giả lập: Space trước/sau click đặt, hai giai đoạn di chuyển/xoay, truyền đúng DN/ngậm, Esc ở hai giai đoạn, quyền sở hữu và dọn block xem trước.
- Kiểm tra ngoặc/đường gọi LISP, DLL nhúng và SHA256 gói ZIP.

## Chưa kiểm chứng trực tiếp

Không có AutoCAD Windows trong môi trường xây dựng. Chưa xác nhận thực tế độ mượt khi rê, mọi visibility/lookup, Wipeout, attribute khi biến đổi, DPI/docking và Undo trên bản vẽ thực. Việc chọn cổng dựa trên hình học nhìn thấy, chưa phải connector metadata do nhà sản xuất quy định. Không thể cam kết hoàn toàn không lỗi.

## Kiểm tra trên bản sao bản vẽ

1. HLSTATUS báo LSP/DLL 0.14.27. Tab VALVES nằm giữa STEEL và DUCT; UPVC+ vẫn đủ 20 nút hai cột.
2. Mở DWG mới, nạp thư viện van từ nút LOAD / RELOAD LIBRARY. Chọn từng nhóm, kiểm tra danh sách size và tên nút. Thử nhóm không có DN15/DN300 và ba thiết bị Standard.
3. Đặt Gate valve DN15, DN100; Butterfly valve DN80; uPVC T1/T2; Flexible stainless steel và một cảm biến. So hình và scale với mẫu bảng.
4. Rê trước khi click, Space nhiều lần, kiểm tra hình cập nhật đúng trạng thái. Click đặt, rê xoay, Space tiếp, click chốt; Esc ở cả hai bước không để lại block xem trước.
5. Trên MLINE ngang/dọc/xiên: click ở tim hoặc mép, kiểm tra van bám đúng tim, rê hai phía đảo hướng. Chốt với ngậm 0 và 2 mm; đo vị trí đầu MLINE mới.
6. Với thiết bị một cổng, kiểm tra khoảng cắt theo thân đúng ý định; chữ/attribute không làm rộng khoảng cắt. Với van hai cổng sai DN, trạng thái không có cổng hoặc quá sát đầu tuyến, kiểm tra lỗi không làm mất MLINE.
7. Kiểm tra style/scale/layer/xdata của hai đoạn mới. Thử layer khóa, thư viện thiếu block, đổi bản vẽ, hủy lệnh. U phải hoàn tác cả lượt đặt.
8. Thử lại UPVC+, Preview tuyến, UPVC/PPR/STEEL/DUCT để kiểm tra các chức năng đang dùng.

Cài đặt theo DOC_TRUOC_KHI_CAI_0.14.27.txt. Cần đóng/mở AutoCAD khi thay DLL; APPLOAD lại LSP không thay DLL đã nạp trong phiên.
